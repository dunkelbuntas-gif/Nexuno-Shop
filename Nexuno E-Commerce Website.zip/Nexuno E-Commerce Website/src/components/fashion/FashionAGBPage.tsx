import React from 'react';
import { ArrowLeft, FileText, ShoppingCart, Truck, CreditCard } from 'lucide-react';

interface FashionAGBPageProps {
  onBack?: () => void;
}

export function FashionAGBPage({ onBack }: FashionAGBPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="mb-6 flex items-center space-x-2 text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium">Zurück zum Shop</span>
          </button>

          {/* Title */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-500 to-green-600 text-white rounded-2xl mb-4">
              <FileText className="h-8 w-8" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Allgemeine Geschäftsbedingungen
            </h1>
            <p className="text-xl text-slate-300">
              Gültig ab: 01. Januar 2025
            </p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="tech-grid-minimal"></div>
        </div>
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <div className="bg-slate-900 rounded-3xl shadow-lg border border-slate-700 p-8 md:p-12">
            
            <div className="space-y-12">
              {/* Geltungsbereich */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-emerald-500">
                  § 1 Geltungsbereich
                </h2>
                <p className="text-slate-300 leading-relaxed">
                  Diese Allgemeinen Geschäftsbedingungen (nachfolgend "AGB") der FashionStore GmbH 
                  (nachfolgend "Verkäufer") gelten für alle Verträge zwischen einem Verbraucher oder Unternehmer 
                  (nachfolgend "Kunde") und dem Verkäufer bezüglich der vom Verkäufer in seinem Online-Shop 
                  dargestellten Waren. Hiermit wird der Einbeziehung von eigenen Bedingungen des Kunden widersprochen, 
                  es sei denn, es ist etwas anderes vereinbart.
                </p>
              </div>

              {/* Vertragsschluss */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-cyan-500 flex items-center">
                  <ShoppingCart className="h-6 w-6 mr-3" />
                  § 2 Vertragsschluss
                </h2>
                
                <div className="space-y-6">
                  <div className="bg-slate-800 rounded-2xl p-6">
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Produktdarstellung
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Die im Online-Shop dargestellten Produkte stellen kein rechtlich bindendes Vertragsangebot 
                      des Verkäufers dar, sondern sind nur eine unverbindliche Aufforderung an den Kunden, 
                      Waren zu bestellen. Mit der Bestellung der gewünschten Ware gibt der Kunde ein für ihn 
                      verbindliches Angebot auf Abschluss eines Kaufvertrages ab.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Bestellvorgang
                    </h3>
                    <ol className="list-decimal list-inside text-slate-300 space-y-2 ml-4">
                      <li>Auswahl der gewünschten Ware im Online-Shop</li>
                      <li>Hinzufügen der Ware in den Warenkorb</li>
                      <li>Bestätigung der Bestellung durch Klicken des "Kostenpflichtig bestellen"-Buttons</li>
                      <li>Automatische Eingangsbestätigung per E-Mail</li>
                      <li>Annahme der Bestellung durch Versandbestätigung</li>
                    </ol>
                  </div>
                </div>
              </div>

              {/* Widerrufsrecht */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-orange-500">
                  § 3 Widerrufsrecht
                </h2>
                
                <div className="bg-slate-800 rounded-2xl p-6 mb-6">
                  <h3 className="text-xl font-semibold text-slate-200 mb-3">
                    Widerrufsrecht für Verbraucher
                  </h3>
                  <p className="text-slate-300 leading-relaxed">
                    Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen. 
                    Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter 
                    Dritter, der nicht der Beförderer ist, die Waren in Besitz genommen haben bzw. hat.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-slate-200 mb-3">
                    Ausübung des Widerrufsrechts
                  </h3>
                  <p className="text-slate-300 leading-relaxed">
                    Um Ihr Widerrufsrecht auszuüben, müssen Sie uns mittels einer eindeutigen Erklärung 
                    (z.B. ein mit der Post versandter Brief oder E-Mail) über Ihren Entschluss, diesen 
                    Vertrag zu widerrufen, informieren. Sie können dafür das beigefügte Muster-Widerrufsformular 
                    verwenden, das jedoch nicht vorgeschrieben ist.
                  </p>
                </div>
              </div>

              {/* Preise und Zahlungsbedingungen */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-purple-500 flex items-center">
                  <CreditCard className="h-6 w-6 mr-3" />
                  § 4 Preise und Zahlungsbedingungen
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-slate-800 border border-slate-600 rounded-xl p-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Preisangaben</h4>
                    <p className="text-slate-300 text-sm leading-relaxed">
                      Die angegebenen Preise enthalten die gesetzliche Umsatzsteuer und sonstige Preisbestandteile. 
                      Hinzu kommen etwaige Versandkosten.
                    </p>
                  </div>
                  
                  <div className="bg-slate-800 border border-slate-600 rounded-xl p-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Zahlungsmöglichkeiten</h4>
                    <ul className="text-slate-300 text-sm space-y-1">
                      <li>• Kreditkarte (Visa, Mastercard)</li>
                      <li>• PayPal</li>
                      <li>• SEPA-Lastschrift</li>
                      <li>• Klarna (Rechnung, Ratenkauf)</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Lieferung und Versand */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-blue-500 flex items-center">
                  <Truck className="h-6 w-6 mr-3" />
                  § 5 Lieferung und Versand
                </h2>
                
                <div className="space-y-6">
                  <div className="bg-slate-800 rounded-2xl p-6">
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Lieferzeiten
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Die Lieferung von Waren erfolgt auf dem Versandweg an die vom Kunden angegebene Lieferadresse. 
                      Bei der Abwicklung der Transaktion ist die in der Bestellabwicklung des Verkäufers angegebene 
                      Lieferadresse maßgeblich.
                    </p>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 border border-slate-600 rounded-lg bg-slate-800">
                      <div className="text-2xl font-bold text-emerald-400 mb-2">1-3 Tage</div>
                      <div className="text-sm text-slate-300">Standard-Versand</div>
                    </div>
                    <div className="text-center p-4 border border-slate-600 rounded-lg bg-slate-800">
                      <div className="text-2xl font-bold text-cyan-400 mb-2">1-2 Tage</div>
                      <div className="text-sm text-slate-300">Express-Versand</div>
                    </div>
                    <div className="text-center p-4 border border-slate-600 rounded-lg bg-slate-800">
                      <div className="text-2xl font-bold text-orange-400 mb-2">Kostenlos</div>
                      <div className="text-sm text-slate-300">ab 75€ Bestellwert</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Eigentumsvorbehalt */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-red-500">
                  § 6 Eigentumsvorbehalt
                </h2>
                <p className="text-slate-300 leading-relaxed">
                  Bis zur vollständigen Bezahlung des geschuldeten Kaufpreises bleibt die gelieferte Ware im Eigentum 
                  des Verkäufers.
                </p>
              </div>

              {/* Mängelhaftung */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-yellow-500">
                  § 7 Mängelhaftung (Gewährleistung)
                </h2>
                <p className="text-slate-300 leading-relaxed">
                  Es gelten die gesetzlichen Mängelhaftungsrechte. Bei Verbrauchern beträgt die Verjährungsfrist 
                  für Mängelhaftungsansprüche bei neuen Waren zwei Jahre ab Ablieferung der Ware.
                </p>
              </div>

              {/* Schlussbestimmungen */}
              <div className="bg-slate-800 rounded-2xl p-6">
                <h2 className="text-2xl font-bold text-white mb-6">
                  § 8 Schlussbestimmungen
                </h2>
                <div className="space-y-4">
                  <p className="text-slate-300 leading-relaxed">
                    <strong>Anwendbares Recht:</strong> Es gilt das Recht der Bundesrepublik Deutschland unter 
                    Ausschluss des UN-Kaufrechts.
                  </p>
                  <p className="text-slate-300 leading-relaxed">
                    <strong>Gerichtsstand:</strong> Sofern es sich beim Kunden um einen Kaufmann, eine juristische 
                    Person des öffentlichen Rechts oder um ein öffentlich-rechtliches Sondervermögen handelt, 
                    ist Gerichtsstand für alle Streitigkeiten aus Vertragsverhältnissen zwischen dem Kunden 
                    und dem Verkäufer der Sitz des Verkäufers.
                  </p>
                </div>
              </div>

              {/* Kontakt */}
              <div className="text-center">
                <h3 className="text-lg font-semibold text-slate-200 mb-3">
                  Bei Fragen zu den AGB
                </h3>
                <p className="text-slate-300">
                  Kontaktieren Sie uns: <br />
                  <strong>E-Mail:</strong> info@nexuno.eu<br />
                  <strong>Telefon:</strong> 015678569698
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default FashionAGBPage;