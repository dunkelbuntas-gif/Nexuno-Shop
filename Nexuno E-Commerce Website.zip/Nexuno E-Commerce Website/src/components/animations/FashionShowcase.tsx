import React from "react";
import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { MotionScrollReveal } from "./MotionParallax";
import { MotionButton } from "./MotionInteractions";

interface FashionShowcaseProps {
  className?: string;
}

interface ShowcaseImage {
  src: string;
  title: string;
  delay: number;
  'aria-label': string;
}

interface ImageMosaicProps {
  className?: string;
  images: ShowcaseImage[];
}

// Main Hero Showcase Component
export function FashionHeroShowcase({
  src,
  title,
  subtitle,
  className = "",
  'aria-label': ariaLabel
}: {
  src: string;
  title: string;
  subtitle: string;
  className?: string;
  'aria-label'?: string;
}) {
  return (
    <div className={`relative aspect-video rounded-2xl overflow-hidden ${className}`}>
      <motion.div
        className="relative w-full h-full"
        initial={{ scale: 1 }}
        whileHover={{ scale: 1.02 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <ImageWithFallback
          src={src}
          alt={ariaLabel || title}
          className="w-full h-full object-cover"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent" />
        
        {/* Content Overlay */}
        <motion.div
          className="absolute inset-0 flex items-end"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <div className="p-8 w-full text-white">
            <h3 className="text-2xl font-bold mb-2">{title}</h3>
            <p className="text-cyan-100">{subtitle}</p>
          </div>
        </motion.div>

        {/* Interactive Overlay on Hover */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 opacity-0"
          whileHover={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        />
      </motion.div>
    </div>
  );
}

// Image Mosaic Component (replaces VideoMosaic)
export function ImageMosaic({ className = "", images }: ImageMosaicProps) {
  return (
    <div className={`grid grid-cols-2 md:grid-cols-3 gap-6 ${className}`}>
      {images.map((image, index) => (
        <motion.div
          key={index}
          className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-20%" }}
          transition={{ delay: image.delay, duration: 0.6 }}
          whileHover={{ scale: 1.05 }}
        >
          <ImageWithFallback
            src={image.src}
            alt={image['aria-label'] || image.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
          
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 via-transparent to-transparent" />
          
          {/* Title overlay */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 p-4"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: image.delay + 0.2 }}
          >
            <h4 className="text-white font-semibold text-lg mb-1">{image.title}</h4>
            <div className="w-full h-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
          </motion.div>

          {/* Hover effect overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 to-blue-600/30 opacity-0"
            whileHover={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          />
        </motion.div>
      ))}
    </div>
  );
}

// Main Fashion Showcase Section
export function FashionShowcase({ className = "" }: FashionShowcaseProps) {
  const showcaseImages: ShowcaseImage[] = [
    {
      src: "https://images.unsplash.com/photo-1618902543712-5167afb37421?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwZmFzaGlvbiUyMHRlY2glMjB3ZWFyfGVufDF8fHx8MTc1NzI0OTE5MXww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Tech Wear",
      delay: 0,
      'aria-label': "Kategorie-Bild: Tech Wear Kollektion"
    },
    {
      src: "https://images.unsplash.com/photo-1620642405534-cd9a3ef7d14b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMGFjY2Vzc29yaWVzJTIwd2VhcmFibGUlMjB0ZWNofGVufDF8fHx8MTc1NzI0OTE5NXww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Smart Accessories",
      delay: 0.1,
      'aria-label': "Kategorie-Bild: Smart Accessories Kollektion"
    },
    {
      src: "https://images.unsplash.com/photo-1753268717665-53efd07d4ad8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGZhc2hpb24lMjBhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlfGVufDF8fHx8MTc1NzI0OTE5OXww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "AI Fashion",
      delay: 0.2,
      'aria-label': "Kategorie-Bild: AI Fashion Kollektion"
    },
    {
      src: "https://images.unsplash.com/photo-1648501570189-0359dab185e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmUlMjBzbmVha2VycyUyMHNob2VzJTIwdGVjaHxlbnwxfHx8fDE3NTcyNDkyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Future Footwear",
      delay: 0.3,
      'aria-label': "Kategorie-Bild: Future Footwear Kollektion"
    },
    {
      src: "https://images.unsplash.com/photo-1592289924034-c423dd2f1c5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXVyYWwlMjBiYWdzJTIwYmFja3BhY2slMjB0ZWNofGVufDF8fHx8MTc1NzI0OTIwN3ww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Neural Bags",
      delay: 0.4,
      'aria-label': "Kategorie-Bild: Neural Bags Kollektion"
    },
    {
      src: "https://images.unsplash.com/photo-1713213199999-c6239448f78f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob2xvZ3JhcGhpYyUyMGZhc2hpb24lMjBpcmlkZXNjZW50fGVufDF8fHx8MTc1NzI0OTIxMXww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Holographic Style",
      delay: 0.5,
      'aria-label': "Kategorie-Bild: Holographic Style Kollektion"
    }
  ];

  return (
    <div className={className}>
      <MotionScrollReveal direction="up">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
            Fashion in Motion
          </h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Erlebe die Zukunft der Mode durch unsere immersive Präsentationen
          </p>
          {/* Accessibility Skip Option */}
          <button 
            className="mt-4 text-sm text-cyan-300 hover:text-cyan-100 underline focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2 focus:ring-offset-slate-900 rounded px-2 py-1"
            onClick={() => document.getElementById('showcase-section-end')?.scrollIntoView({ behavior: 'smooth' })}
            aria-label="Fashion Showcase überspringen für bessere Barrierefreiheit"
          >
            Showcase überspringen →
          </button>
        </div>
      </MotionScrollReveal>

      {/* Hero Showcase Image */}
      <div className="mb-12">
        <MotionScrollReveal direction="up" delay={0.2}>
          <FashionHeroShowcase
            src="https://images.unsplash.com/photo-1733324961705-97bd6cd7f4ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc2hvd2Nhc2UlMjBydW53YXklMjBtb2RlbHxlbnwxfHx8fDE3NTcyNDkyMTV8MA&ixlib=rb-4.1.0&q=80&w=1080"
            title="AI Fashion Collection 2025"
            subtitle="Wo Technologie auf Style trifft"
            className="max-w-4xl mx-auto"
            aria-label="Hauptbild: AI Fashion Collection 2025 Showcase"
          />
        </MotionScrollReveal>
      </div>

      {/* Image Mosaic for Product Categories */}
      <MotionScrollReveal direction="up" delay={0.4}>
        <ImageMosaic
          className="max-w-6xl mx-auto"
          images={showcaseImages}
        />
      </MotionScrollReveal>

      {/* Call to Action */}
      <div className="text-center mt-16" id="showcase-section-end">
        <MotionScrollReveal direction="up" delay={0.6}>
          <MotionButton 
            variant="primary" 
            size="lg" 
            className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 rounded-xl text-lg font-semibold shadow-2xl focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2 focus:ring-offset-slate-900"
            aria-label="Zur kompletten Fashion Kollektion navigieren"
          >
            Entdecke die komplette Kollektion
          </MotionButton>
        </MotionScrollReveal>
      </div>
    </div>
  );
}