import type { Page } from '../App';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer 
      className="relative"
      style={{ 
        background: 'var(--gradient-footer)',
        borderTop: '1px solid var(--border-light)'
      }}
      role="contentinfo"
      aria-label="Website-Footer"
    >
      {/* Futuristic Background Pattern */}
      <div className="absolute inset-0 perspective-grid opacity-20" aria-hidden="true"></div>
      
      {/* Main Footer Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          
          {/* Company Info & Brand */}
          <div className="lg:col-span-2">
            <button 
              onClick={() => onNavigate('home')}
              className="group mb-6 bg-transparent border-0 cursor-pointer transition-all duration-300"
              aria-label="Zur Startseite"
            >
              <h3 className="text-3xl font-bold font-['Poppins'] tracking-wider group-hover:scale-105 transition-transform duration-300">
                <span className="glow-text-tech">NEXUNO</span>
              </h3>
              <span className="block text-slate-400 text-sm font-['Inter'] mt-1">
                Fashion der Zukunft
              </span>
            </button>
            
            <p className="text-slate-300 font-['Inter'] text-base leading-relaxed max-w-md mb-6">
              Entdecke die Zukunft der Mode mit unseren innovativen Designs. 
              Nachhaltig produziert, zeitlos gestaltet, für die Generation von morgen.
            </p>
            
            {/* Company Details */}
            <div className="space-y-2 text-sm text-slate-400 font-['Inter']">
              <p>
                <strong className="text-slate-300">NEXUNO Fashion</strong><br />
                André Schumann<br />
                Fließstraße 6<br />
                12439 Berlin, Deutschland
              </p>
              <p>
                <strong className="text-slate-300">Kontakt:</strong><br />
                <a 
                  href="mailto:info@nexuno.eu" 
                  className="hover:text-[var(--accent-cyan)] transition-colors duration-300"
                  aria-label="E-Mail an NEXUNO Fashion senden"
                >
                  info@nexuno.eu
                </a>
              </p>
            </div>
          </div>

          {/* Shop Navigation */}
          <div>
            <h4 className="text-lg font-semibold mb-6 font-['Poppins'] text-white">
              Shop
            </h4>
            <nav aria-label="Shop Navigation">
              <ul className="space-y-3">
                <li>
                  <button 
                    onClick={() => onNavigate('fashion')}
                    className="footer-link"
                    aria-label="Alle Produkte anzeigen"
                  >
                    Alle Produkte
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('tshirts')}
                    className="footer-link"
                    aria-label="T-Shirts anzeigen"
                  >
                    T-Shirts
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('hoodies')}
                    className="footer-link"
                    aria-label="Hoodies anzeigen"
                  >
                    Hoodies
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('accessories')}
                    className="footer-link"
                    aria-label="Accessoires anzeigen"
                  >
                    Accessoires
                  </button>
                </li>
              </ul>
            </nav>
          </div>

          {/* Support & Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-6 font-['Poppins'] text-white">
              Support & Info
            </h4>
            <nav aria-label="Support und rechtliche Informationen">
              <ul className="space-y-3">
                <li>
                  <button 
                    onClick={() => onNavigate('contact')}
                    className="footer-link"
                    aria-label="Kontakt aufnehmen"
                  >
                    Kontakt
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('about')}
                    className="footer-link"
                    aria-label="Über NEXUNO erfahren"
                  >
                    Über uns
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('impressum')}
                    className="footer-link"
                    aria-label="Impressum anzeigen"
                  >
                    Impressum
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('datenschutz')}
                    className="footer-link"
                    aria-label="Datenschutzerklärung anzeigen"
                  >
                    Datenschutz
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('agb')}
                    className="footer-link"
                    aria-label="AGB anzeigen"
                  >
                    AGB
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('widerruf')}
                    className="footer-link"
                    aria-label="Widerrufsrecht anzeigen"
                  >
                    Widerrufsrecht
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="mt-12 pt-8 border-t border-slate-700">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h4 className="text-xl font-semibold mb-2 font-['Poppins'] text-white">
                Bleib auf dem Laufenden
              </h4>
              <p className="text-slate-400 font-['Inter'] text-sm">
                Erhalte Updates zu neuen Kollektionen und exklusiven Angeboten.
              </p>
            </div>
            <div className="flex gap-3">
              <input 
                type="email" 
                placeholder="Deine E-Mail-Adresse"
                className="flex-1 px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-[var(--accent-cyan)] transition-colors duration-300"
                aria-label="E-Mail-Adresse für Newsletter eingeben"
              />
              <button 
                className="btn-tech-primary px-6 py-3 rounded-lg whitespace-nowrap"
                aria-label="Für Newsletter anmelden"
              >
                Anmelden
              </button>
            </div>
          </div>
        </div>

        {/* Social Links & Quality Badges */}
        <div className="mt-12 pt-8 border-t border-slate-700">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            
            {/* Quality Badges */}
            <div>
              <h5 className="text-sm font-semibold mb-4 font-['Poppins'] text-white">
                Qualität & Nachhaltigkeit
              </h5>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-2 h-2 bg-green-500 rounded-full" aria-hidden="true"></span>
                  <span>100% Organic Cotton</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-2 h-2 bg-blue-500 rounded-full" aria-hidden="true"></span>
                  <span>Fair Trade Certified</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-2 h-2 bg-purple-500 rounded-full" aria-hidden="true"></span>
                  <span>Carbon Neutral</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-2 h-2 bg-orange-500 rounded-full" aria-hidden="true"></span>
                  <span>GOTS Certified</span>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div className="text-right">
              <h5 className="text-sm font-semibold mb-4 font-['Poppins'] text-white">
                Folge uns
              </h5>
              <div className="flex justify-end gap-4">
                <a 
                  href="#" 
                  className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-colors duration-300 group"
                  aria-label="NEXUNO auf Instagram folgen"
                >
                  <span className="text-slate-400 group-hover:text-white transition-colors duration-300">📷</span>
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-colors duration-300 group"
                  aria-label="NEXUNO auf Twitter folgen"
                >
                  <span className="text-slate-400 group-hover:text-white transition-colors duration-300">🐦</span>
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-colors duration-300 group"
                  aria-label="NEXUNO auf Facebook folgen"
                >
                  <span className="text-slate-400 group-hover:text-white transition-colors duration-300">📘</span>
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-colors duration-300 group"
                  aria-label="NEXUNO auf YouTube folgen"
                >
                  <span className="text-slate-400 group-hover:text-white transition-colors duration-300">📺</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright Section */}
      <div 
        className="relative z-10 border-t border-slate-700 py-6"
        style={{ background: 'rgba(15, 23, 42, 0.8)' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center text-center md:text-left">
            <p className="text-slate-400 text-xs font-['Inter'] tracking-wide">
              © 2024 NEXUNO Fashion. Alle Rechte vorbehalten.
            </p>
            <div className="text-xs text-slate-500 md:text-right">
              <span>Made with ❤️ in Berlin</span>
              <span className="mx-2">•</span>
              <span>Powered by Innovation</span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .footer-link {
          @apply text-slate-400 hover:text-[var(--accent-cyan)] transition-all duration-300 text-left bg-transparent border-none cursor-pointer font-['Inter'] text-sm relative;
        }
        
        .footer-link::after {
          content: '';
          position: absolute;
          bottom: -2px;
          left: 0;
          width: 0;
          height: 1px;
          background: var(--accent-cyan);
          transition: width 0.3s ease;
        }
        
        .footer-link:hover::after {
          width: 100%;
        }

        .footer-link:focus {
          outline: 2px solid var(--accent-cyan);
          outline-offset: 2px;
          border-radius: 4px;
        }
      `}</style>
    </footer>
  );
}