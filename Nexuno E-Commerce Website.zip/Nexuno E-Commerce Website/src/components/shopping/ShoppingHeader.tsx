import React, { useState } from 'react';
import { Search, Heart, ShoppingCart, User, Menu, X } from 'lucide-react';
import { useWishlist } from '../wishlist/WishlistButton';
import { useCart } from '../cart/CartContext';
import { motion, AnimatePresence } from 'motion/react';
import { WishlistSidebar } from '../wishlist/WishlistSidebar';

interface ShoppingHeaderProps {
  onSearchToggle?: () => void;
  onCartToggle?: () => void;
  onMenuToggle?: () => void;
}

export function ShoppingHeader({ 
  onSearchToggle, 
  onCartToggle, 
  onMenuToggle 
}: ShoppingHeaderProps) {
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Get wishlist count (assuming we have this hook)
  const wishlistCount = 0; // Replace with actual wishlist count
  const { items } = useCart();
  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const HeaderButton = ({ 
    icon: Icon, 
    count, 
    onClick, 
    ariaLabel,
    className = "" 
  }: {
    icon: any;
    count?: number;
    onClick?: () => void;
    ariaLabel: string;
    className?: string;
  }) => (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        relative p-2 rounded-lg transition-all duration-200 
        bg-white/80 backdrop-blur border border-white/30 
        hover:bg-white hover:border-cyan-200 hover:text-cyan-600
        focus:outline-none focus:ring-2 focus:ring-cyan-400/60 focus:ring-offset-2
        ${className}
      `}
      aria-label={ariaLabel}
    >
      <Icon className="w-5 h-5" />
      {count !== undefined && count > 0 && (
        <motion.span
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium"
        >
          {count > 99 ? '99+' : count}
        </motion.span>
      )}
    </motion.button>
  );

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-lg border-b border-slate-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <h1 className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                Nexuno
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-slate-700 hover:text-cyan-600 font-medium transition-colors">
                Alle Produkte
              </a>
              <a href="#" className="text-slate-700 hover:text-cyan-600 font-medium transition-colors">
                T-Shirts
              </a>
              <a href="#" className="text-slate-700 hover:text-cyan-600 font-medium transition-colors">
                Hoodies
              </a>
              <a href="#" className="text-slate-700 hover:text-cyan-600 font-medium transition-colors">
                Accessories
              </a>
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-3">
              {/* Search */}
              <HeaderButton
                icon={Search}
                onClick={onSearchToggle}
                ariaLabel="Suche öffnen"
                className="hidden sm:flex"
              />

              {/* Wishlist */}
              <HeaderButton
                icon={Heart}
                count={wishlistCount}
                onClick={() => setIsWishlistOpen(true)}
                ariaLabel="Wunschliste öffnen"
              />

              {/* Cart */}
              <HeaderButton
                icon={ShoppingCart}
                count={cartCount}
                onClick={onCartToggle}
                ariaLabel="Warenkorb öffnen"
              />

              {/* Account */}
              <HeaderButton
                icon={User}
                onClick={() => {}}
                ariaLabel="Konto"
                className="hidden sm:flex"
              />

              {/* Mobile Menu */}
              <HeaderButton
                icon={isMobileMenuOpen ? X : Menu}
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                ariaLabel="Menü"
                className="md:hidden"
              />
            </div>
          </div>

          {/* Mobile Menu */}
          <AnimatePresence>
            {isMobileMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="md:hidden border-t border-slate-200 py-4"
              >
                <nav className="space-y-3">
                  <a href="#" className="block px-4 py-2 text-slate-700 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-all">
                    Alle Produkte
                  </a>
                  <a href="#" className="block px-4 py-2 text-slate-700 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-all">
                    T-Shirts
                  </a>
                  <a href="#" className="block px-4 py-2 text-slate-700 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-all">
                    Hoodies
                  </a>
                  <a href="#" className="block px-4 py-2 text-slate-700 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-all">
                    Accessories
                  </a>
                  <div className="flex gap-2 px-4 py-2">
                    <HeaderButton
                      icon={Search}
                      onClick={onSearchToggle}
                      ariaLabel="Suche öffnen"
                      className="flex-1"
                    />
                    <HeaderButton
                      icon={User}
                      onClick={() => {}}
                      ariaLabel="Konto"
                      className="flex-1"
                    />
                  </div>
                </nav>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Wishlist Sidebar */}
      <WishlistSidebar 
        isOpen={isWishlistOpen} 
        onClose={() => setIsWishlistOpen(false)} 
      />
    </>
  );
}