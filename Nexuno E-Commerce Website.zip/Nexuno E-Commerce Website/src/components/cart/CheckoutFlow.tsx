import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingCart, 
  CreditCard, 
  Truck, 
  CheckCircle, 
  ArrowLeft, 
  ArrowRight,
  Lock,
  User,
  MapPin,
  Calendar,
  Shield
} from 'lucide-react';
import { MotionButton, MotionStaggerContainer } from '../animations/MotionInteractions';
import { MotionScrollReveal } from '../animations/MotionParallax';
import { useCart } from './CartContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';

type CheckoutStep = 'cart' | 'shipping' | 'payment' | 'confirmation';

interface CheckoutFlowProps {
  onClose: () => void;
}

export function CheckoutFlow({ onClose }: CheckoutFlowProps) {
  const { state, updateQuantity, removeItem } = useCart();
  const [currentStep, setCurrentStep] = React.useState<CheckoutStep>('cart');
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [orderComplete, setOrderComplete] = React.useState(false);
  
  const [shippingData, setShippingData] = React.useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    zipCode: '',
    country: 'Deutschland'
  });

  const [paymentData, setPaymentData] = React.useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardHolder: ''
  });

  const steps = [
    { id: 'cart', label: 'Warenkorb', icon: ShoppingCart },
    { id: 'shipping', label: 'Versand', icon: User },
    { id: 'payment', label: 'Zahlung', icon: CreditCard },
    { id: 'confirmation', label: 'Bestätigung', icon: CheckCircle }
  ];

  const currentStepIndex = steps.findIndex(step => step.id === currentStep);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  };

  const nextStep = () => {
    const nextIndex = currentStepIndex + 1;
    if (nextIndex < steps.length) {
      setCurrentStep(steps[nextIndex].id as CheckoutStep);
    }
  };

  const prevStep = () => {
    const prevIndex = currentStepIndex - 1;
    if (prevIndex >= 0) {
      setCurrentStep(steps[prevIndex].id as CheckoutStep);
    }
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsProcessing(false);
    setOrderComplete(true);
    setCurrentStep('confirmation');
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 'cart':
        return state.items.length > 0;
      case 'shipping':
        return Object.values(shippingData).every(value => value.trim() !== '');
      case 'payment':
        return Object.values(paymentData).every(value => value.trim() !== '');
      default:
        return true;
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      />

      {/* Checkout Modal */}
      <motion.div
        className="relative w-full max-w-4xl max-h-[90vh] mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Checkout</h1>
            <MotionButton
              variant="outline"
              size="sm"
              onClick={onClose}
              className="text-white border-white/20 hover:bg-white/10"
            >
              ×
            </MotionButton>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = currentStepIndex === index;
              const isCompleted = currentStepIndex > index;
              const isNext = currentStepIndex + 1 === index;

              return (
                <React.Fragment key={step.id}>
                  <motion.div
                    className="flex flex-col items-center"
                    whileHover={{ scale: 1.05 }}
                  >
                    <motion.div
                      className={`
                        w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all
                        ${isCompleted 
                          ? 'bg-green-500 border-green-500 text-white' 
                          : isActive 
                            ? 'bg-cyan-500 border-cyan-500 text-white' 
                            : isNext
                              ? 'border-cyan-400 text-cyan-400 bg-cyan-400/10'
                              : 'border-white/30 text-white/50'
                        }
                      `}
                      animate={isActive ? { scale: [1, 1.1, 1] } : { scale: 1 }}
                      transition={{ duration: 0.5 }}
                    >
                      <StepIcon className="w-5 h-5" />
                    </motion.div>
                    <span className={`text-xs mt-2 ${isActive ? 'text-cyan-300' : 'text-white/70'}`}>
                      {step.label}
                    </span>
                  </motion.div>

                  {index < steps.length - 1 && (
                    <motion.div
                      className="flex-1 h-0.5 mx-4 bg-white/20 overflow-hidden"
                      initial={{ scaleX: 0 }}
                      animate={{ 
                        scaleX: currentStepIndex > index ? 1 : 0,
                        backgroundColor: currentStepIndex > index ? '#10b981' : 'rgba(255,255,255,0.2)'
                      }}
                      transition={{ duration: 0.5 }}
                      style={{ originX: 0 }}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <AnimatePresence mode="wait">
            {currentStep === 'cart' && (
              <MotionScrollReveal key="cart-step" direction="up">
                <div className="space-y-4">
                  <h2 className="text-xl font-semibold mb-4">Deine Bestellung</h2>
                  
                  <MotionStaggerContainer staggerDelay={0.1} className="space-y-3">
                    {state.items.map((item) => (
                      <motion.div
                        key={`${item.id}-${item.size}-${item.color}`}
                        className="flex items-center gap-4 p-4 border rounded-lg hover:shadow-md transition-shadow"
                        whileHover={{ scale: 1.02 }}
                      >
                        <div className="w-16 h-16 rounded-lg overflow-hidden">
                          <ImageWithFallback
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium text-slate-900">{item.name}</h3>
                          <p className="text-sm text-slate-600">{item.category}</p>
                          {(item.size || item.color) && (
                            <div className="flex gap-2 mt-1">
                              {item.size && (
                                <span className="text-xs px-2 py-1 bg-slate-100 rounded">
                                  {item.size}
                                </span>
                              )}
                              {item.color && (
                                <span className="text-xs px-2 py-1 bg-slate-100 rounded">
                                  {item.color}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-slate-600">Menge: {item.quantity}</span>
                          <span className="font-semibold text-slate-900">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </MotionStaggerContainer>

                  {/* Summary */}
                  <motion.div
                    className="bg-slate-50 p-4 rounded-lg border-t-4 border-cyan-500"
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold">Gesamtsumme:</span>
                      <span className="text-2xl font-bold text-cyan-600">
                        {formatPrice(state.total)}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mt-2">
                      Inkl. MwSt. • Versandkosten werden im nächsten Schritt berechnet
                    </p>
                  </motion.div>
                </div>
              </MotionScrollReveal>
            )}

            {currentStep === 'shipping' && (
              <MotionScrollReveal key="shipping-step" direction="up">
                <div className="space-y-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center">
                      <Truck className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold">Versandinformationen</h2>
                      <p className="text-slate-600">Wo sollen wir deine Bestellung hinschicken?</p>
                    </div>
                  </div>

                  <MotionStaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Vorname</label>
                      <input
                        type="text"
                        value={shippingData.firstName}
                        onChange={(e) => setShippingData({...shippingData, firstName: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="Max"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Nachname</label>
                      <input
                        type="text"
                        value={shippingData.lastName}
                        onChange={(e) => setShippingData({...shippingData, lastName: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="Mustermann"
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-slate-700 mb-2">E-Mail</label>
                      <input
                        type="email"
                        value={shippingData.email}
                        onChange={(e) => setShippingData({...shippingData, email: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="max@beispiel.de"
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-slate-700 mb-2">Adresse</label>
                      <input
                        type="text"
                        value={shippingData.address}
                        onChange={(e) => setShippingData({...shippingData, address: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="Musterstraße 123"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Stadt</label>
                      <input
                        type="text"
                        value={shippingData.city}
                        onChange={(e) => setShippingData({...shippingData, city: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="Berlin"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">PLZ</label>
                      <input
                        type="text"
                        value={shippingData.zipCode}
                        onChange={(e) => setShippingData({...shippingData, zipCode: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="10115"
                      />
                    </div>
                  </MotionStaggerContainer>
                </div>
              </MotionScrollReveal>
            )}

            {currentStep === 'payment' && (
              <MotionScrollReveal key="payment-step" direction="up">
                <div className="space-y-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold">Zahlungsinformationen</h2>
                      <p className="text-slate-600">Sichere Zahlung mit SSL-Verschlüsselung</p>
                    </div>
                  </div>

                  <MotionStaggerContainer staggerDelay={0.1} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Karteninhaber</label>
                      <div className="relative">
                        <input
                          type="text"
                          value={paymentData.cardHolder}
                          onChange={(e) => setPaymentData({...paymentData, cardHolder: e.target.value})}
                          className="w-full px-4 py-2 pl-10 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                          placeholder="Max Mustermann"
                        />
                        <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Kartennummer</label>
                      <div className="relative">
                        <input
                          type="text"
                          value={paymentData.cardNumber}
                          onChange={(e) => setPaymentData({...paymentData, cardNumber: e.target.value})}
                          className="w-full px-4 py-2 pl-10 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                          placeholder="1234 5678 9012 3456"
                        />
                        <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Gültig bis</label>
                        <div className="relative">
                          <input
                            type="text"
                            value={paymentData.expiryDate}
                            onChange={(e) => setPaymentData({...paymentData, expiryDate: e.target.value})}
                            className="w-full px-4 py-2 pl-10 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                            placeholder="MM/YY"
                          />
                          <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">CVV</label>
                        <div className="relative">
                          <input
                            type="text"
                            value={paymentData.cvv}
                            onChange={(e) => setPaymentData({...paymentData, cvv: e.target.value})}
                            className="w-full px-4 py-2 pl-10 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                            placeholder="123"
                          />
                          <Shield className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        </div>
                      </div>
                    </div>
                  </MotionStaggerContainer>

                  {/* Security Notice */}
                  <motion.div
                    className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Lock className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="text-sm font-medium text-green-800">SSL-verschlüsselt</p>
                      <p className="text-xs text-green-600">Deine Zahlungsdaten sind sicher geschützt</p>
                    </div>
                  </motion.div>
                </div>
              </MotionScrollReveal>
            )}

            {currentStep === 'confirmation' && (
              <MotionScrollReveal key="confirmation-step" direction="up">
                <div className="text-center space-y-6">
                  <motion.div
                    className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 300, delay: 0.2 }}
                  >
                    <CheckCircle className="w-12 h-12 text-green-600" />
                  </motion.div>
                  
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">
                      Bestellung erfolgreich!
                    </h2>
                    <p className="text-slate-600">
                      Vielen Dank für deine Bestellung. Du erhältst eine Bestätigungsemail in Kürze.
                    </p>
                  </div>

                  <motion.div
                    className="bg-slate-50 p-6 rounded-lg text-left max-w-md mx-auto"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    <h3 className="font-semibold mb-4">Bestellzusammenfassung:</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Artikel:</span>
                        <span>{state.itemCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Gesamtsumme:</span>
                        <span className="font-semibold">{formatPrice(state.total)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Versand an:</span>
                        <span>{shippingData.city}</span>
                      </div>
                    </div>
                  </motion.div>

                  <MotionButton
                    variant="tech"
                    size="lg"
                    onClick={onClose}
                    className="w-full max-w-xs mx-auto"
                  >
                    Fertig
                  </MotionButton>
                </div>
              </MotionScrollReveal>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Navigation */}
        {currentStep !== 'confirmation' && (
          <motion.div
            className="flex justify-between items-center p-6 bg-slate-50 border-t"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <MotionButton
              variant="outline"
              onClick={currentStepIndex > 0 ? prevStep : onClose}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              {currentStepIndex > 0 ? 'Zurück' : 'Abbrechen'}
            </MotionButton>

            <div className="flex items-center gap-4">
              {currentStep !== 'payment' ? (
                <MotionButton
                  variant="tech"
                  onClick={nextStep}
                  disabled={!isStepValid()}
                >
                  Weiter
                  <ArrowRight className="w-4 h-4 ml-2" />
                </MotionButton>
              ) : (
                <MotionButton
                  variant="tech"
                  onClick={handlePayment}
                  disabled={!isStepValid() || isProcessing}
                  className="min-w-[160px]"
                >
                  {isProcessing ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                    />
                  ) : (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      Jetzt bezahlen
                    </>
                  )}
                </MotionButton>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}