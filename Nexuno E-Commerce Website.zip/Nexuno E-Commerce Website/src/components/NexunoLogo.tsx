import React from 'react';
import nexunoLogo from 'figma:asset/dc274090c09a9c81d77ec4f6306cfa2f84599213.png';

interface NexunoLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'default' | 'transparent' | 'glow';
  onClick?: () => void;
  className?: string;
}

export function NexunoLogo({ 
  size = 'md', 
  variant = 'transparent',
  onClick,
  className = '' 
}: NexunoLogoProps) {
  
  const sizeClasses = {
    sm: 'h-8', // 32px
    md: 'h-12', // 48px  
    lg: 'h-16', // 64px
    xl: 'h-20'  // 80px
  };

  const getLogoStyle = () => {
    const baseStyle: React.CSSProperties = {
      height: 'auto',
      maxWidth: '100%',
      transition: 'all 0.3s ease',
    };

    switch (variant) {
      case 'transparent':
        return {
          ...baseStyle,
          // Mache den grauen Hintergrund transparent
          background: 'transparent',
          mixBlendMode: 'multiply' as const,
          filter: 'brightness(1.1) contrast(1.2)',
          // Entferne grauen Hintergrund durch CSS-Tricks
          maskImage: 'linear-gradient(to bottom, black 0%, black 100%)',
          WebkitMaskImage: 'linear-gradient(to bottom, black 0%, black 100%)',
        };
      
      case 'glow':
        return {
          ...baseStyle,
          filter: 'brightness(1.1) contrast(1.2) drop-shadow(0 0 20px rgba(30, 58, 138, 0.4)) drop-shadow(0 0 40px rgba(6, 182, 212, 0.2))',
          mixBlendMode: 'multiply' as const,
        };
      
      default:
        return baseStyle;
    }
  };

  const containerStyle: React.CSSProperties = {
    display: 'inline-block',
    background: variant === 'transparent' ? 'transparent' : undefined,
    borderRadius: '12px',
    padding: variant === 'transparent' ? '0' : '4px',
  };

  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={`relative group transition-all duration-300 hover:scale-105 ${className}`}
        style={containerStyle}
      >
        <img
          src={nexunoLogo}
          alt="Nexuno - Fashion der Zukunft"
          className={`${sizeClasses[size]} object-contain`}
          style={getLogoStyle()}
        />
        
        {/* Subtle Hover Glow */}
        <div 
          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(30, 58, 138, 0.1) 0%, transparent 70%)',
            filter: 'blur(8px)',
            transform: 'scale(1.2)'
          }}
        />
      </button>
    );
  }

  return (
    <div className={`${className}`} style={containerStyle}>
      <img
        src={nexunoLogo}
        alt="Nexuno - Fashion der Zukunft"
        className={`${sizeClasses[size]} object-contain`}
        style={getLogoStyle()}
      />
    </div>
  );
}

// Verschiedene vorgefertigte Logo-Varianten
export function NexunoLogoSmall({ onClick }: { onClick?: () => void }) {
  return <NexunoLogo size="sm" variant="transparent" onClick={onClick} />;
}

export function NexunoLogoMedium({ onClick }: { onClick?: () => void }) {
  return <NexunoLogo size="md" variant="transparent" onClick={onClick} />;
}

export function NexunoLogoLarge({ onClick }: { onClick?: () => void }) {
  return <NexunoLogo size="lg" variant="transparent" onClick={onClick} />;
}

export function NexunoLogoGlow({ size = 'md', onClick }: { size?: 'sm' | 'md' | 'lg' | 'xl', onClick?: () => void }) {
  return <NexunoLogo size={size} variant="glow" onClick={onClick} />;
}

// Hero-Version mit speziellen Effekten
export function NexunoLogoHero({ onClick }: { onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="relative group transition-all duration-500 hover:scale-110"
      style={{
        background: 'transparent',
        border: 'none',
        padding: '8px',
        borderRadius: '16px',
      }}
    >
      <img
        src={nexunoLogo}
        alt="Nexuno - Fashion der Zukunft"
        className="h-16 object-contain transition-all duration-500"
        style={{
          filter: 'brightness(1.2) contrast(1.3) drop-shadow(0 0 20px rgba(30, 58, 138, 0.3))',
          mixBlendMode: 'multiply',
        }}
      />
      
      {/* Advanced Hover Effects */}
      <div 
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 pointer-events-none"
        style={{
          background: 'linear-gradient(135deg, rgba(30, 58, 138, 0.1) 0%, rgba(6, 182, 212, 0.05) 100%)',
          filter: 'blur(12px)',
          transform: 'scale(1.3)',
          animation: 'pulse 2s ease-in-out infinite'
        }}
      />
      
      {/* Animated Border */}
      <div 
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-60 transition-all duration-500 pointer-events-none"
        style={{
          background: 'linear-gradient(45deg, transparent 30%, rgba(6, 182, 212, 0.3) 50%, transparent 70%)',
          backgroundSize: '200% 200%',
          animation: 'gradient-shift 3s ease-in-out infinite',
        }}
      />
    </button>
  );
}