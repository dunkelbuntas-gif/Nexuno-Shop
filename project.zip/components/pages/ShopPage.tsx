import { useState } from 'react';
import { Filter, Grid, List, SlidersHorizontal } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Checkbox } from '../ui/checkbox';
import { Slider } from '../ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ProductGrid } from '../ProductGrid';
import { BackButton } from '../BackButton';
import type { Page } from '../../App';

interface ShopPageProps {
  onNavigate: (page: Page, productId?: string) => void;
}

export function ShopPage({ onNavigate }: ShopPageProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [priceRange, setPriceRange] = useState([0, 150]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('newest');

  const categories = [
    { id: 'tshirts', label: 'T-Shirts', count: 24 },
    { id: 'hoodies', label: 'Hoodies', count: 18 },
    { id: 'accessories', label: 'Accessories', count: 12 },
  ];

  const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
  const colors = [
    { name: 'Schwarz', hex: '#000000' },
    { name: 'Weiß', hex: '#FFFFFF' },
    { name: 'Grau', hex: '#6B7280' },
    { name: 'Neon Cyan', hex: 'var(--neon-cyan)' },
    { name: 'Neon Magenta', hex: 'var(--neon-magenta)' },
    { name: 'Neon Violett', hex: 'var(--neon-violet)' },
  ];

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleSize = (size: string) => {
    setSelectedSizes(prev => 
      prev.includes(size) 
        ? prev.filter(s => s !== size)
        : [...prev, size]
    );
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      {/* Hero Section - Minimalist */}
      <section className="py-24 border-b border-[var(--border-light)]" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-[var(--text-headline)] mb-6 font-['Poppins'] tracking-tight">
            <span className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent">
              Shop
            </span>
          </h1>
          <p className="text-xl text-[var(--text-body)] max-w-2xl mx-auto font-['Inter'] leading-relaxed">
            Die komplette Nexuno Kollektion – minimalistisch designt für die Zukunft
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <BackButton />
        </div>
        
        {/* Controls Bar - Clean Design */}
        <div className="flex flex-col lg:flex-row justify-between items-center gap-4 mb-12">
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 glass-card border-white/30 hover:border-[var(--primary-blue)] hover:glow-subtle"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filter
            </Button>
            
            <div className="flex items-center glass-card border border-white/30 rounded-lg p-1">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className={viewMode === 'grid' ? 'bg-[var(--primary-blue)] text-white' : ''}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'bg-[var(--primary-blue)] text-white' : ''}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-[var(--text-body)] font-['Inter'] text-sm">54 Produkte</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48 glass-card border-white/30 hover:border-[var(--primary-blue)] focus:border-[var(--primary-blue)] focus:glow-subtle">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-card">
                <SelectItem value="newest">Neueste zuerst</SelectItem>
                <SelectItem value="price-low">Preis: Niedrig zu Hoch</SelectItem>
                <SelectItem value="price-high">Preis: Hoch zu Niedrig</SelectItem>
                <SelectItem value="popular">Beliebteste</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar - Glass Design */}
          <div className={`lg:w-80 space-y-6 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            {/* Categories */}
            <Card className="glass-card border-white/30 glow-subtle">
              <CardHeader>
                <CardTitle className="text-[var(--text-headline)] font-['Poppins']">Kategorien</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={category.id}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={() => toggleCategory(category.id)}
                        className="border-[var(--primary-blue)] data-[state=checked]:bg-[var(--primary-blue)]"
                      />
                      <label htmlFor={category.id} className="text-sm font-medium cursor-pointer text-[var(--text-body)] font-['Inter']">
                        {category.label}
                      </label>
                    </div>
                    <span className="text-xs text-[var(--text-muted)] font-['Inter']">({category.count})</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Price Range */}
            <Card className="glass-card border-white/30 glow-subtle">
              <CardHeader>
                <CardTitle className="text-[var(--text-headline)] font-['Poppins']">Preis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={150}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-[var(--text-body)] font-['Inter']">
                    <span>€{priceRange[0]}</span>
                    <span>€{priceRange[1]}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sizes */}
            <Card className="glass-card border-white/30 glow-subtle">
              <CardHeader>
                <CardTitle className="text-[var(--text-headline)] font-['Poppins']">Größen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {sizes.map((size) => (
                    <Button
                      key={size}
                      variant={selectedSizes.includes(size) ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => toggleSize(size)}
                      className={selectedSizes.includes(size) 
                        ? 'bg-[var(--primary-blue)] hover:bg-[var(--accent-bright)] text-white border-[var(--primary-blue)]' 
                        : 'border-white/30 hover:border-[var(--primary-blue)] hover:bg-white/20'
                      }
                    >
                      {size}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Colors */}
            <Card className="glass-card border-white/30 glow-subtle">
              <CardHeader>
                <CardTitle className="text-[var(--text-headline)] font-['Poppins']">Farben</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-3">
                  {colors.map((color) => (
                    <button
                      key={color.name}
                      className="w-10 h-10 rounded-lg border-2 border-white/30 hover:border-[var(--primary-blue)] transition-all duration-300 hover:glow-subtle"
                      style={{ backgroundColor: color.hex === 'var(--neon-cyan)' ? '#06B6D4' : color.hex === 'var(--neon-magenta)' ? '#1E3A8A' : color.hex === 'var(--neon-violet)' ? '#3B82F6' : color.hex }}
                      title={color.name}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Products */}
          <div className="flex-1">
            <ProductGrid onProductClick={(id) => onNavigate('product', id)} />
          </div>
        </div>
      </div>
    </div>
  );
}