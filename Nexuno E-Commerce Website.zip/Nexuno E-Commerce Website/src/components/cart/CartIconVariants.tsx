import { Package, Layers3, Briefcase, Archive, Container, Box, Hexagon, Cube, ShoppingCart, ShoppingBag } from 'lucide-react';
import { useCart } from './CartContext';
import { motion } from 'motion/react';
import { useState } from 'react';

// Verschiedene futuristische Cart-Icon-Varianten
export const CART_ICON_VARIANTS = {
  // Architektonisch & 3D
  layers: { icon: Layers3, name: '3D Layers', theme: 'architectural' },
  cube: { icon: Cube, name: '3D Cube', theme: 'geometric' },
  hexagon: { icon: Hexagon, name: 'Hexagon', theme: 'geometric' },
  
  // Container & Packaging
  package: { icon: Package, name: 'Package', theme: 'delivery' },
  box: { icon: Box, name: 'Box', theme: 'delivery' },
  container: { icon: Container, name: 'Container', theme: 'industrial' },
  archive: { icon: Archive, name: 'Archive', theme: 'storage' },
  
  // Business & Premium
  briefcase: { icon: Briefcase, name: 'Briefcase', theme: 'premium' },
  
  // Klassisch
  cart: { icon: ShoppingCart, name: 'Cart', theme: 'classic' },
  bag: { icon: ShoppingBag, name: 'Shopping Bag', theme: 'classic' },
};

interface CartIconAdvancedProps {
  variant?: keyof typeof CART_ICON_VARIANTS;
  size?: number;
  glowIntensity?: 'subtle' | 'normal' | 'intense';
  style?: 'minimal' | 'glassmorphism' | 'neon' | 'architectural';
}

export function CartIconAdvanced({ 
  variant = 'layers', 
  size = 22,
  glowIntensity = 'normal',
  style = 'glassmorphism'
}: CartIconAdvancedProps) {
  const { state, toggleCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  
  const iconConfig = CART_ICON_VARIANTS[variant];
  const IconComponent = iconConfig.icon;

  // Style-spezifische Konfigurationen
  const styleConfigs = {
    minimal: {
      background: isHovered 
        ? 'rgba(255, 255, 255, 0.1)' 
        : 'rgba(255, 255, 255, 0.05)',
      border: isHovered 
        ? '1px solid rgba(96, 165, 250, 0.3)' 
        : '1px solid rgba(255, 255, 255, 0.1)',
      boxShadow: isHovered 
        ? '0 4px 16px rgba(96, 165, 250, 0.15)' 
        : 'none'
    },
    glassmorphism: {
      background: isHovered 
        ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.25) 0%, rgba(96, 165, 250, 0.15) 100%)'
        : 'linear-gradient(135deg, rgba(255, 255, 255, 0.15) 0%, rgba(248, 250, 252, 0.1) 100%)',
      border: isHovered 
        ? '1px solid rgba(96, 165, 250, 0.4)' 
        : '1px solid rgba(255, 255, 255, 0.2)',
      boxShadow: isHovered 
        ? '0 8px 32px rgba(96, 165, 250, 0.2), 0 0 20px rgba(34, 211, 238, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)'
        : '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.8)'
    },
    neon: {
      background: isHovered 
        ? 'rgba(30, 58, 138, 0.2)' 
        : 'rgba(15, 23, 42, 0.8)',
      border: isHovered 
        ? '1px solid rgba(6, 182, 212, 0.8)' 
        : '1px solid rgba(96, 165, 250, 0.4)',
      boxShadow: isHovered 
        ? '0 0 20px rgba(6, 182, 212, 0.6), 0 0 40px rgba(96, 165, 250, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.1)'
        : '0 0 10px rgba(96, 165, 250, 0.3)'
    },
    architectural: {
      background: isHovered 
        ? 'linear-gradient(135deg, rgba(248, 250, 252, 0.95) 0%, rgba(226, 232, 240, 0.9) 100%)'
        : 'rgba(255, 255, 255, 0.9)',
      border: isHovered 
        ? '2px solid rgba(30, 58, 138, 0.6)' 
        : '1px solid rgba(203, 213, 225, 0.8)',
      boxShadow: isHovered 
        ? '0 12px 48px rgba(30, 58, 138, 0.15), 0 4px 16px rgba(6, 182, 212, 0.1)'
        : '0 4px 20px rgba(0, 0, 0, 0.08)'
    }
  };

  const currentStyle = styleConfigs[style];

  // Glow-Intensitäten
  const glowConfigs = {
    subtle: {
      iconFilter: 'drop-shadow(0 0 4px rgba(96, 165, 250, 0.3))',
      ambientOpacity: 0.3
    },
    normal: {
      iconFilter: 'drop-shadow(0 0 8px rgba(96, 165, 250, 0.6)) drop-shadow(0 0 16px rgba(34, 211, 238, 0.4))',
      ambientOpacity: 0.5
    },
    intense: {
      iconFilter: 'drop-shadow(0 0 12px rgba(96, 165, 250, 0.8)) drop-shadow(0 0 24px rgba(34, 211, 238, 0.6)) drop-shadow(0 0 32px rgba(59, 130, 246, 0.4))',
      ambientOpacity: 0.8
    }
  };

  const currentGlow = glowConfigs[glowIntensity];

  return (
    <motion.button
      onClick={toggleCart}
      className="relative group"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Hauptcontainer */}
      <motion.div
        className="relative p-3 rounded-xl backdrop-blur-20 transition-all duration-500"
        style={currentStyle}
        animate={{
          rotateY: isHovered && style === 'glassmorphism' ? 10 : 0,
          rotateX: isHovered && style === 'glassmorphism' ? -5 : 0,
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        {/* Holografische Reflektion - nur bei glassmorphism */}
        {style === 'glassmorphism' && (
          <motion.div
            className="absolute inset-0 rounded-xl pointer-events-none"
            style={{
              background: 'linear-gradient(135deg, transparent 0%, rgba(96, 165, 250, 0.1) 25%, transparent 50%, rgba(34, 211, 238, 0.1) 75%, transparent 100%)',
              opacity: isHovered ? 0.8 : 0
            }}
            animate={{ opacity: isHovered ? [0, 0.8, 0] : 0 }}
            transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
          />
        )}
        
        {/* Icon mit Glow-Effekt */}
        <motion.div
          className="relative z-10"
          animate={{
            rotateY: isHovered && style === 'glassmorphism' ? -10 : 0,
            scale: isHovered ? 1.1 : 1
          }}
          transition={{ duration: 0.3 }}
        >
          <IconComponent 
            size={size} 
            className="transition-all duration-300"
            style={{
              color: isHovered 
                ? (style === 'neon' ? '#00F5FF' : 'var(--primary-blue)')
                : (style === 'neon' ? '#60A5FA' : 'var(--text-headline)'),
              filter: isHovered ? currentGlow.iconFilter : 'none'
            }}
          />
        </motion.div>

        {/* Architektonische Ecken-Details - nur bei architectural und glassmorphism */}
        {(style === 'architectural' || style === 'glassmorphism') && (
          <>
            <div className="absolute top-1 left-1 w-2 h-2 border-l border-t border-blue-300/30 rounded-tl-sm" />
            <div className="absolute top-1 right-1 w-2 h-2 border-r border-t border-blue-300/30 rounded-tr-sm" />
            <div className="absolute bottom-1 left-1 w-2 h-2 border-l border-b border-cyan-300/30 rounded-bl-sm" />
            <div className="absolute bottom-1 right-1 w-2 h-2 border-r border-b border-cyan-300/30 rounded-br-sm" />
          </>
        )}
        
        {/* Fließender Lichtstrahl bei Hover */}
        {isHovered && style !== 'minimal' && (
          <motion.div
            className={`absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent ${
              style === 'neon' ? 'via-cyan-400/80' : 'via-cyan-400/60'
            } to-transparent`}
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
        )}
      </motion.div>
      
      {/* Counter Badge */}
      {state.itemCount > 0 && (
        <motion.div
          initial={{ scale: 0, rotateZ: -180 }}
          animate={{ scale: 1, rotateZ: 0 }}
          exit={{ scale: 0, rotateZ: 180 }}
          className="absolute -top-2 -right-2 min-w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
          style={{
            background: style === 'neon' 
              ? 'linear-gradient(135deg, #00F5FF 0%, #1E3A8A 100%)'
              : 'linear-gradient(135deg, var(--primary-blue) 0%, var(--accent-cyan) 100%)',
            boxShadow: style === 'neon'
              ? '0 0 16px rgba(0, 245, 255, 0.6), 0 4px 12px rgba(30, 58, 138, 0.4)'
              : '0 4px 12px rgba(30, 58, 138, 0.4), 0 2px 6px rgba(6, 182, 212, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.5)',
            border: '1px solid rgba(255, 255, 255, 0.3)'
          }}
          whileHover={{ scale: 1.1 }}
        >
          <motion.span
            key={state.itemCount}
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            style={{ textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)' }}
          >
            {state.itemCount > 99 ? '99+' : state.itemCount}
          </motion.span>
          
          {/* Pulsierender Ring-Effekt */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-white/30"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.8, 0, 0.8]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </motion.div>
      )}
      
      {/* Ambient Glow Base */}
      <motion.div
        className="absolute inset-0 rounded-xl pointer-events-none"
        style={{
          background: style === 'neon' 
            ? 'radial-gradient(circle, rgba(0, 245, 255, 0.15) 0%, transparent 70%)'
            : 'radial-gradient(circle, rgba(96, 165, 250, 0.1) 0%, transparent 70%)',
          opacity: isHovered ? currentGlow.ambientOpacity : 0,
          filter: 'blur(8px)',
          transform: 'scale(1.5)'
        }}
        animate={{ opacity: isHovered ? currentGlow.ambientOpacity : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  );
}

// Einfache Verwendung für verschiedene Varianten
export function CartIconLayers() {
  return <CartIconAdvanced variant="layers" style="glassmorphism" glowIntensity="normal" />;
}

export function CartIconCube() {
  return <CartIconAdvanced variant="cube" style="architectural" glowIntensity="subtle" />;
}

export function CartIconPackage() {
  return <CartIconAdvanced variant="package" style="minimal" glowIntensity="normal" />;
}

export function CartIconNeon() {
  return <CartIconAdvanced variant="hexagon" style="neon" glowIntensity="intense" />;
}