import React from 'react';
import { ArrowLeft, RotateCcw, Clock, CheckCircle, XCircle } from 'lucide-react';

interface FashionWiderrufsrechtPageProps {
  onBack?: () => void;
}

export function FashionWiderrufsrechtPage({ onBack }: FashionWiderrufsrechtPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="mb-6 flex items-center space-x-2 text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium">Zurück zum Shop</span>
          </button>

          {/* Title */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 text-white rounded-2xl mb-4">
              <RotateCcw className="h-8 w-8" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Widerrufsrecht
            </h1>
            <p className="text-xl text-slate-300">
              14 Tage Rückgaberecht - Einfach und unkompliziert
            </p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="tech-grid-minimal"></div>
        </div>
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <div className="bg-slate-900 rounded-3xl shadow-lg border border-slate-700 p-8 md:p-12">
            
            <div className="space-y-12">
              {/* Widerrufsbelehrung */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-orange-500">
                  Widerrufsbelehrung
                </h2>
                
                <div className="bg-slate-800 rounded-2xl p-6 mb-8">
                  <h3 className="text-xl font-semibold text-slate-200 mb-4 flex items-center">
                    <Clock className="h-6 w-6 mr-3 text-orange-400" />
                    14 Tage Widerrufsrecht
                  </h3>
                  <p className="text-slate-300 leading-relaxed">
                    Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen. 
                    Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter Dritter, 
                    der nicht der Beförderer ist, die letzte Ware in Besitz genommen haben bzw. hat.
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <div className="text-center p-6 bg-slate-800 rounded-2xl">
                    <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="h-6 w-6 text-white" />
                    </div>
                    <h4 className="font-semibold text-slate-200 mb-2">Kostenloser Rückversand</h4>
                    <p className="text-sm text-slate-300">Wir übernehmen die Rücksendekosten</p>
                  </div>
                  
                  <div className="text-center p-6 bg-slate-800 rounded-2xl">
                    <div className="w-12 h-12 bg-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <RotateCcw className="h-6 w-6 text-white" />
                    </div>
                    <h4 className="font-semibold text-slate-200 mb-2">Einfache Abwicklung</h4>
                    <p className="text-sm text-slate-300">Online-Retourenformular verfügbar</p>
                  </div>
                  
                  <div className="text-center p-6 bg-slate-800 rounded-2xl">
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Clock className="h-6 w-6 text-white" />
                    </div>
                    <h4 className="font-semibold text-slate-200 mb-2">Schnelle Erstattung</h4>
                    <p className="text-sm text-slate-300">Rückerstattung binnen 14 Tagen</p>
                  </div>
                </div>
              </div>

              {/* Widerrufsverfahren */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-cyan-500">
                  So einfach funktioniert der Widerruf
                </h2>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-cyan-500 text-white rounded-full flex items-center justify-center font-bold">
                      1
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-200 mb-2">
                        Widerruf mitteilen
                      </h3>
                      <p className="text-slate-300 leading-relaxed">
                        Teilen Sie uns Ihren Widerruf per E-Mail an <strong>widerruf@fashionstore.com</strong> mit 
                        oder nutzen Sie unser Online-Formular. Geben Sie dabei Ihre Bestellnummer an.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-cyan-500 text-white rounded-full flex items-center justify-center font-bold">
                      2
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-200 mb-2">
                        Ware verpacken
                      </h3>
                      <p className="text-slate-300 leading-relaxed">
                        Verpacken Sie die Ware möglichst in der Originalverpackung. Legen Sie den 
                        Retourenschein (falls vorhanden) oder eine Kopie Ihrer Bestellbestätigung bei.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-cyan-500 text-white rounded-full flex items-center justify-center font-bold">
                      3
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-200 mb-2">
                        Paket versenden
                      </h3>
                      <p className="text-slate-300 leading-relaxed">
                        Senden Sie das Paket an unsere Retourenadresse. Wir empfehlen einen versicherten 
                        Versand und bewahren Sie den Versandbeleg auf.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Retourenadresse */}
              <div className="bg-slate-800 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-slate-200 mb-4">
                  Retourenadresse
                </h3>
                <div className="bg-slate-700 border-l-4 border-cyan-500 p-4 rounded">
                  <p className="text-slate-200 font-medium">
                    FashionStore GmbH<br />
                    Retourenabteilung<br />
                    Musterstraße 123<br />
                    10115 Berlin<br />
                    Deutschland
                  </p>
                </div>
              </div>

              {/* Ausschluss vom Widerrufsrecht */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-red-500 flex items-center">
                  <XCircle className="h-6 w-6 mr-3 text-red-500" />
                  Ausschluss vom Widerrufsrecht
                </h2>
                
                <div className="bg-slate-800 rounded-2xl p-6">
                  <p className="text-slate-300 leading-relaxed mb-4">
                    Das Widerrufsrecht besteht nicht bei folgenden Verträgen:
                  </p>
                  
                  <ul className="list-disc list-inside text-slate-300 space-y-2 ml-4">
                    <li>Zur Lieferung von Waren, die nicht vorgefertigt sind und für deren Herstellung eine individuelle Auswahl oder Bestimmung durch den Verbraucher maßgeblich ist</li>
                    <li>Zur Lieferung von Waren, die schnell verderben können oder deren Verfalldatum schnell überschritten würde</li>
                    <li>Zur Lieferung alkoholischer Getränke, deren Preis bei Vertragsschluss vereinbart wurde</li>
                    <li>Zur Lieferung von Zeitungen, Zeitschriften oder Illustrierten</li>
                    <li>Bei Dienstleistungen, wenn der Unternehmer die Dienstleistung vollständig erbracht hat</li>
                  </ul>
                </div>
              </div>

              {/* Kosten und Erstattung */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-emerald-500">
                  Kosten und Erstattung
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-slate-800 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-slate-200 mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2 text-emerald-400" />
                      Kostenübernahme
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Wir übernehmen die Kosten der Rücksendung, wenn die Ware mangelhaft ist oder 
                      Sie unser kostenloses Retourenportal nutzen.
                    </p>
                  </div>
                  
                  <div className="bg-slate-800 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-slate-200 mb-3 flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-cyan-400" />
                      Rückerstattung
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Wir erstatten alle erhaltenen Zahlungen unverzüglich, spätestens binnen 
                      vierzehn Tagen ab dem Tag des Widerrufs.
                    </p>
                  </div>
                </div>
              </div>

              {/* Muster-Widerrufsformular */}
              <div className="bg-slate-800 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-slate-200 mb-4">
                  Muster-Widerrufsformular
                </h3>
                <div className="bg-slate-700 p-6 rounded-lg border-2 border-dashed border-orange-400">
                  <p className="text-slate-300 leading-relaxed">
                    <strong>An:</strong> FashionStore GmbH, Musterstraße 123, 10115 Berlin, widerruf@fashionstore.com<br /><br />
                    
                    Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag über den Kauf der folgenden Waren (*):<br /><br />
                    
                    <em>_________________________________________________</em><br /><br />
                    
                    Bestellt am (*) / erhalten am (*):<br />
                    <em>_________________________________________________</em><br /><br />
                    
                    Name des/der Verbraucher(s):<br />
                    <em>_________________________________________________</em><br /><br />
                    
                    Anschrift des/der Verbraucher(s):<br />
                    <em>_________________________________________________</em><br /><br />
                    
                    Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier):<br />
                    <em>_________________________________________________</em><br /><br />
                    
                    Datum:<br />
                    <em>_________________________________________________</em><br /><br />
                    
                    <small>(*) Unzutreffendes streichen.</small>
                  </p>
                </div>
              </div>

              {/* Kontakt */}
              <div className="text-center bg-slate-800 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-slate-200 mb-4">
                  Fragen zum Widerrufsrecht?
                </h3>
                <p className="text-slate-300 mb-4">
                  Unser Kundenservice hilft Ihnen gerne weiter
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a 
                    href="mailto:widerruf@fashionstore.com" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                  >
                    E-Mail senden
                  </a>
                  <a 
                    href="tel:+493012345678" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-slate-700 text-slate-200 rounded-lg hover:bg-slate-600 transition-colors"
                  >
                    Anrufen: +49 30 12345678
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default FashionWiderrufsrechtPage;