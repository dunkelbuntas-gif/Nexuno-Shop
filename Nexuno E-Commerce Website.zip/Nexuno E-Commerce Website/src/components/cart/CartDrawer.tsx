import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowRight, Star, Shield, Truck, CreditCard } from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Card } from '../ui/card';
import { toast } from 'sonner@2.0.3';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout?: () => void;
  variant?: 'bottom' | 'top';
}

export function CartDrawer({ isOpen, onClose, onCheckout, variant = 'bottom' }: CartDrawerProps) {
  const { state, removeItem, updateQuantity, clearCart } = useCart();

  const handleRemoveItem = (id: string, size?: string, color?: string, name?: string) => {
    removeItem(id, size, color);
    toast.success(`${name || 'Artikel'} wurde entfernt`);
  };

  const handleUpdateQuantity = (id: string, quantity: number, size?: string, color?: string) => {
    updateQuantity(id, quantity, size, color);
  };

  const handleCheckout = () => {
    if (state.items.length === 0) {
      toast.error('Ihr Warenkorb ist leer');
      return;
    }
    onCheckout?.();
    onClose();
  };

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const subtotal = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);
  const shipping = subtotal > 69 ? 0 : 4.99;
  const total = subtotal + shipping;

  const slideDirection = {
    bottom: {
      initial: { y: '100%' },
      animate: { y: 0 },
      exit: { y: '100%' }
    },
    top: {
      initial: { y: '-100%' },
      animate: { y: 0 },
      exit: { y: '-100%' }
    }
  };

  const positionClasses = {
    bottom: 'bottom-0 rounded-t-2xl',
    top: 'top-0 rounded-b-2xl'
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            initial={slideDirection[variant].initial}
            animate={slideDirection[variant].animate}
            exit={slideDirection[variant].exit}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className={`fixed left-0 right-0 ${positionClasses[variant]} max-h-[80vh] bg-white/95 backdrop-blur-xl border-t border-white/20 shadow-2xl z-50 flex flex-col mx-4`}
          >
            {/* Handle Bar */}
            <div className="flex justify-center py-3">
              <div className="w-12 h-1 bg-gray-300 rounded-full" />
            </div>

            {/* Header */}
            <div className="px-6 pb-4 border-b border-gray-200/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-xl">
                    <ShoppingBag className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-gray-900">Warenkorb</h2>
                    <p className="text-sm text-gray-600">
                      {state.itemCount} {state.itemCount === 1 ? 'Artikel' : 'Artikel'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  aria-label="Warenkorb schließen"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden">
              {state.items.length === 0 ? (
                /* Empty State */
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <ShoppingBag className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Ihr Warenkorb ist leer
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Entdecken Sie unsere Fashion-Kollektionen
                  </p>
                  <Button
                    onClick={onClose}
                    className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                  >
                    Jetzt shoppen
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
                  {/* Cart Items */}
                  <div className="lg:col-span-2 space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                    <AnimatePresence mode="popLayout">
                      {state.items.map((item, index) => (
                        <motion.div
                          key={`${item.id}-${item.size}-${item.color}`}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95, height: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="p-4 bg-white/80 backdrop-blur-sm border-gray-200/50 hover:shadow-md transition-all duration-300">
                            <div className="flex gap-4">
                              {/* Product Image */}
                              <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                                <img
                                  src={item.image}
                                  alt={item.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>

                              {/* Product Details */}
                              <div className="flex-1 min-w-0">
                                <h4 className="font-semibold text-gray-900 text-sm truncate mb-1">
                                  {item.name}
                                </h4>
                                <div className="flex items-center gap-1 mb-2">
                                  {item.size && (
                                    <Badge variant="outline" className="text-xs px-1.5 py-0.5">
                                      {item.size}
                                    </Badge>
                                  )}
                                  {item.color && (
                                    <Badge variant="outline" className="text-xs px-1.5 py-0.5">
                                      {item.color}
                                    </Badge>
                                  )}
                                </div>
                                
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-1">
                                    <button
                                      onClick={() => handleUpdateQuantity(item.id, item.quantity - 1, item.size, item.color)}
                                      className="w-6 h-6 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                      disabled={item.quantity <= 1}
                                    >
                                      <Minus className="w-3 h-3" />
                                    </button>
                                    <span className="w-8 text-center text-sm font-medium">
                                      {item.quantity}
                                    </span>
                                    <button
                                      onClick={() => handleUpdateQuantity(item.id, item.quantity + 1, item.size, item.color)}
                                      className="w-6 h-6 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                    >
                                      <Plus className="w-3 h-3" />
                                    </button>
                                  </div>

                                  <div className="text-right">
                                    <p className="font-semibold text-sm text-gray-900">
                                      {formatPrice(getItemTotal(item.price, item.quantity))}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              {/* Remove Button */}
                              <button
                                onClick={() => handleRemoveItem(item.id, item.size, item.color, item.name)}
                                className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                                aria-label="Artikel entfernen"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </Card>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  {/* Summary Sidebar */}
                  <div className="lg:col-span-1">
                    <Card className="p-6 bg-gradient-to-b from-white/90 to-gray-50/90 backdrop-blur-sm border-gray-200/50 sticky top-0">
                      <h3 className="font-semibold text-gray-900 mb-4">Bestellübersicht</h3>
                      
                      {/* Price Breakdown */}
                      <div className="space-y-3 mb-6">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Zwischensumme</span>
                          <span className="text-gray-900">{formatPrice(subtotal)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Versand</span>
                          <span className="text-gray-900">
                            {shipping === 0 ? 'Kostenlos' : formatPrice(shipping)}
                          </span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-semibold">
                          <span className="text-gray-900">Gesamt</span>
                          <span className="text-gray-900">{formatPrice(total)}</span>
                        </div>
                      </div>

                      {/* Shipping Progress */}
                      {shipping > 0 && (
                        <div className="mb-6 p-3 bg-cyan-50 rounded-lg border border-cyan-200">
                          <div className="flex items-center gap-2 mb-2">
                            <Truck className="w-4 h-4 text-cyan-600" />
                            <span className="text-sm font-medium text-cyan-800">
                              Noch €{(69 - subtotal).toFixed(2)} für kostenlosen Versand
                            </span>
                          </div>
                          <div className="w-full bg-cyan-200 rounded-full h-2">
                            <div 
                              className="bg-cyan-500 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${Math.min((subtotal / 69) * 100, 100)}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Action Button */}
                      <Button
                        onClick={handleCheckout}
                        className="w-full h-12 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                      >
                        <CreditCard className="w-5 h-5 mr-2" />
                        Zur Kasse
                      </Button>

                      {/* Trust Badges */}
                      <div className="mt-6 pt-4 border-t border-gray-200">
                        <div className="grid grid-cols-1 gap-2 text-xs text-gray-600">
                          <div className="flex items-center gap-2">
                            <Shield className="w-3 h-3 text-green-600" />
                            <span>SSL verschlüsselt</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Star className="w-3 h-3 text-yellow-500" />
                            <span>14 Tage Rückgaberecht</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Truck className="w-3 h-3 text-blue-600" />
                            <span>Schneller Versand</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}