import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface PageTransitionProps {
  children: React.ReactNode;
  pageKey: string;
  transitionType?: 'slide' | 'fade' | 'scale' | 'curtain' | 'ripple';
  direction?: 'left' | 'right' | 'up' | 'down';
  duration?: number;
}

export function PageTransition({ 
  children, 
  pageKey,
  transitionType = 'slide',
  direction = 'right',
  duration = 0.5
}: PageTransitionProps) {

  const getTransitionVariants = () => {
    const baseTransition = {
      duration,
      ease: [0.25, 0.25, 0, 1],
    };

    switch (transitionType) {
      case 'slide':
        return {
          initial: {
            x: direction === 'left' ? '-100%' : direction === 'right' ? '100%' : 0,
            y: direction === 'up' ? '-100%' : direction === 'down' ? '100%' : 0,
            opacity: 0,
          },
          animate: {
            x: 0,
            y: 0,
            opacity: 1,
            transition: baseTransition,
          },
          exit: {
            x: direction === 'left' ? '100%' : direction === 'right' ? '-100%' : 0,
            y: direction === 'up' ? '100%' : direction === 'down' ? '-100%' : 0,
            opacity: 0,
            transition: baseTransition,
          },
        };

      case 'fade':
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1, transition: baseTransition },
          exit: { opacity: 0, transition: baseTransition },
        };

      case 'scale':
        return {
          initial: { 
            scale: 0.8, 
            opacity: 0,
            filter: 'blur(10px)',
          },
          animate: { 
            scale: 1, 
            opacity: 1,
            filter: 'blur(0px)',
            transition: baseTransition,
          },
          exit: { 
            scale: 1.2, 
            opacity: 0,
            filter: 'blur(10px)',
            transition: baseTransition,
          },
        };

      case 'curtain':
        return {
          initial: {
            clipPath: 'polygon(0% 50%, 0% 50%, 0% 50%, 0% 50%)',
            opacity: 0,
          },
          animate: {
            clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)',
            opacity: 1,
            transition: { ...baseTransition, duration: duration * 1.2 },
          },
          exit: {
            clipPath: 'polygon(100% 50%, 100% 50%, 100% 50%, 100% 50%)',
            opacity: 0,
            transition: { ...baseTransition, duration: duration * 0.8 },
          },
        };

      case 'ripple':
        return {
          initial: {
            clipPath: 'circle(0% at 50% 50%)',
            opacity: 0,
          },
          animate: {
            clipPath: 'circle(150% at 50% 50%)',
            opacity: 1,
            transition: { ...baseTransition, duration: duration * 1.5 },
          },
          exit: {
            clipPath: 'circle(0% at 50% 50%)',
            opacity: 0,
            transition: { ...baseTransition, duration: duration * 0.8 },
          },
        };

      default:
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1, transition: baseTransition },
          exit: { opacity: 0, transition: baseTransition },
        };
    }
  };

  const variants = getTransitionVariants();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={pageKey}
        initial="initial"
        animate="animate"
        exit="exit"
        variants={variants}
        className="w-full"
      >
        {/* Floating Background Elements during Transition */}
        <motion.div
          className="fixed inset-0 pointer-events-none z-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: duration * 0.5 }}
        >
          {/* Animated Particles */}
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-gradient-to-r from-green-400 to-blue-500 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [-20, -100],
                opacity: [0, 1, 0],
                scale: [0.5, 1, 0.5],
              }}
              transition={{
                duration: duration * 2,
                repeat: 1,
                delay: i * 0.1,
                ease: 'easeOut',
              }}
            />
          ))}
        </motion.div>

        {/* Main Content */}
        <div className="relative z-10">
          {children}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

// Loading Transition Component
export function LoadingTransition({ isLoading, children }: { isLoading: boolean; children: React.ReactNode }) {
  return (
    <AnimatePresence mode="wait">
      {isLoading ? (
        <motion.div
          key="loading"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="flex items-center justify-center min-h-screen bg-gradient-to-br from-white to-gray-50"
        >
          {/* Spinning Logo */}
          <motion.div
            className="relative"
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          >
            <div className="w-16 h-16 border-4 border-green-200 rounded-full">
              <div className="w-full h-full border-t-4 border-green-500 rounded-full animate-spin"></div>
            </div>
          </motion.div>
          
          {/* Loading Text */}
          <motion.div
            className="ml-4 text-gray-600"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            Lädt...
          </motion.div>
        </motion.div>
      ) : (
        <motion.div
          key="content"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}