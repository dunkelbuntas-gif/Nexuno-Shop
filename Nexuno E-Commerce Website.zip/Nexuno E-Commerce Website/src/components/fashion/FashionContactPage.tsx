import React, { useState, useEffect } from 'react';
import { ArrowLeft, Send, Phone, Mail, MapPin, Clock, MessageCircle, User, FileText, Zap, Shield, Award, CheckCircle, X } from 'lucide-react';
import { FashionFAQSection } from './FashionFAQSection';

interface FashionContactPageProps {
  onBack?: () => void;
}

export function FashionContactPage({ onBack }: FashionContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    category: 'general'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showFAQModal, setShowFAQModal] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: '',
        category: 'general'
      });
    }, 3000);
  };

  // FAQ Modal Handlers
  const openFAQModal = () => {
    setShowFAQModal(true);
    document.body.style.overflow = 'hidden'; // Prevent background scroll
  };

  const closeFAQModal = () => {
    setShowFAQModal(false);
    document.body.style.overflow = 'unset'; // Restore scroll
  };

  // Close modal on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && showFAQModal) {
        closeFAQModal();
      }
    };

    if (showFAQModal) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset'; // Cleanup on unmount
    };
  }, [showFAQModal]);

  const contactInfo = [
    {
      icon: <Phone className="h-6 w-6" />,
      title: 'Telefon',
      content: '015678569698',
      description: 'Mo-Fr 9:00-18:00 Uhr',
      link: 'tel:015678569698',
      gradient: 'from-emerald-500 to-teal-600'
    },
    {
      icon: <Mail className="h-6 w-6" />,
      title: 'E-Mail',
      content: 'info@nexuno.eu',
      description: 'Antwort binnen 24h',
      link: 'mailto:info@nexuno.eu',
      gradient: 'from-blue-500 to-cyan-600'
    },
    {
      icon: <MapPin className="h-6 w-6" />,
      title: 'Adresse',
      content: 'Fließstraße 6',
      description: '12439 Berlin',
      link: 'https://maps.google.com/?q=Fließstraße+6,+12439+Berlin',
      gradient: 'from-purple-500 to-violet-600'
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: 'Geschäftszeiten',
      content: 'Mo-Fr 9:00-18:00',
      description: 'Sa 10:00-14:00',
      link: null,
      gradient: 'from-orange-500 to-amber-600'
    }
  ];

  const categories = [
    { value: 'general', label: 'Allgemeine Anfrage' },
    { value: 'support', label: 'Produktsupport' },
    { value: 'orders', label: 'Bestellungen' },
    { value: 'returns', label: 'Rücksendungen' },
    { value: 'business', label: 'Geschäftskunden' },
    { value: 'press', label: 'Presse & Medien' }
  ];

  const quickHelpItems = [
    {
      icon: <MessageCircle className="h-5 w-5" />,
      title: 'FAQ',
      description: 'Antworten auf häufige Fragen',
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      status: 'Verfügbar'
    },
    {
      icon: <Zap className="h-5 w-5" />,
      title: 'Live Chat',
      description: 'Mo-Fr 9:00-18:00 Uhr',
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      status: 'Online'
    },
    {
      icon: <Phone className="h-5 w-5" />,
      title: 'Rückruf Service',
      description: 'Wir rufen Sie gerne zurück',
      color: 'text-purple-500',
      bgColor: 'bg-purple-50',
      status: 'Aktiv'
    }
  ];

  const responseTimeItems = [
    { label: 'E-Mail', time: 'binnen 24h', status: 'excellent' },
    { label: 'Telefon', time: 'sofort', status: 'excellent' },
    { label: 'Live Chat', time: 'binnen 5min', status: 'excellent' },
    { label: 'Support-Ticket', time: 'binnen 48h', status: 'good' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Floating Background Elements - Dark Theme */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 opacity-10">
          <div className="tech-grid-minimal"></div>
        </div>
      </div>

      {/* Header - Dark Fashion Store Design */}
      <header className="relative bg-slate-900 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-6 py-12">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="mb-8 bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-xl hover:scale-105 transition-all duration-300 border border-slate-600 hover:border-cyan-400/40 group"
            aria-label="Zurück zum Shop"
          >
            <div className="flex items-center space-x-3">
              <ArrowLeft className="h-5 w-5 text-slate-300 group-hover:text-cyan-400 transition-colors" />
              <span className="font-medium text-slate-200 group-hover:text-cyan-300 transition-colors">Zurück zum Shop</span>
            </div>
          </button>

          {/* Hero Section */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white mb-6 animate-pulse-slow">
              <MessageCircle className="h-10 w-10" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Wir sind für Sie da
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
              Haben Sie Fragen zu unseren Tech-Fashion Produkten oder benötigen Sie Unterstützung? 
              Unser Expert*innen-Team steht Ihnen gerne zur Verfügung.
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative py-20 bg-slate-950 text-white overflow-hidden isolate">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="tech-grid-minimal"></div>
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          
          {/* Contact Info Cards - Fashion Store Dark Design */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {contactInfo.map((info, index) => (
              <div 
                key={index}
                className="bg-slate-900 rounded-2xl p-8 text-center hover:scale-105 hover:shadow-2xl transition-all duration-500 group border border-slate-700 hover:border-cyan-400/50"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${info.gradient} text-white mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  {info.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">
                  {info.title}
                </h3>
                {info.link ? (
                  <a 
                    href={info.link}
                    target={info.link.startsWith('http') ? '_blank' : undefined}
                    rel={info.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors text-lg group-hover:glow-text"
                  >
                    {info.content}
                  </a>
                ) : (
                  <p className="text-white font-medium text-lg">{info.content}</p>
                )}
                <p className="text-sm text-slate-400 mt-2 group-hover:text-slate-300 transition-colors">{info.description}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Contact Form - Dark Fashion Store Design */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900 rounded-3xl border border-slate-700 p-12 shadow-2xl">
                <div className="mb-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-1 h-12 bg-gradient-to-b from-cyan-500 to-blue-600 rounded-full"></div>
                    <h2 className="text-3xl font-bold text-white">
                      Nachricht senden
                    </h2>
                  </div>
                  <p className="text-slate-300 text-lg leading-relaxed">
                    Füllen Sie das Formular aus und wir melden uns schnellstmöglich bei Ihnen zurück. 
                    Ihre Daten werden selbstverständlich vertraulich behandelt.
                  </p>
                </div>

                {submitted ? (
                  <div className="text-center py-16">
                    <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-emerald-500/20 text-emerald-400 mb-6 animate-scale-in">
                      <CheckCircle className="h-12 w-12" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-4">
                      Nachricht erfolgreich gesendet!
                    </h3>
                    <p className="text-slate-300 text-lg max-w-md mx-auto">
                      Vielen Dank für Ihre Nachricht. Wir melden uns binnen 24 Stunden bei Ihnen zurück.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Category Selection */}
                    <div>
                      <label htmlFor="category" className="block text-lg font-medium text-slate-200 mb-3">
                        Kategorie *
                      </label>
                      <select
                        id="category"
                        name="category"
                        value={formData.category}
                        onChange={handleInputChange}
                        required
                        className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-white hover:border-cyan-400/60"
                      >
                        {categories.map((category) => (
                          <option key={category.value} value={category.value} className="bg-slate-800 text-white">
                            {category.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Name and Email Row */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <label htmlFor="name" className="block text-lg font-medium text-slate-200 mb-3">
                          <User className="inline h-5 w-5 mr-2 text-cyan-400" />
                          Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                          className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-white placeholder-slate-400 hover:border-cyan-400/60"
                          placeholder="Ihr vollständiger Name"
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-lg font-medium text-slate-200 mb-3">
                          <Mail className="inline h-5 w-5 mr-2 text-cyan-400" />
                          E-Mail *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-white placeholder-slate-400 hover:border-cyan-400/60"
                          placeholder="ihre@email.de"
                        />
                      </div>
                    </div>

                    {/* Phone and Subject Row */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <label htmlFor="phone" className="block text-lg font-medium text-slate-200 mb-3">
                          <Phone className="inline h-5 w-5 mr-2 text-cyan-400" />
                          Telefon (optional)
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-white placeholder-slate-400 hover:border-cyan-400/60"
                          placeholder="+49 123 456789"
                        />
                      </div>
                      <div>
                        <label htmlFor="subject" className="block text-lg font-medium text-slate-200 mb-3">
                          <FileText className="inline h-5 w-5 mr-2 text-cyan-400" />
                          Betreff *
                        </label>
                        <input
                          type="text"
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleInputChange}
                          required
                          className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-white placeholder-slate-400 hover:border-cyan-400/60"
                          placeholder="Worum geht es?"
                        />
                      </div>
                    </div>

                    {/* Message */}
                    <div>
                      <label htmlFor="message" className="block text-lg font-medium text-slate-200 mb-3">
                        <MessageCircle className="inline h-5 w-5 mr-2 text-cyan-400" />
                        Nachricht *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        className="w-full px-6 py-4 bg-slate-800 border border-slate-600 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 resize-vertical text-white placeholder-slate-400 hover:border-cyan-400/60"
                        placeholder="Teilen Sie uns Ihr Anliegen mit..."
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="pt-6">
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-5 rounded-xl font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-3 text-lg shadow-lg hover:shadow-2xl hover:scale-[1.02] group"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                            <span>Wird gesendet...</span>
                          </>
                        ) : (
                          <>
                            <Send className="h-6 w-6 group-hover:rotate-12 transition-transform" />
                            <span>Nachricht senden</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Privacy Notice */}
                    <div className="text-sm text-slate-400 pt-6 border-t border-slate-700">
                      <p className="leading-relaxed">
                        Mit dem Absenden stimmen Sie der Verarbeitung Ihrer Daten zur Bearbeitung Ihrer Anfrage zu. 
                        Weitere Informationen finden Sie in unserer{' '}
                        <a href="#" className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2 transition-colors">
                          Datenschutzerklärung
                        </a>.
                      </p>
                    </div>
                  </form>
                )}
              </div>
            </div>

            {/* Dark Themed Sidebar */}
            <div className="space-y-8">
              
              {/* Quick Help Card */}
              <div className="bg-slate-900 rounded-2xl border border-slate-700 p-8 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center gap-3 mb-6">
                  <Zap className="h-6 w-6 text-cyan-400" />
                  <h3 className="text-xl font-bold text-white">
                    Schnelle Hilfe
                  </h3>
                </div>
                <div className="space-y-5">
                  {quickHelpItems.map((item, index) => (
                    <div 
                      key={index} 
                      className="flex items-start space-x-4 p-4 rounded-xl bg-slate-800 hover:bg-slate-700 transition-all duration-300 group cursor-pointer"
                      onClick={item.title === 'FAQ' ? openFAQModal : undefined}
                    >
                      <div className={`p-2 rounded-lg ${item.bgColor} ${item.color} group-hover:scale-110 transition-transform`}>
                        {item.icon}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-semibold text-white">{item.title}</p>
                          <span className="text-xs font-medium text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-full">
                            {item.status}
                          </span>
                        </div>
                        <p className="text-sm text-slate-300">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Company Info Card */}
              <div className="bg-slate-900 rounded-2xl border border-slate-700 p-8 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center gap-3 mb-6">
                  <Award className="h-6 w-6 text-purple-400" />
                  <h3 className="text-xl font-bold text-white">
                    Über Nexuno
                  </h3>
                </div>
                <p className="text-slate-300 leading-relaxed mb-6">
                  André Schumann betreibt einen innovativen Online-Shop für Print-on-Demand und Dropshipping Produkte. 
                  Spezialisiert auf Tech-Fashion und zukunftsweisende Mode-Accessoires.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg">
                    <span className="text-slate-300 font-medium">Geschäftsführer</span>
                    <span className="text-white font-semibold">André Schumann</span>
                  </div>
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg">
                    <span className="text-slate-300 font-medium">Gründung</span>
                    <span className="text-white font-semibold">2025</span>
                  </div>
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg">
                    <span className="text-slate-300 font-medium">Standort</span>
                    <span className="text-white font-semibold">Berlin, DE</span>
                  </div>
                </div>
              </div>

              {/* Response Times Card */}
              <div className="bg-slate-900 rounded-2xl border border-slate-700 p-8 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center gap-3 mb-6">
                  <Shield className="h-6 w-6 text-emerald-400" />
                  <h3 className="text-xl font-bold text-white">
                    Kontakt & Erreichbarkeit
                  </h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                    <span className="text-slate-300 font-medium">E-Mail Anfragen</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-emerald-400">
                        Verfügbar
                      </span>
                      <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                    <span className="text-slate-300 font-medium">Telefonischer Support</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-cyan-400">
                        Auf Anfrage
                      </span>
                      <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-3 px-4 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
                    <span className="text-slate-300 font-medium">Bearbeitungszeit</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-400">
                        Werktags
                      </span>
                      <div className="w-2 h-2 rounded-full bg-slate-500"></div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>

      {/* FAQ Modal */}
      {showFAQModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-300"
            onClick={closeFAQModal}
            aria-hidden="true"
          />
          
          {/* Modal Content */}
          <div 
            className="relative bg-slate-950 rounded-3xl border border-slate-700 shadow-2xl max-h-[90vh] overflow-hidden transition-all duration-300 ease-out transform animate-in fade-in-0 slide-in-from-bottom-4 w-[95vw] md:w-[90vw] lg:w-[80vw] xl:w-[70vw] max-w-6xl"
            role="dialog"
            aria-modal="true"
            aria-labelledby="faq-modal-title"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-slate-700 bg-slate-900">
              <h2 id="faq-modal-title" className="text-2xl font-bold text-white flex items-center gap-3">
                <MessageCircle className="h-6 w-6 text-cyan-400" />
                Häufig gestellte Fragen
              </h2>
              <button
                onClick={closeFAQModal}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-600 hover:border-slate-500"
                aria-label="FAQ schließen"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)] custom-scrollbar">
              <FashionFAQSection />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default FashionContactPage;