import React, { useState, useMemo } from 'react';
import { Search, X, Filter } from 'lucide-react';
import { Product, searchProducts } from '../lib/local-products';
import { CategoryIcon } from './CategoryQuickNav';

interface ProductSearchProps {
  products: Product[];
  onFilteredProducts: (products: Product[]) => void;
  selectedCategory: string;
  className?: string;
}

export function ProductSearch({ 
  products, 
  onFilteredProducts, 
  selectedCategory,
  className = ""
}: ProductSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [priceRange, setPriceRange] = useState<'all' | 'under30' | '30to60' | 'over60'>('all');
  const [sortBy, setSortBy] = useState<'relevance' | 'name' | 'price' | 'rating'>('relevance');

  // Filter and search products
  const filteredProducts = useMemo(() => {
    let filtered = [...products];
    
    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }
    
    // Search query filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query) ||
        product.categoryName.toLowerCase().includes(query) ||
        product.colors.some(color => color.toLowerCase().includes(query))
      );
    }
    
    // Price range filter
    if (priceRange !== 'all') {
      filtered = filtered.filter(product => {
        const price = product.price;
        switch (priceRange) {
          case 'under30': return price < 30;
          case '30to60': return price >= 30 && price <= 60;
          case 'over60': return price > 60;
          default: return true;
        }
      });
    }
    
    // Sort products
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'price':
          return a.price - b.price;
        case 'rating':
          // Fallback rating since we don't have ratings in our data
          return Math.random() - 0.5; // Random sort as fallback
        case 'relevance':
        default:
          // Relevance: exact matches first, then partial matches
          if (searchQuery.trim()) {
            const query = searchQuery.toLowerCase();
            const aExact = a.name.toLowerCase().includes(query) ? 1 : 0;
            const bExact = b.name.toLowerCase().includes(query) ? 1 : 0;
            return bExact - aExact;
          }
          return 0;
      }
    });
    
    return filtered;
  }, [products, selectedCategory, searchQuery, priceRange, sortBy]);

  // Update parent component when filtered products change
  React.useEffect(() => {
    onFilteredProducts(filteredProducts);
  }, [filteredProducts, onFilteredProducts]);

  const clearSearch = () => {
    setSearchQuery('');
    setPriceRange('all');
    setSortBy('relevance');
  };

  const hasActiveFilters = searchQuery.trim() || priceRange !== 'all' || sortBy !== 'relevance';

  const categoryNames: Record<string, string> = {
    tshirts: 'T-Shirts',
    hoodies: 'Hoodies',
    accessories: 'Accessoires',
    activewear: 'Activewear',
    tech: 'Tech',
    prints: 'Prints'
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Main search bar */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="search"
            placeholder="Suche nach Produkten, Kategorien oder Beschreibungen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="
              w-full pl-10 pr-12 py-3 rounded-lg
              bg-white/10 backdrop-blur-lg border border-white/20 
              text-white placeholder-slate-400
              focus:bg-white/15 focus:border-cyan-400/50 focus:outline-none
              transition-all duration-300
            "
            aria-label="Produktsuche"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-10 top-1/2 transform -translate-y-1/2 p-1 hover:bg-white/10 rounded-full transition-colors"
              aria-label="Suchbegriff löschen"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          )}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`
              absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-full transition-all duration-300
              ${showAdvanced 
                ? 'bg-cyan-500/20 text-cyan-400' 
                : 'hover:bg-white/10 text-slate-400'
              }
            `}
            aria-label="Erweiterte Filter"
            aria-expanded={showAdvanced}
          >
            <Filter className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Advanced filters */}
      {showAdvanced && (
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-lg p-4 space-y-4">
          <h3 className="text-sm font-medium text-white flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Erweiterte Filter
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Price range filter */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Preisbereich
              </label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value as any)}
                className="
                  w-full px-3 py-2 rounded-lg
                  bg-white/10 border border-white/20 text-white
                  focus:bg-white/15 focus:border-cyan-400/50 focus:outline-none
                  transition-all duration-300
                "
              >
                <option value="all">Alle Preise</option>
                <option value="under30">Unter €30</option>
                <option value="30to60">€30 - €60</option>
                <option value="over60">Über €60</option>
              </select>
            </div>

            {/* Sort by */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Sortierung
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="
                  w-full px-3 py-2 rounded-lg
                  bg-white/10 border border-white/20 text-white
                  focus:bg-white/15 focus:border-cyan-400/50 focus:outline-none
                  transition-all duration-300
                "
              >
                <option value="relevance">Relevanz</option>
                <option value="name">Name (A-Z)</option>
                <option value="price">Preis (niedrig → hoch)</option>
                <option value="rating">Bewertung (hoch → niedrig)</option>
              </select>
            </div>
          </div>

          {/* Active filters and clear button */}
          {hasActiveFilters && (
            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <div className="flex flex-wrap gap-2">
                {searchQuery.trim() && (
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-cyan-500/20 text-cyan-300">
                    <Search className="w-3 h-3" />
                    "{searchQuery.trim()}"
                  </span>
                )}
                {priceRange !== 'all' && (
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-cyan-500/20 text-cyan-300">
                    €
                    {priceRange === 'under30' && 'unter €30'}
                    {priceRange === '30to60' && '€30-€60'}
                    {priceRange === 'over60' && 'über €60'}
                  </span>
                )}
                {sortBy !== 'relevance' && (
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-cyan-500/20 text-cyan-300">
                    Sortiert nach: {sortBy === 'name' ? 'Name' : sortBy === 'price' ? 'Preis' : 'Bewertung'}
                  </span>
                )}
              </div>
              
              <button
                onClick={clearSearch}
                className="text-xs text-slate-400 hover:text-white transition-colors"
              >
                Alle Filter zurücksetzen
              </button>
            </div>
          )}
        </div>
      )}

      {/* Search results summary */}
      <div className="flex items-center justify-between text-sm text-slate-400">
        <div className="flex items-center gap-2">
          {selectedCategory !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-white/10">
              <CategoryIcon category={selectedCategory} className="w-3 h-3" />
              {categoryNames[selectedCategory] || selectedCategory}
            </span>
          )}
          <span>
            {filteredProducts.length} {filteredProducts.length === 1 ? 'Produkt' : 'Produkte'}
            {searchQuery.trim() && ` für "${searchQuery.trim()}"`}
          </span>
        </div>
        
        {filteredProducts.length > 0 && hasActiveFilters && (
          <button
            onClick={clearSearch}
            className="text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Filter zurücksetzen
          </button>
        )}
      </div>
    </div>
  );
}