import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, User, Bot, Minimize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatMessage {
  id: string;
  message: string;
  sender: 'user' | 'support' | 'bot';
  timestamp: Date;
  senderName?: string;
}

interface LiveChatWidgetProps {
  position?: 'bottom-right' | 'bottom-left';
  supportOnline?: boolean;
}

export function LiveChatWidget({ 
  position = 'bottom-right',
  supportOnline = true 
}: LiveChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      message: 'Hallo! 👋 Willkommen bei Nexuno Tech Fashion. Wie kann ich Ihnen helfen?',
      sender: 'support',
      timestamp: new Date(),
      senderName: 'Sarah'
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate support responses
  const simulateResponse = (userMessage: string) => {
    setIsTyping(true);
    
    setTimeout(() => {
      let responseMessage = '';
      const lowerMessage = userMessage.toLowerCase();
      
      if (lowerMessage.includes('größe') || lowerMessage.includes('size')) {
        responseMessage = 'Gerne helfe ich bei der Größenauswahl! Unsere Tech-Fashion läuft normal aus. Bei Unsicherheiten empfehle ich unsere virtuelle Anprobe oder die Größentabelle. 📏';
      } else if (lowerMessage.includes('versand') || lowerMessage.includes('lieferung')) {
        responseMessage = 'Versand erfolgt kostenlos ab €75. Standard-Lieferzeit: 2-3 Werktage. Express-Versand verfügbar! 🚚';
      } else if (lowerMessage.includes('rückgabe') || lowerMessage.includes('umtausch')) {
        responseMessage = '30 Tage Rückgaberecht! Einfacher Rückversand mit unserem kostenlosen Retourenlabel. 📦';
      } else if (lowerMessage.includes('tech') || lowerMessage.includes('ai') || lowerMessage.includes('smart')) {
        responseMessage = 'Unsere AI-Fashion Features: Smart-Fabric-Technologie, App-Integration, Temperatur-Regulierung und mehr! 🤖✨';
      } else if (lowerMessage.includes('preis') || lowerMessage.includes('angebot') || lowerMessage.includes('rabatt')) {
        responseMessage = 'Aktuelle Angebote: 15% auf alle Tech-Hoodies, kostenloser Versand ab €75. Newsletter-Abonnenten erhalten exklusive Deals! 💰';
      } else {
        responseMessage = 'Vielen Dank für Ihre Nachricht! Unser Tech-Support ist für Sie da. Haben Sie spezielle Fragen zu unseren AI-Fashion Produkten? 🎯';
      }
      
      const response: ChatMessage = {
        id: Date.now().toString(),
        message: responseMessage,
        sender: 'support',
        timestamp: new Date(),
        senderName: 'Sarah'
      };
      
      setMessages(prev => [...prev, response]);
      setIsTyping(false);
      
      if (!isOpen) {
        setUnreadCount(prev => prev + 1);
      }
    }, Math.random() * 2000 + 1000); // Random delay 1-3 seconds
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      message: newMessage,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    
    // Simulate support response
    simulateResponse(newMessage);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const openChat = () => {
    setIsOpen(true);
    setIsMinimized(false);
    setUnreadCount(0);
  };

  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6'
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={openChat}
            className={`fixed ${positionClasses[position]} z-50 w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center`}
            aria-label="Live Chat öffnen"
          >
            <MessageCircle className="h-6 w-6" />
            {unreadCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center"
              >
                {unreadCount}
              </motion.div>
            )}
            
            {supportOnline && (
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className={`fixed ${positionClasses[position]} z-50 w-80 h-96 bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden ${isMinimized ? 'h-14' : ''}`}
          >
            {/* Chat Header */}
            <div className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4" />
                  </div>
                  {supportOnline && (
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border border-white"></div>
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Tech Fashion Support</h3>
                  <p className="text-xs text-cyan-100">
                    {supportOnline ? 'Online • Antwortet schnell' : 'Offline • Wir melden uns'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="p-1 hover:bg-white/20 rounded"
                  aria-label="Chat minimieren"
                >
                  <Minimize2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-white/20 rounded"
                  aria-label="Chat schließen"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Messages Area */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  <AnimatePresence>
                    {messages.map((message, index) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-xs rounded-2xl px-4 py-2 ${
                          message.sender === 'user'
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {message.sender !== 'user' && (
                            <div className="flex items-center space-x-2 mb-1">
                              <div className="flex items-center space-x-1">
                                {message.sender === 'bot' ? (
                                  <Bot className="h-3 w-3 text-cyan-600" />
                                ) : (
                                  <User className="h-3 w-3 text-cyan-600" />
                                )}
                                <span className="text-xs font-medium text-cyan-600">
                                  {message.senderName || 'Support'}
                                </span>
                              </div>
                            </div>
                          )}
                          <p className="text-sm">{message.message}</p>
                          <p className={`text-xs mt-1 ${
                            message.sender === 'user' ? 'text-cyan-100' : 'text-gray-500'
                          }`}>
                            {message.timestamp.toLocaleTimeString('de-DE', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex justify-start"
                    >
                      <div className="bg-gray-100 rounded-2xl px-4 py-2 flex items-center space-x-1">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                        </div>
                        <span className="text-xs text-gray-500 ml-2">Sarah tippt...</span>
                      </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Quick Replies */}
                <div className="px-4 pb-2">
                  <div className="flex flex-wrap gap-2">
                    {['Größenhilfe 📏', 'Versandinfo 🚚', 'Tech-Features 🤖'].map((reply) => (
                      <button
                        key={reply}
                        onClick={() => {
                          setNewMessage(reply.replace(/[📏🚚🤖]/g, '').trim());
                          setTimeout(() => sendMessage(), 100);
                        }}
                        className="text-xs bg-gray-100 text-gray-700 px-3 py-1 rounded-full hover:bg-gray-200 transition-colors"
                      >
                        {reply}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Input Area */}
                <div className="border-t border-gray-200 p-4">
                  <div className="flex items-center space-x-2">
                    <textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Nachricht eingeben..."
                      className="flex-1 resize-none border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      rows={1}
                    />
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={sendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white p-2 rounded-lg hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                      aria-label="Nachricht senden"
                    >
                      <Send className="h-4 w-4" />
                    </motion.button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}