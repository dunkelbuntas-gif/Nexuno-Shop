import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  ArrowRight, 
  Sparkles, 
  Play, 
  ChevronDown
} from 'lucide-react';
import heroImage from 'figma:asset/2d04372e838a9cca216f6ce55ecc0e6d045f9f70.png';
import humanImage from 'figma:asset/db9b1a940f86a71b32d08f262eb4b3ead661e592.png';

export function EnhancedHeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  // Smooth Parallax transformations
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);
  const imageScale = useTransform(scrollYProgress, [0, 1], [1, 1.1]);

  return (
    <div 
      ref={containerRef}
      className="relative h-[70vh] min-h-[600px] max-h-[800px] overflow-hidden bg-gradient-to-br from-slate-700 via-blue-700 to-indigo-700"
    >
      {/* Smooth Moving Lines Background */}
      <motion.div 
        className="absolute inset-0"
        style={{ y: backgroundY }}
      >
        {/* Horizontal Moving Lines */}
        <div className="absolute inset-0">
          {Array.from({ length: 8 }).map((_, i) => (
            <motion.div
              key={`h-line-${i}`}
              className="absolute h-px bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent"
              style={{
                top: `${15 + i * 12}%`,
                left: "0%",
                right: "0%",
              }}
              animate={{
                scaleX: [0.3, 1, 0.3],
                opacity: [0.3, 0.8, 0.3],
              }}
              transition={{
                duration: 4 + i * 0.5,
                repeat: Infinity,
                delay: i * 0.3,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Vertical Moving Lines */}
        <div className="absolute inset-0">
          {Array.from({ length: 6 }).map((_, i) => (
            <motion.div
              key={`v-line-${i}`}
              className="absolute w-px bg-gradient-to-b from-transparent via-blue-400/40 to-transparent"
              style={{
                left: `${20 + i * 15}%`,
                top: "0%",
                bottom: "0%",
              }}
              animate={{
                scaleY: [0.4, 1, 0.4],
                opacity: [0.2, 0.6, 0.2],
              }}
              transition={{
                duration: 6 + i * 0.3,
                repeat: Infinity,
                delay: i * 0.4,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Diagonal Moving Lines */}
        <div className="absolute inset-0">
          {Array.from({ length: 4 }).map((_, i) => (
            <motion.div
              key={`d-line-${i}`}
              className="absolute bg-gradient-to-br from-transparent via-purple-400/30 to-transparent"
              style={{
                width: "200%",
                height: "2px",
                left: "-50%",
                top: `${25 + i * 20}%`,
                transform: "rotate(15deg)",
              }}
              animate={{
                x: ["-20%", "20%", "-20%"],
                opacity: [0.2, 0.5, 0.2],
              }}
              transition={{
                duration: 8 + i * 1,
                repeat: Infinity,
                delay: i * 0.6,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Subtle Ambient Glow */}
        <div className="absolute inset-0 opacity-40">
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"
            animate={{
              scale: [0.8, 1.2, 0.8],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl"
            animate={{
              scale: [1.1, 0.9, 1.1],
              opacity: [0.4, 0.7, 0.4],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2,
            }}
          />
        </div>
      </motion.div>

      {/* Main Content Container */}
      <motion.div 
        className="relative z-10 h-full flex items-center py-8"
        style={{ y: contentY }}
      >
        {/* Left Content */}
        <motion.div 
          className="flex-1 px-6 lg:px-12 xl:px-16 max-w-3xl"
        >
          {/* Animated Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-lg border border-cyan-400/30 rounded-full px-4 py-2 mb-6"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
            </motion.div>
            <span className="text-cyan-100 text-sm font-medium">KI-Mode Revolution</span>
          </motion.div>

          {/* Main Headline with Typewriter Effect */}
          <motion.div className="mb-6">
            <motion.h1 
              className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
            >
              <motion.span
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="block"
              >
                Fashion
              </motion.span>
              
              <motion.span
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="block bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent"
                style={{
                  filter: `drop-shadow(0 0 20px rgba(34, 211, 238, 0.5))`,
                }}
              >
                meets AI
              </motion.span>
            </motion.h1>

            {/* Animated Underline */}
            <motion.div
              className="h-1 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full mt-4"
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 1.2, delay: 1.2 }}
            />
          </motion.div>

          {/* Description */}
          <motion.p 
            className="text-lg lg:text-xl text-cyan-100 mb-6 max-w-xl leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.0 }}
          >
            Wo <span className="font-semibold text-white">menschliche Kreativität</span> auf{' '}
            <span className="font-semibold text-cyan-400">künstliche Intelligenz</span> trifft.
            Die Zukunft der Mode ist hier.
          </motion.p>

          {/* Animated Stats */}
          <motion.div 
            className="flex flex-wrap gap-6 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
          >
            {[
              { label: 'KI-Designs', value: '10K+' },
              { label: 'Happy Customers', value: '50K+' },
              { label: 'Collections', value: '100+' }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <motion.div 
                  className="text-xl lg:text-2xl font-bold text-white"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 1.4 + index * 0.1 }}
                >
                  {stat.value}
                </motion.div>
                <div className="text-cyan-200 text-xs">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>

          {/* Enhanced Action Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.4 }}
          >
            {/* Primary CTA */}
            <motion.button
              className="group relative px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl overflow-hidden"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Animated Background */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600"
                initial={{ x: "-100%" }}
                whileHover={{ x: "0%" }}
                transition={{ duration: 0.3 }}
              />
              
              <span className="relative z-10 flex items-center space-x-2">
                <span>Kollektion entdecken</span>
                <motion.div
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <ArrowRight className="w-5 h-5" />
                </motion.div>
              </span>

              {/* Glow Effect */}
              <motion.div
                className="absolute inset-0 rounded-xl bg-cyan-400/20"
                animate={{
                  boxShadow: [
                    "0 0 20px rgba(34, 211, 238, 0.5)",
                    "0 0 40px rgba(34, 211, 238, 0.7)",
                    "0 0 20px rgba(34, 211, 238, 0.5)"
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </motion.button>

            {/* Secondary CTA */}
            <motion.button
              className="group px-6 py-3 border-2 border-white/30 text-white font-semibold rounded-xl backdrop-blur-lg hover:bg-white/10 transition-all duration-300"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="flex items-center space-x-2">
                <Play className="w-5 h-5" />
                <span>AI Demo anschauen</span>
              </span>
            </motion.button>
          </motion.div>
        </motion.div>

        {/* Right Content - Dual Character Display */}
        <motion.div 
          className="flex-1 relative h-full flex items-center justify-center"
        >
          {/* Dual Character Container */}
          <motion.div
            className="relative max-w-5xl w-full flex items-center justify-center gap-8"
            style={{ scale: imageScale }}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            {/* Subtle Glow Background for Both Characters */}
            <motion.div
              className="absolute inset-0 rounded-3xl opacity-60"
              animate={{
                background: [
                  "radial-gradient(ellipse 80% 70% at 50% 50%, rgba(34, 211, 238, 0.15), transparent)",
                  "radial-gradient(ellipse 80% 70% at 50% 50%, rgba(59, 130, 246, 0.15), transparent)",
                  "radial-gradient(ellipse 80% 70% at 50% 50%, rgba(34, 211, 238, 0.15), transparent)"
                ]
              }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            />

            {/* Human Character (Left) */}
            <motion.div
              className="relative z-10 rounded-3xl overflow-hidden backdrop-blur-sm border border-white/10 flex-1 max-w-md"
              initial={{ opacity: 0, scale: 0.95, x: -50 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 1.2, delay: 0.6, ease: "easeOut" }}
            >
              <ImageWithFallback
                src={humanImage}
                alt="Fashion Model - Stylischer Mann mit weißem Hoodie und Sonnenbrille"
                className="w-full h-auto object-contain mix-blend-multiply opacity-90"
              />

              {/* Corner Accents for Human */}
              <motion.div
                className="absolute top-4 left-4 w-12 h-12 border-l-2 border-t-2 border-purple-400/40 rounded-tl-lg"
                animate={{ opacity: [0.3, 0.7, 0.3] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
              />
            </motion.div>

            {/* Connecting Line Between Characters */}
            <motion.div
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-px bg-gradient-to-r from-cyan-400/60 via-white/80 to-blue-400/60"
              animate={{
                scaleX: [0.5, 1.2, 0.5],
                opacity: [0.4, 0.9, 0.4],
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />

            {/* AI Robot Character (Right) - Mirrored */}
            <motion.div
              className="relative z-10 rounded-3xl overflow-hidden backdrop-blur-sm border border-white/10 flex-1 max-w-md"
              initial={{ opacity: 0, scale: 0.95, x: 50 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 1.2, delay: 0.8, ease: "easeOut" }}
            >
              <ImageWithFallback
                src={heroImage}
                alt="AI Fashion Model - Futuristic Roboter mit schwarzem Hoodie"
                className="w-full h-auto object-contain mix-blend-multiply opacity-90 transform scale-x-[-1]"
              />

              {/* Corner Accents for Robot */}
              <motion.div
                className="absolute bottom-4 right-4 w-12 h-12 border-r-2 border-b-2 border-cyan-400/40 rounded-br-lg"
                animate={{ opacity: [0.4, 0.8, 0.4] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              />
            </motion.div>

            {/* Enhanced Floating Points Around Both Characters */}
            {Array.from({ length: 5 }).map((_, i) => (
              <motion.div
                key={`dual-float-${i}`}
                className="absolute w-1.5 h-1.5 bg-gradient-to-r from-cyan-400/70 to-purple-400/70 rounded-full"
                style={{
                  left: `${20 + i * 15}%`,
                  top: `${20 + i * 12}%`,
                }}
                animate={{
                  y: [0, -20, 0],
                  x: [0, i % 2 === 0 ? 10 : -10, 0],
                  opacity: [0.3, 0.8, 0.3],
                }}
                transition={{
                  duration: 5 + i * 0.5,
                  repeat: Infinity,
                  delay: i * 0.6,
                  ease: "easeInOut",
                }}
              />
            ))}

            {/* Fashion meets AI Connection Visual */}
            <motion.div
              className="absolute top-1/4 left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full border-2 border-white/60 bg-gradient-to-br from-cyan-400/30 to-purple-500/30 backdrop-blur-sm"
              animate={{
                scale: [0.8, 1.3, 0.8],
                rotate: [0, 180, 360],
                opacity: [0.4, 0.9, 0.4],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex flex-col items-center space-y-1"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 2 }}
      >
        <span className="text-white/70 text-sm">Scroll to explore</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ChevronDown className="w-6 h-6 text-white/70" />
        </motion.div>
      </motion.div>

      {/* Performance Optimizations */}
      <div className="absolute inset-0 pointer-events-none" style={{ willChange: 'transform' }} />
    </div>
  );
}