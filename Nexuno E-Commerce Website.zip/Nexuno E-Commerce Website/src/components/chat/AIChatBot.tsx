// chat/AIChatBot.tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Bot, Sparkles, Headphones, Send, Loader2 } from 'lucide-react';

type Role = 'user' | 'bot';

type SuggestedAction =
  | { label: string; query: string }               // stellt direkt eine Folgefrage
  | { label: 'Mit Mensch sprechen'; type: 'human' };

interface ChatMessage {
  id: string;
  role: Role;
  text: string;
  suggestions?: SuggestedAction[];
}

interface AIChatBotProps {
  onEscalateToHuman?: () => void;
}

export function AIChatBot({ onEscalateToHuman }: AIChatBotProps) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'm_welcome',
      role: 'bot',
      text:
        '👋 Hallo! Ich bin dein AI-Assistent für Nexuno Fashion.\n\n' +
        'Ich helfe dir bei: 🛍️ Bestellen • 🚚 Versand • 🔄 Rückgabe • 📦 Produktinfos • 👤 Konto • 🏢 Unternehmen.\n' +
        'Womit starten wir?',
      suggestions: [
        { label: 'Wie kann ich bestellen?', query: 'Hilfe beim Bestellprozess' },
        { label: 'Wann kommt meine Bestellung?', query: 'Versand und Lieferzeiten' },
        { label: 'Wie funktioniert der Umtausch?', query: 'Rückgabe und Umtausch' },
        { label: 'Informationen über das Unternehmen', query: 'Über Nexuno Fashion' },
        { label: 'Mit Mensch sprechen', type: 'human' },
      ],
    },
  ]);
  const [isThinking, setIsThinking] = useState(false);
  const scrollerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll bei neuen Nachrichten
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages, isThinking]);

  // ---------------- AI "Routing" (Mock) ----------------
  const aiAnswer = useMemo(
    () => ({
      async reply(userText: string): Promise<{ text: string; suggestions?: SuggestedAction[] }> {
        // kleine Verzögerung für Tipperlebnis
        await new Promise((r) => setTimeout(r, 900));
        const q = userText.toLowerCase();

        if (q.includes('bestell') || q.includes('order') || q.includes('kauf')) {
          return {
            text:
              '🛍️ **Bestellprozess & Bezahlung**\n\n' +
              '1) Produkt wählen → In den Warenkorb → Zur Kasse\n' +
              '2) Zahlungsmethoden: Kreditkarte, PayPal, SEPA, Rechnung\n' +
              '3) Nach Abschluss erhältst du eine Bestellbestätigung',
            suggestions: [
              { label: 'Zahlungsarten anzeigen', query: 'Welche Zahlungsarten gibt es?' },
              { label: 'Bestellstatus prüfen', query: 'Wie prüfe ich meinen Bestellstatus?' },
              { label: 'Mit Mensch sprechen', type: 'human' },
            ],
          };
        }

        if (q.includes('versand') || q.includes('liefer') || q.includes('delivery')) {
          return {
            text:
              '🚚 **Versand & Lieferung**\n\n' +
              '• Standard: 2–3 Werktage (ab 75€ kostenlos)\n' +
              '• Express: 1–2 Werktage (9,99€)\n' +
              '• Tracking kommt per E-Mail nach Versand',
            suggestions: [
              { label: 'Versandkosten berechnen', query: 'Was kostet der Versand?' },
              { label: 'Sendung verfolgen', query: 'Wie verfolge ich mein Paket?' },
            ],
          };
        }

        if (q.includes('rückgabe') || q.includes('umtausch') || q.includes('return')) {
          return {
            text:
              '🔄 **Rückgabe & Umtausch**\n\n' +
              '• 30 Tage Rückgaberecht\n' +
              '• Kostenloses Rücksendelabel\n' +
              '• Rückerstattung i.d.R. 5–7 Tage nach Eingang',
            suggestions: [
              { label: 'Rücksendung starten', query: 'Wie starte ich eine Rücksendung?' },
              { label: 'Umtausch beantragen', query: 'Wie tausche ich einen Artikel um?' },
            ],
          };
        }

        if (q.includes('unternehmen') || q.includes('about') || q.includes('kontakt') || q.includes('firma')) {
          return {
            text:
              '🏢 **Über Nexuno Fashion**\n\n' +
              'E-Commerce mit modernen Designs & Qualität.\n' +
              'Kontakt: info@nexuno.eu • +49 (0)30 12345678\n' +
              'Servicezeiten: Mo–Fr 9–18 Uhr, Sa 10–16 Uhr',
            suggestions: [{ label: 'Mit Mensch sprechen', type: 'human' }],
          };
        }

        if (q.includes('produkt') || q.includes('größe') || q.includes('verfügbar') || q.includes('lager')) {
          return {
            text:
              '📦 **Produktinfos**\n\n' +
              '• Nutze Filter & Suche oben\n' +
              '• Details: Material, Pflege, Größen, Farben\n' +
              '• Live-Bestände in der Detailansicht',
            suggestions: [
              { label: 'Produktkatalog öffnen', query: 'Zeig mir Produkte' },
              { label: 'Verfügbarkeit prüfen', query: 'Ist Artikel X verfügbar?' },
            ],
          };
        }

        // Fallback
        return {
          text:
            '🤖 Ich habe dich verstanden! Stelle mir eine Frage zu Bestellung, Versand, Rückgabe, Produkten, ' +
            'Konto oder Unternehmen – oder klicke auf eine Option unten.',
          suggestions: [
            { label: 'Wie kann ich bestellen?', query: 'Hilfe beim Bestellprozess' },
            { label: 'Wann kommt meine Bestellung?', query: 'Versand und Lieferzeiten' },
            { label: 'Mit Mensch sprechen', type: 'human' },
          ],
        };
      },
    }),
    []
  );

  // ---------------- Handlers ----------------
  const pushMessage = (role: Role, text: string, suggestions?: SuggestedAction[]) => {
    setMessages((prev) => [
      ...prev,
      { id: `${role}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, role, text, suggestions },
    ]);
  };

  const handleAsk = async (text: string) => {
    if (!text.trim() || isThinking) return;
    pushMessage('user', text.trim());
    setInput('');
    setIsThinking(true);
    try {
      const res = await aiAnswer.reply(text.trim());
      pushMessage('bot', res.text, res.suggestions);
    } catch {
      pushMessage('bot', 'Uff, da ist was schiefgelaufen. Versuch es bitte nochmal oder sprich mit unserem Team.', [
        { label: 'Mit Mensch sprechen', type: 'human' },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    void handleAsk(input);
  };

  const handleSuggestionClick = (s: SuggestedAction) => {
    if ('type' in s && s.type === 'human') {
      onEscalateToHuman?.();
      return;
    }
    handleAsk(s.query);
  };

  // ---------------- UI ----------------
  return (
    <div className="flex h-full flex-col rounded-xl border border-white/10 bg-gradient-to-br from-slate-900/70 to-slate-800/50 backdrop-blur-md">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
        <div className="relative">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-blue-600">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <Sparkles className="absolute -right-1 -top-1 h-4 w-4 text-yellow-400" />
        </div>
        <div className="leading-tight">
          <div className="font-semibold text-white">Support Chat</div>
          <div className="text-xs text-white/60">AI-Assistent · 24/7 verfügbar</div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollerRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={[
                'max-w-[85%] whitespace-pre-wrap rounded-xl px-3 py-2 text-sm shadow-sm',
                m.role === 'user'
                  ? 'bg-cyan-600/20 text-cyan-100 ring-1 ring-cyan-500/30'
                  : 'bg-white/5 text-white/90 ring-1 ring-white/10',
              ].join(' ')}
            >
              {m.text}
              {m.suggestions && m.suggestions.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {m.suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => handleSuggestionClick(s)}
                      className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/90 hover:bg-white/10"
                    >
                      {'type' in s && s.type === 'human' ? (
                        <span className="inline-flex items-center gap-1">
                          <Headphones className="h-3.5 w-3.5" />
                          Mit Mensch sprechen
                        </span>
                      ) : (
                        s.label
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex items-center gap-2 text-xs text-white/60">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Assistent tippt …
          </div>
        )}

        {/* Quick actions (nur wenn es sehr wenige Messages gibt) */}
        {messages.length <= 2 && (
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              { label: 'Wie kann ich bestellen?', query: 'Hilfe beim Bestellprozess' },
              { label: 'Wann kommt meine Bestellung?', query: 'Versand und Lieferzeiten' },
              { label: 'Wie funktioniert der Umtausch?', query: 'Rückgabe und Umtausch' },
              { label: 'Informationen über das Unternehmen', query: 'Über Nexuno Fashion' },
            ].map((q) => (
              <button
                key={q.label}
                onClick={() => handleAsk(q.query)}
                className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-left text-sm text-white/90 hover:bg-white/10"
              >
                {q.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="border-t border-white/10 p-3">
        <div className="flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) return; // form submit handled
            }}
            placeholder="Nachricht eingeben…"
            className="flex-1 rounded-lg bg-white/5 px-3 py-2 text-sm text-white placeholder-white/40 outline-none ring-1 ring-white/10 focus:ring-cyan-500/40"
          />
          <button
            type="submit"
            disabled={!input.trim() || isThinking}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-3 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Send className="h-4 w-4" />
            Senden
          </button>
        </div>
        <p className="mt-1 text-center text-[10px] text-white/40">
          Durchschnittliche Wartezeit bei Hand-Over: 2 Minuten
        </p>
      </form>
    </div>
  );
}

export default AIChatBot;