/**
 * Schlanke Karussell-Komponente für Produktbilder
 * Mit Thumbnails, Swipe-Support und Tastaturnavigation
 */

import * as React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CarouselImage {
  src?: string;
  url?: string;
  alt: string;
  type?: string;
}

interface CarouselProps {
  images: CarouselImage[];
  selectedIndex?: number;
  onIndexChange?: (index: number) => void;
  className?: string;
  showThumbnails?: boolean;
  showNavigation?: boolean;
  showIndicators?: boolean;
  eager?: number; // Anzahl der Bilder die eager geladen werden sollen
}

export function Carousel({
  images,
  selectedIndex = 0,
  onIndexChange,
  className = '',
  showThumbnails = true,
  showNavigation = true,
  showIndicators = false,
  eager = 2
}: CarouselProps) {
  const [currentIndex, setCurrentIndex] = React.useState(selectedIndex);
  const [touchStart, setTouchStart] = React.useState<number | null>(null);
  const [touchEnd, setTouchEnd] = React.useState<number | null>(null);
  const [isTransitioning, setIsTransitioning] = React.useState(false);
  
  const carouselRef = React.useRef<HTMLDivElement>(null);
  const mainImageRef = React.useRef<HTMLImageElement>(null);

  // Synchronisiere mit externem selectedIndex
  React.useEffect(() => {
    if (selectedIndex !== currentIndex) {
      setCurrentIndex(selectedIndex);
    }
  }, [selectedIndex]);

  // Callback bei Index-Änderung
  React.useEffect(() => {
    onIndexChange?.(currentIndex);
  }, [currentIndex, onIndexChange]);

  // Navigation Funktionen
  const goToNext = React.useCallback(() => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex(prev => (prev + 1) % images.length);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [images.length, isTransitioning]);

  const goToPrevious = React.useCallback(() => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex(prev => (prev - 1 + images.length) % images.length);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [images.length, isTransitioning]);

  const goToIndex = React.useCallback((index: number) => {
    if (index === currentIndex || isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex(index);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [currentIndex, isTransitioning]);

  // Tastaturnavigation
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!carouselRef.current?.contains(document.activeElement)) return;
      
      switch (e.key) {
        case 'ArrowLeft':
          e.preventDefault();
          goToPrevious();
          break;
        case 'ArrowRight':
          e.preventDefault();
          goToNext();
          break;
        case 'Home':
          e.preventDefault();
          goToIndex(0);
          break;
        case 'End':
          e.preventDefault();
          goToIndex(images.length - 1);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [goToNext, goToPrevious, goToIndex, images.length]);

  // Touch/Swipe-Handler
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      goToNext();
    } else if (isRightSwipe) {
      goToPrevious();
    }
  };

  // Wenn keine Bilder vorhanden
  if (!images || images.length === 0) {
    return (
      <div className={`flex items-center justify-center bg-gray-100 rounded-lg ${className}`}>
        <p className="text-gray-500">Keine Bilder verfügbar</p>
      </div>
    );
  }

  // Normalisiere Bildquellen um sowohl src als auch url zu unterstützen
  const normalizedImages = (images || []).map((img: any) => ({
    src: img?.src ?? img?.url ?? '',
    alt: img?.alt ?? '',
    type: img?.type,
  }));

  const currentImage = normalizedImages[currentIndex];

  return (
    <div 
      ref={carouselRef}
      className={`w-full ${className}`}
      style={{ minHeight: 320 }}
      role="region"
      aria-label="Produktbilder Karussell"
      aria-live="polite"
    >
      {/* Hauptbild Container */}
      <div 
        className="relative bg-gray-50 rounded-lg overflow-hidden group"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Hauptbild */}
        <div className="aspect-square flex items-center justify-center">
          <img
            ref={mainImageRef}
            src={currentImage.src}
            alt={currentImage.alt}
            className={`w-full h-full object-contain transition-opacity duration-300 ${
              isTransitioning ? 'opacity-70' : 'opacity-100'
            }`}
            loading={currentIndex < eager ? 'eager' : 'lazy'}
            onError={(e) => {
              console.warn(`Failed to load image: ${currentImage.src}`);
              // Fallback zu placeholder
              (e.target as HTMLImageElement).src = '/api/placeholder/400/400';
            }}
          />
        </div>

        {/* Navigation Buttons */}
        {showNavigation && images.length > 1 && (
          <>
            <button
              onClick={goToPrevious}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full 
                         bg-black/50 text-white backdrop-blur opacity-0 group-hover:opacity-100 
                         transition-all duration-200 hover:bg-black/70 hover:scale-110
                         focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2
                         disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Vorheriges Bild"
              disabled={isTransitioning}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              onClick={goToNext}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full 
                         bg-black/50 text-white backdrop-blur opacity-0 group-hover:opacity-100 
                         transition-all duration-200 hover:bg-black/70 hover:scale-110
                         focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2
                         disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Nächstes Bild"
              disabled={isTransitioning}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Bildtyp Badge */}
        {currentImage.type && (
          <div className="absolute top-3 left-3 bg-black/70 text-white px-2 py-1 rounded text-xs backdrop-blur">
            {currentImage.type.replace('_', ' ')}
          </div>
        )}

        {/* Bild Counter */}
        {images.length > 1 && (
          <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-xs backdrop-blur">
            {currentIndex + 1} / {images.length}
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {showThumbnails && images.length > 1 && (
        <div className="mt-4">
          <div 
            className="flex gap-2 overflow-x-auto scrollbar-hide pb-2"
            role="tablist"
            aria-label="Bildauswahl"
          >
            {normalizedImages.map((image, index) => (
              <button
                key={index}
                onClick={() => goToIndex(index)}
                className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all duration-200 
                           focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 ${
                  index === currentIndex
                    ? 'border-cyan-500 ring-2 ring-cyan-500/20 scale-105'
                    : 'border-gray-200 hover:border-gray-300 hover:scale-102'
                }`}
                role="tab"
                aria-selected={index === currentIndex}
                aria-controls={`carousel-image-${index}`}
                aria-label={`Bild ${index + 1} von ${images.length} anzeigen: ${image.alt}`}
                disabled={isTransitioning}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-full object-cover"
                  loading={index < eager ? 'eager' : 'lazy'}
                  onError={(e) => {
                    // Hide broken thumbnails
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Indicators (alternative zu Thumbnails) */}
      {showIndicators && !showThumbnails && images.length > 1 && (
        <div className="flex justify-center mt-4 gap-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => goToIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 ${
                index === currentIndex
                  ? 'bg-cyan-500 scale-110'
                  : 'bg-gray-300 hover:bg-gray-400'
              }`}
              aria-label={`Zu Bild ${index + 1} wechseln`}
              disabled={isTransitioning}
            />
          ))}
        </div>
      )}

      {/* Screen Reader Info */}
      <div 
        id={`carousel-image-${currentIndex}`}
        className="sr-only"
        aria-live="polite"
        role="status"
      >
        Bild {currentIndex + 1} von {images.length}: {currentImage.alt}
      </div>
    </div>
  );
}

// Erweiterte Karussell-Variante mit Auto-Play
interface AutoCarouselProps extends CarouselProps {
  autoPlay?: boolean;
  autoPlayInterval?: number;
  pauseOnHover?: boolean;
}

export function AutoCarousel({
  autoPlay = false,
  autoPlayInterval = 3000,
  pauseOnHover = true,
  ...carouselProps
}: AutoCarouselProps) {
  const [isPlaying, setIsPlaying] = React.useState(autoPlay);
  const [isPaused, setIsPaused] = React.useState(false);
  const intervalRef = React.useRef<NodeJS.Timeout>();

  const { images, selectedIndex = 0, onIndexChange } = carouselProps;
  const [currentIndex, setCurrentIndex] = React.useState(selectedIndex);

  // Auto-play Logic
  React.useEffect(() => {
    if (!isPlaying || isPaused || images.length <= 1) return;

    intervalRef.current = setInterval(() => {
      setCurrentIndex(prev => {
        const nextIndex = (prev + 1) % images.length;
        onIndexChange?.(nextIndex);
        return nextIndex;
      });
    }, autoPlayInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPlaying, isPaused, images.length, autoPlayInterval, onIndexChange]);

  const handleMouseEnter = () => {
    if (pauseOnHover) setIsPaused(true);
  };

  const handleMouseLeave = () => {
    if (pauseOnHover) setIsPaused(false);
  };

  return (
    <div onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      <Carousel
        {...carouselProps}
        selectedIndex={currentIndex}
        onIndexChange={(index) => {
          setCurrentIndex(index);
          onIndexChange?.(index);
        }}
      />
      
      {/* Auto-play Controls */}
      {autoPlay && (
        <div className="flex justify-center mt-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="text-sm text-gray-600 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 rounded px-2 py-1"
            aria-label={isPlaying ? 'Auto-play pausieren' : 'Auto-play starten'}
          >
            {isPlaying ? 'Pausieren' : 'Abspielen'}
          </button>
        </div>
      )}
    </div>
  );
}