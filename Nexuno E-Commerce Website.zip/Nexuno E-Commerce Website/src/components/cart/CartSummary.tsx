import React from 'react';
import { motion } from 'motion/react';
import { Truck, Shield, Star, CreditCard, Gift, Percent, Info } from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';

interface CartSummaryProps {
  onCheckout?: () => void;
  showPromotions?: boolean;
  showTrustBadges?: boolean;
  className?: string;
}

export function CartSummary({ 
  onCheckout, 
  showPromotions = true, 
  showTrustBadges = true,
  className = ''
}: CartSummaryProps) {
  const { state } = useCart();

  const formatPrice = (price: number) => `€${price.toFixed(2)}`;

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  // Calculations
  const subtotal = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);
  const freeShippingThreshold = 69;
  const shippingCost = subtotal >= freeShippingThreshold ? 0 : 4.99;
  const discount = subtotal > 100 ? subtotal * 0.05 : 0; // 5% discount for orders over €100
  const tax = (subtotal - discount) * 0.19; // 19% VAT
  const total = subtotal + shippingCost - discount + tax;

  const shippingProgress = Math.min((subtotal / freeShippingThreshold) * 100, 100);
  const remainingForFreeShipping = Math.max(freeShippingThreshold - subtotal, 0);

  return (
    <Card className={`p-6 bg-gradient-to-b from-white/95 to-gray-50/95 backdrop-blur-sm border border-gray-200/50 ${className}`}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Bestellübersicht</h3>
          <Badge variant="outline" className="text-xs">
            {state.itemCount} Artikel
          </Badge>
        </div>

        {/* Free Shipping Progress */}
        {shippingCost > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg border border-cyan-200"
          >
            <div className="flex items-center gap-2 mb-2">
              <Truck className="w-4 h-4 text-cyan-600" />
              <span className="text-sm font-medium text-cyan-800">
                Noch {formatPrice(remainingForFreeShipping)} für kostenlosen Versand
              </span>
            </div>
            <div className="w-full bg-cyan-200 rounded-full h-2 overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${shippingProgress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="bg-gradient-to-r from-cyan-500 to-cyan-600 h-2 rounded-full"
              />
            </div>
            <p className="text-xs text-cyan-700 mt-1">
              {shippingProgress < 100 ? `${shippingProgress.toFixed(0)}% erreicht` : 'Kostenloser Versand aktiviert! 🎉'}
            </p>
          </motion.div>
        )}

        {/* Promotion Banner */}
        {showPromotions && discount > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200"
          >
            <div className="flex items-center gap-2">
              <Percent className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">
                5% Rabatt ab €100 Bestellwert angewandt!
              </span>
            </div>
          </motion.div>
        )}

        {/* Price Breakdown */}
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Zwischensumme</span>
            <span className="text-gray-900 font-medium">{formatPrice(subtotal)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <div className="flex items-center gap-1">
              <span className="text-gray-600">Versand</span>
              <Info className="w-3 h-3 text-gray-400" />
            </div>
            <span className="text-gray-900 font-medium">
              {shippingCost === 0 ? (
                <span className="text-green-600 font-semibold">Kostenlos</span>
              ) : (
                formatPrice(shippingCost)
              )}
            </span>
          </div>

          {discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-green-600">Rabatt (5%)</span>
              <span className="text-green-600 font-medium">-{formatPrice(discount)}</span>
            </div>
          )}

          <div className="flex justify-between text-sm">
            <div className="flex items-center gap-1">
              <span className="text-gray-600">MwSt. (19%)</span>
              <Info className="w-3 h-3 text-gray-400" />
            </div>
            <span className="text-gray-900 font-medium">{formatPrice(tax)}</span>
          </div>

          <Separator />

          <motion.div 
            key={total}
            initial={{ scale: 1.05 }}
            animate={{ scale: 1 }}
            className="flex justify-between items-center pt-2"
          >
            <span className="text-lg font-semibold text-gray-900">Gesamt</span>
            <span className="text-xl font-bold text-gray-900">{formatPrice(total)}</span>
          </motion.div>
        </div>

        {/* Gift Options */}
        {showPromotions && subtotal > 50 && (
          <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
            <div className="flex items-center gap-2">
              <Gift className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-800">
                Geschenkverpackung für nur €2,99 verfügbar
              </span>
            </div>
          </div>
        )}

        {/* Checkout Button */}
        <Button
          onClick={onCheckout}
          disabled={state.items.length === 0}
          className="w-full h-12 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <CreditCard className="w-5 h-5 mr-2" />
          Jetzt kaufen
        </Button>

        {/* Payment Methods */}
        <div className="text-center">
          <p className="text-xs text-gray-500 mb-2">Sichere Zahlungsmethoden</p>
          <div className="flex justify-center items-center gap-2">
            <div className="px-2 py-1 bg-gray-100 rounded text-xs font-medium">VISA</div>
            <div className="px-2 py-1 bg-gray-100 rounded text-xs font-medium">MC</div>
            <div className="px-2 py-1 bg-gray-100 rounded text-xs font-medium">PayPal</div>
            <div className="px-2 py-1 bg-gray-100 rounded text-xs font-medium">Klarna</div>
          </div>
        </div>

        {/* Trust Badges */}
        {showTrustBadges && (
          <div className="pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 gap-3 text-xs text-gray-600">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-green-600" />
                <span>SSL-verschlüsselte Übertragung</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500" />
                <span>14 Tage Rückgaberecht</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-600" />
                <span>Versand innerhalb von 1-2 Werktagen</span>
              </div>
            </div>
          </div>
        )}

        {/* Customer Service */}
        <div className="text-center pt-4 border-t border-gray-200">
          <p className="text-xs text-gray-500 mb-1">Fragen? Wir helfen gerne!</p>
          <p className="text-xs font-medium text-cyan-600">info@nexuno.eu • +49 30 12345678</p>
        </div>
      </div>
    </Card>
  );
}