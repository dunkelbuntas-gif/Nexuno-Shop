# 🚀 Nexuno + Printful + Cloudflare Workers Integration

**Complete Print-on-Demand E-Commerce Solution**

## 🎯 **OVERVIEW**

Diese Integration verbindet die **Nexuno Fashion Website** mit **Printful's Print-on-Demand API** über **Cloudflare Workers** für eine **globale, skalierbare Backend-Lösung**.

---

## 🛠️ **TECHNICAL STACK**

### **Frontend:**
- ⚡ **React + TypeScript** 
- 🎨 **Tailwind CSS v4**
- 🌊 **Motion/React** (animations)
- 📱 **Responsive Design**

### **Backend:**
- 🌍 **Cloudflare Workers** (Global Edge)
- 🗄️ **KV Storage** (Product Caching)
- 📦 **R2 Storage** (Design Files)
- 🔗 **Printful API** Integration

### **Features:**
- 🛒 **Real Printful Products**
- 🎨 **Design Studio** (Upload + Text)
- 🖼️ **Live Mockup Generation**
- 📦 **Order Fulfillment**
- 🔄 **Webhook Integration**
- 🌍 **Global CDN Performance**

---

## 🚀 **QUICK START**

### **1. Install Dependencies**
```bash
npm install
npm install -g wrangler  # Cloudflare CLI
```

### **2. Setup Cloudflare**
```bash
# Login to Cloudflare
wrangler login

# Create KV namespace for caching
wrangler kv:namespace create "PRINTFUL_CACHE"
wrangler kv:namespace create "PRINTFUL_CACHE" --preview

# Create R2 bucket for design storage
wrangler r2 bucket create nexuno-designs
```

### **3. Environment Variables**
Create `.env` file:
```env
# Printful API
PRINTFUL_API_KEY=your_printful_api_key_here
PRINTFUL_STORE_ID=your_store_id_here

# Cloudflare (auto-configured via wrangler.toml)
CLOUDFLARE_ACCOUNT_ID=your_account_id
CLOUDFLARE_API_TOKEN=your_api_token
```

### **4. Update wrangler.toml**
```toml
# Update with your actual KV namespace IDs
[[kv_namespaces]]
binding = "PRINTFUL_CACHE"
id = "your_kv_namespace_id_here"
preview_id = "your_preview_kv_namespace_id_here"
```

### **5. Development**
```bash
# Start frontend
npm run dev

# Start worker (separate terminal)
npm run worker:dev

# Both running:
# Frontend: http://localhost:5173
# Worker:   http://localhost:8787
```

### **6. Production Deploy**
```bash
# Deploy everything
npm run deploy

# Or deploy separately:
npm run build          # Build frontend
npm run worker:deploy  # Deploy worker
```

---

## 📁 **PROJECT STRUCTURE**

```
nexuno-printful/
├── workers/
│   └── index.ts              # Cloudflare Worker (Printful API)
├── components/printful/
│   ├── PrintfulProductGrid.tsx   # Product listing
│   └── PrintfulDesignStudio.tsx  # Design interface
├── lib/
│   └── printful-api.ts       # Frontend API client
├── wrangler.toml            # Worker configuration
└── package.json
```

---

## 🔌 **API ENDPOINTS**

### **Worker Endpoints** (`/printful/*`)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/printful/products` | GET | List Printful products |
| `/printful/variants/{id}` | GET | Product variants & pricing |
| `/printful/mockups` | POST | Generate product mockups |
| `/printful/upload` | POST | Upload design files |
| `/printful/orders` | POST | Create orders |
| `/printful/orders?id={id}` | GET | Order status |
| `/printful/webhooks` | POST | Printful webhooks |
| `/printful/status` | GET | Health check |

### **Frontend API Usage**
```typescript
import { printfulApi } from './lib/printful-api';

// Get products
const products = await printfulApi.getProducts('t-shirts');

// Upload design
const uploadResult = await printfulApi.uploadDesign(file);

// Create order
const order = await printfulApi.createOrder(orderData);
```

---

## 🎨 **DESIGN STUDIO FEATURES**

### **1. File Upload**
- ✅ PNG, JPG, SVG support
- ✅ 10MB file size limit
- ✅ Automatic upload to R2 → Printful
- ✅ Real-time progress feedback

### **2. Text Design**
- ✅ Custom text input
- ✅ Font size control (12-200px)
- ✅ Color picker
- ✅ Background color
- ✅ Multi-line support
- ✅ Live canvas preview

### **3. Product Customization**
- ✅ Size selection
- ✅ Color variants
- ✅ Placement options (front/back/left/right)
- ✅ Live mockup generation
- ✅ Pricing calculation

### **4. Preview & Mockups**
- ✅ Real-time design preview
- ✅ 3D product mockups
- ✅ Multiple placement views
- ✅ Zoom & rotate controls

---

## 🌍 **CLOUDFLARE WORKERS ADVANTAGES**

### **🚀 Performance**
- **200+ Edge Locations** worldwide
- **<1ms Cold Starts** (vs 50ms+ on other platforms)
- **Global KV Caching** for product data
- **R2 Storage** with global CDN

### **💰 Cost Efficiency**
- **$5/10M requests** (extremely cheap)
- **Free tier: 100k requests/day**
- **Pay per use** (no idle server costs)
- **Included bandwidth** with R2

### **🔧 Developer Experience**
- **TypeScript native** support
- **Local development** with Wrangler
- **Hot reloading** during development
- **Easy deployment** (`wrangler deploy`)

### **🛡️ Reliability**
- **99.99% Uptime** SLA
- **DDoS protection** included
- **Automatic scaling** to millions of requests
- **No server management** required

---

## 🔄 **PRINTFUL WORKFLOW**

### **1. Product Sync**
```
Printful → Workers → KV Cache → Frontend
```

### **2. Design Upload**
```
Frontend → Workers → R2 Storage → Printful File API
```

### **3. Mockup Generation**
```
Frontend → Workers → Printful Mockup API → Live Preview
```

### **4. Order Creation**
```
Frontend → Workers → Printful Orders API → Fulfillment
```

### **5. Status Updates**
```
Printful Webhooks → Workers → KV Storage → Frontend
```

---

## 📦 **DEPLOYMENT OPTIONS**

### **Option 1: Full Cloudflare** (Recommended)
- **Pages** for frontend hosting
- **Workers** for backend API
- **KV + R2** for storage
- **Custom domain** with SSL

### **Option 2: Hybrid**
- **Vercel/Netlify** for frontend
- **Cloudflare Workers** for backend
- **Cross-origin** configuration

### **Option 3: All-in-One**
- **Workers Sites** for static assets
- **Single deployment** command
- **Unified dashboard** management

---

## 🔐 **SECURITY FEATURES**

### **API Protection**
- ✅ **CORS** configuration
- ✅ **Rate limiting** built-in
- ✅ **API key** protection
- ✅ **Request validation**

### **File Upload Security**
- ✅ **File type** validation
- ✅ **Size limits** enforced
- ✅ **Virus scanning** (via R2)
- ✅ **Public URL** generation

### **Data Privacy**
- ✅ **GDPR compliant** caching
- ✅ **PII protection** in logs
- ✅ **Secure transmission** (HTTPS)
- ✅ **EU data residency** options

---

## 📊 **MONITORING & ANALYTICS**

### **Built-in Cloudflare Analytics**
- 📈 **Request metrics**
- 🚀 **Performance monitoring**
- 🛡️ **Security insights**
- 💰 **Cost tracking**

### **Custom Metrics**
```typescript
// Add to worker for custom tracking
console.log('Order created:', orderId);  // Appears in logs
ctx.waitUntil(analytics.track('order_created'));  // Custom analytics
```

### **Error Monitoring**
- 🚨 **Real-time alerts**
- 📊 **Error rate tracking**
- 🔍 **Request tracing**
- 📝 **Log aggregation**

---

## 🎯 **NEXT STEPS**

### **Phase 1: MVP** ✅
- [x] Basic Printful integration
- [x] Product listing
- [x] Design upload
- [x] Order creation

### **Phase 2: Enhanced UX**
- [ ] Advanced design tools
- [ ] 3D product previews
- [ ] Batch operations
- [ ] Mobile app support

### **Phase 3: Scale**
- [ ] Multi-vendor support
- [ ] International shipping
- [ ] Subscription orders
- [ ] Analytics dashboard

---

## 🆘 **TROUBLESHOOTING**

### **Common Issues**

#### **Worker not starting**
```bash
# Check wrangler.toml syntax
wrangler validate

# Check environment variables
wrangler secret list
```

#### **CORS errors**
```typescript
// Ensure CORS headers in worker:
headers: {
  'Access-Control-Allow-Origin': 'https://nexuno.eu',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}
```

#### **KV cache not working**
```bash
# Verify KV namespace binding
wrangler kv:namespace list

# Test KV operations
wrangler kv:key put --binding=PRINTFUL_CACHE "test" "value"
```

#### **Printful API errors**
- ✅ Check API key validity
- ✅ Verify store configuration
- ✅ Check request format
- ✅ Review rate limits

---

## 📞 **SUPPORT**

- 📧 **Email:** dev@nexuno.eu
- 📚 **Docs:** [Cloudflare Workers](https://developers.cloudflare.com/workers/)
- 🛠️ **Printful API:** [Printful Documentation](https://developers.printful.com/)
- 💬 **Community:** [Discord](https://discord.gg/nexuno)

---

**🚀 Ready to launch your global Print-on-Demand empire with Cloudflare Workers!**