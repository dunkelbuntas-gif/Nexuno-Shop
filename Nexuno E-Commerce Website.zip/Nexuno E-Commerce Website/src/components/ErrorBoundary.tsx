import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage?: string;
  retryCount: number;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  onError?: (error: string) => void;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  private retryTimeout: NodeJS.Timeout | null = null;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { 
      hasError: false, 
      retryCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { 
      hasError: true,
      errorMessage: error.message
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Enhanced error logging for timeout issues
    if (error.message.includes('timeout') || error.message.includes('getPage')) {
      console.warn('Timeout error detected:', {
        error: error.message,
        component: errorInfo.componentStack?.split('\n')[1]?.trim(),
        retryCount: this.state.retryCount
      });
    } else {
      console.warn('Component error caught:', error.name, error.message);
    }

    // Call optional error handler
    this.props.onError?.(error.message);
  }

  componentWillUnmount() {
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
    }
  }

  private handleRetry = () => {
    const newRetryCount = this.state.retryCount + 1;
    
    if (newRetryCount > 3) {
      console.warn('Max retry attempts reached, reloading page...');
      window.location.reload();
      return;
    }

    this.setState({ 
      hasError: false, 
      retryCount: newRetryCount,
      errorMessage: undefined
    });

    // Add delay for timeout-related errors
    if (this.state.errorMessage?.includes('timeout') || this.state.errorMessage?.includes('getPage')) {
      this.retryTimeout = setTimeout(() => {
        this.setState({ hasError: false });
      }, 2000);
    }
  };

  render() {
    if (this.state.hasError) {
      const isTimeoutError = this.state.errorMessage?.includes('timeout') || 
                            this.state.errorMessage?.includes('getPage');

      return this.props.fallback || (
        <div className="text-center py-6 px-4">
          <div className="bg-white/10 backdrop-blur border border-white/20 rounded-lg p-4 max-w-sm mx-auto">
            <h3 className="text-white font-medium mb-2">
              {isTimeoutError ? 'Verbindung wird hergestellt...' : 'Komponente wird geladen...'}
            </h3>
            <p className="text-slate-300 text-sm mb-3">
              {isTimeoutError 
                ? 'Die Anwendung benötigt einen Moment zum Laden.' 
                : 'Einen Moment bitte.'
              }
            </p>
            {this.state.retryCount < 3 ? (
              <button 
                onClick={this.handleRetry}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 
                           text-white px-4 py-2 rounded text-sm transition-all duration-200"
              >
                {isTimeoutError ? 'Verbindung wiederholen' : 'Erneut versuchen'}
                {this.state.retryCount > 0 && ` (${this.state.retryCount}/3)`}
              </button>
            ) : (
              <button 
                onClick={() => window.location.reload()}
                className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 
                           text-white px-4 py-2 rounded text-sm transition-all duration-200"
              >
                Seite neu laden
              </button>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;