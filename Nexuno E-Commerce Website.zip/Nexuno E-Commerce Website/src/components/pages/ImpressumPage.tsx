import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { BackButton } from '../BackButton';

interface ImpressumPageProps {
  onBack?: () => void;
}

export function ImpressumPage({ onBack }: ImpressumPageProps) {
  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-secondary)' }}>
      {/* Hero Section */}
      <section className="gradient-footer py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <div className="mb-8">
            <BackButton onBack={onBack} />
          </div>
          
          {/* Header */}
          <div className="text-center">
            <h1 className="mb-4 text-5xl font-bold text-white font-['Poppins']">
              <span className="bg-gradient-to-r from-[var(--accent-cyan)] to-[var(--accent-magenta)] bg-clip-text text-transparent">
                Impressum
              </span>
            </h1>
            <p className="text-xl text-slate-300 font-['Inter']">
              Angaben gemäß § 5 TMG
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

          <div className="content-box">
            <h2 className="text-3xl font-bold mb-8 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Firmeninformationen
            </h2>
            
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Unternehmen
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  André Schuman - Nexuno<br />
                  Fließstraße 6<br />
                  12439 Berlin<br />
                  Deutschland
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Kontakt
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Telefon: +49 30 12345678<br />
                  E-Mail: info@nexuno.eu<br />
                  Website: www.nexuno.eu
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Geschäftsführung
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  André Schumann
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Registereintrag
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Registergericht: Amtsgericht Berlin-Charlottenburg<br />
                  Registernummer: HRB 123456 B
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Umsatzsteuer-ID
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz:<br />
                  DE123456789
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Verantwortlich für den Inhalt
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  André Schumann<br />
                  Fließstraße 6<br />
                  12439 Berlin<br />
                  Deutschland
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Streitschlichtung
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:{' '}
                  <a 
                    href="https://ec.europa.eu/consumers/odr/" 
                    className="text-[var(--primary-blue)] hover:text-[var(--accent-cyan)] transition-colors duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    https://ec.europa.eu/consumers/odr/
                  </a>
                  <br /><br />
                  Unsere E-Mail-Adresse finden Sie oben im Impressum. Wir sind nicht bereit oder verpflichtet, 
                  an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Haftung für Inhalte
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den 
                  allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht 
                  unter der Verpflichtung, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach 
                  Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Haftung für Links
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. 
                  Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten 
                  Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Urheberrecht
                </h3>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen 
                  Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der 
                  Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}