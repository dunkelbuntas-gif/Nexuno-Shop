import React, { useState } from 'react';
import { ChevronDown, Package, CreditCard, RotateCcw, Truck, Shirt, Shield } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQCategory {
  id: string;
  title: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  questions: FAQItem[];
}

export function FashionFAQSection() {
  const [activeCategory, setActiveCategory] = useState('orders');
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({});

  const toggleItem = (categoryId: string, questionIndex: number) => {
    const key = `${categoryId}-${questionIndex}`;
    setOpenItems(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const faqCategories: FAQCategory[] = [
    {
      id: 'orders',
      title: 'Bestellungen & Versand',
      icon: <Truck className="h-5 w-5" />,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/20',
      questions: [
        {
          question: 'Wie lange dauert die Lieferung meiner Bestellung?',
          answer: 'Da wir Print-on-Demand verwenden, beträgt die Produktionszeit 3-5 Werktage. Der Versand dauert zusätzlich 2-4 Werktage innerhalb Deutschlands. Sie erhalten eine Tracking-Nummer sobald Ihr Artikel versendet wurde.'
        },
        {
          question: 'Kann ich meine Bestelldaten noch ändern?',
          answer: 'Änderungen sind nur möglich, solange die Bestellung noch nicht in Produktion gegangen ist. Kontaktieren Sie uns innerhalb von 2 Stunden nach der Bestellung per E-Mail oder Telefon.'
        },
        {
          question: 'Welche Versandkosten fallen an?',
          answer: 'Innerhalb Deutschlands: 4,99€ (kostenlos ab 50€). EU: 7,99€ (kostenlos ab 75€). Andere Länder: 12,99€. Express-Versand gegen Aufpreis verfügbar.'
        },
        {
          question: 'Liefert ihr auch ins Ausland?',
          answer: 'Ja, wir liefern in die gesamte EU sowie in die USA, Kanada, Australien und weitere Länder. Die Versandkosten und Lieferzeiten variieren je nach Zielland.'
        },
        {
          question: 'Wie kann ich den Status meiner Bestellung verfolgen?',
          answer: 'Nach dem Versand erhalten Sie automatisch eine E-Mail mit der Tracking-Nummer. Über den Link können Sie Ihre Sendung in Echtzeit verfolgen.'
        }
      ]
    },
    {
      id: 'products',
      title: 'Produkte & Qualität',
      icon: <Shirt className="h-5 w-5" />,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20',
      questions: [
        {
          question: 'Welche Materialien werden für die Kleidung verwendet?',
          answer: '100% Bio-Baumwolle (GOTS-zertifiziert) für T-Shirts, hochwertige Baumwoll-Polyester-Mischungen für Hoodies. Alle Materialien sind nachhaltig und hautfreundlich.'
        },
        {
          question: 'Wie fällt die Größe der Kleidungsstücke aus?',
          answer: 'Unsere Größen entsprechen der europäischen Größentabelle. Bei jedem Produkt finden Sie eine detaillierte Größentabelle. Im Zweifel empfehlen wir eine Nummer größer.'
        },
        {
          question: 'Sind die Drucke waschbeständig?',
          answer: 'Ja, wir verwenden DTG-Direktdruck (Direct-to-Garment) mit hochwertigen, umweltfreundlichen Tinten. Die Drucke sind waschbeständig bis 40°C und verblassen nicht.'
        },
        {
          question: 'Kann ich mein eigenes Design hochladen?',
          answer: 'Aktuell bieten wir nur unsere kuratierten Designs an. Custom-Designs sind für die Zukunft geplant. Folgen Sie uns für Updates!'
        },
        {
          question: 'Wie sieht es mit der Farbgenauigkeit aus?',
          answer: 'Wir verwenden kalibrierte Monitore und hochwertige Druckverfahren für maximale Farbgenauigkeit. Leichte Abweichungen können aufgrund verschiedener Bildschirme auftreten.'
        }
      ]
    },
    {
      id: 'returns',
      title: 'Rückgaben & Umtausch',
      icon: <RotateCcw className="h-5 w-5" />,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
      questions: [
        {
          question: 'Wie kann ich einen Artikel zurücksenden?',
          answer: 'Kontaktieren Sie uns binnen 14 Tagen nach Erhalt. Sie erhalten ein kostenloses Retourenlabel und detaillierte Anweisungen per E-Mail.'
        },
        {
          question: 'Kann ich die Größe umtauschen?',
          answer: 'Ja, Größenumtausch ist innerhalb von 14 Tagen möglich, sofern der Artikel ungetragen und mit Etiketten ist. Die Rücksendekosten übernehmen wir.'
        },
        {
          question: 'Wer übernimmt die Rücksendekosten?',
          answer: 'Bei Größenproblemen oder Qualitätsmängeln übernehmen wir die Kosten. Bei Nichtgefallen trägt der Kunde die Rücksendekosten (4,99€).'
        },
        {
          question: 'Wie lange habe ich Zeit für eine Rücksendung?',
          answer: 'Sie haben 14 Tage ab Erhalt der Ware Zeit für eine Rücksendung. Die Ware muss ungetragen und in der Originalverpackung sein.'
        },
        {
          question: 'Was passiert bei defekten Artikeln?',
          answer: 'Defekte Artikel tauschen wir sofort und kostenlos um. Senden Sie uns Fotos des Defekts und Sie erhalten umgehend Ersatz oder volle Rückerstattung.'
        }
      ]
    },
    {
      id: 'payment',
      title: 'Zahlung & Rechnung',
      icon: <CreditCard className="h-5 w-5" />,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/20',
      questions: [
        {
          question: 'Welche Zahlungsmethoden akzeptiert ihr?',
          answer: 'PayPal, Kreditkarte (Visa, Mastercard), SEPA-Lastschrift, Sofortüberweisung, Apple Pay, Google Pay und Klarna (Rechnung/Ratenkauf).'
        },
        {
          question: 'Ist der Kauf auf Rechnung möglich?',
          answer: 'Ja, über unseren Partner Klarna können Sie auf Rechnung kaufen (14 Tage Zahlungsziel) oder in Raten zahlen. Bonität wird automatisch geprüft.'
        },
        {
          question: 'Bekomme ich eine Rechnung für meine Bestellung?',
          answer: 'Ja, Sie erhalten automatisch eine Rechnung per E-Mail nach dem Versand. Für Geschäftskunden stellen wir gerne Rechnungen mit ausgewiesener MwSt. aus.'
        },
        {
          question: 'Wie sicher sind meine Zahlungsdaten?',
          answer: 'Alle Zahlungen werden über SSL-verschlüsselte Verbindungen abgewickelt. Wir speichern keine Kreditkartendaten und sind PCI-DSS zertifiziert.'
        }
      ]
    },
    {
      id: 'printondemand',
      title: 'Print-on-Demand',
      icon: <Package className="h-5 w-5" />,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20',
      questions: [
        {
          question: 'Was bedeutet "Print-on-Demand"?',
          answer: 'Wir produzieren Ihre Artikel erst nach der Bestellung. Das reduziert Verschwendung, ermöglicht nachhaltige Produktion und bietet Ihnen immer frische, hochwertige Ware.'
        },
        {
          question: 'Warum dauert die Produktion länger als bei anderen Shops?',
          answer: 'Jeder Artikel wird individuell für Sie gefertigt. Das dauert 3-5 Werktage, garantiert aber perfekte Qualität und frische Ware direkt vom Produzenten.'
        },
        {
          question: 'Kann ich vor der Bestellung eine Produktprobe sehen?',
          answer: 'Wir bieten detaillierte Produktfotos und 360°-Ansichten. Auf Anfrage können wir Ihnen Materialproben zusenden (gegen geringe Gebühr).'
        },
        {
          question: 'Sind individuelle Anpassungen möglich?',
          answer: 'Derzeit nicht, aber wir arbeiten an einem Custom-Design-Tool. Für Großbestellungen (50+ Stück) sind Sonderanfertigungen möglich.'
        }
      ]
    }
  ];

  const activeTab = faqCategories.find(cat => cat.id === activeCategory);

  return (
    <div className="bg-slate-900 rounded-3xl border border-slate-700 p-8 mb-12">
      <div className="flex items-center gap-3 mb-8">
        <Shield className="h-7 w-7 text-cyan-400" />
        <h2 className="text-2xl font-bold text-white">
          Häufig gestellte Fragen (FAQ)
        </h2>
      </div>

      {/* Category Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-8">
        {faqCategories.map((category) => (
          <button
            key={category.id}
            onClick={() => setActiveCategory(category.id)}
            className={`p-4 rounded-xl text-sm font-medium transition-all duration-300 flex flex-col items-center gap-2 hover:scale-105 ${
              activeCategory === category.id
                ? `${category.bgColor} ${category.color} border-2 border-current`
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border-2 border-transparent'
            }`}
          >
            <div className={`p-2 rounded-lg ${activeCategory === category.id ? 'bg-white/10' : 'bg-slate-700'}`}>
              {category.icon}
            </div>
            <span className="text-center leading-tight">{category.title}</span>
          </button>
        ))}
      </div>

      {/* FAQ Content */}
      {activeTab && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-700">
            <div className={`p-3 rounded-xl ${activeTab.bgColor}`}>
              <div className={activeTab.color}>
                {activeTab.icon}
              </div>
            </div>
            <h3 className="text-xl font-semibold text-white">{activeTab.title}</h3>
          </div>

          {activeTab.questions.map((faq, index) => {
            const isOpen = openItems[`${activeCategory}-${index}`];
            return (
              <div
                key={index}
                className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden transition-all duration-300 hover:border-slate-600"
              >
                <button
                  onClick={() => toggleItem(activeCategory, index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-750 transition-colors group"
                  aria-expanded={isOpen}
                >
                  <h4 className="font-medium text-white text-lg pr-4 group-hover:text-cyan-300 transition-colors">
                    {faq.question}
                  </h4>
                  <ChevronDown 
                    className={`h-5 w-5 text-slate-400 group-hover:text-cyan-400 transition-all duration-300 flex-shrink-0 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                
                {isOpen && (
                  <div className="px-6 pb-6 pt-2">
                    <div className="text-slate-300 leading-relaxed text-base">
                      {faq.answer}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}