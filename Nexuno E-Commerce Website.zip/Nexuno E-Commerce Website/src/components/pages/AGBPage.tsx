import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { BackButton } from '../BackButton';

interface AGBPageProps {
  onBack?: () => void;
}

export function AGBPage({ onBack }: AGBPageProps) {
  const sections = [
    {
      title: "1. Geltungsbereich",
      content: [
        "Diese Allgemeinen Geschäftsbedingungen (nachfolgend \"AGB\") gelten für alle Bestellungen über den Online-Shop von André Schuman - Nexuno, Fließstraße 6, 12439 Berlin.",
        "Abweichende Bedingungen des Kunden werden nicht anerkannt, es sei denn, der Verkäufer stimmt ihrer Geltung ausdrücklich zu."
      ]
    },
    {
      title: "2. Vertragsschluss",
      content: [
        "Die Darstellung der Produkte im Online-Shop stellt kein rechtlich bindendes Angebot, sondern einen unverbindlichen Online-Katalog dar.",
        "Durch Anklicken des Buttons \"Kaufen\" geben Sie eine verbindliche Bestellung ab. Der Kaufvertrag kommt mit der Bestätigung der Bestellung durch uns zustande."
      ]
    },
    {
      title: "3. Preise und Zahlungsbedingungen",
      content: [
        "Alle Preise verstehen sich inklusive der gesetzlichen Mehrwertsteuer und zuzüglich der Versandkosten.",
        "Die Zahlung erfolgt wahlweise per PayPal, Kreditkarte oder Überweisung. Bei Zahlungsausfällen behalten wir uns vor, Verzugszinsen zu berechnen."
      ]
    },
    {
      title: "4. Lieferung und Versand",
      content: [
        "Die Lieferung erfolgt an die vom Kunden angegebene Lieferadresse. Lieferzeiten sind unverbindlich, soweit nicht ausdrücklich als verbindlich bezeichnet.",
        "Versandkosten werden je nach Größe und Gewicht der Sendung sowie Lieferort berechnet und vor Abschluss der Bestellung angezeigt."
      ]
    },
    {
      title: "5. Eigentumsvorbehalt",
      content: [
        "Die gelieferte Ware bleibt bis zur vollständigen Bezahlung aller Forderungen aus dem Kaufvertrag unser Eigentum."
      ]
    },
    {
      title: "6. Widerrufsrecht",
      content: [
        "Verbrauchern steht ein Widerrufsrecht gemäß den gesetzlichen Bestimmungen zu. Einzelheiten regelt unsere Widerrufsbelehrung."
      ]
    },
    {
      title: "7. Gewährleistung",
      content: [
        "Es gelten die gesetzlichen Gewährleistungsbestimmungen. Mängel sind unverzüglich schriftlich anzuzeigen."
      ]
    },
    {
      title: "8. Haftung",
      content: [
        "Schadensersatzansprüche gegen uns sind ausgeschlossen, soweit sich aus den folgenden Bestimmungen nichts anderes ergibt.",
        "Vorstehender Haftungsausschluss gilt nicht für Schäden aus der Verletzung des Lebens, des Körpers oder der Gesundheit oder aus der Verletzung wesentlicher Vertragspflichten."
      ]
    },
    {
      title: "9. Datenschutz",
      content: [
        "Der Schutz Ihrer persönlichen Daten ist uns wichtig. Einzelheiten zur Erhebung und zum Umgang mit Ihren Daten entnehmen Sie unserer Datenschutzerklärung."
      ]
    },
    {
      title: "10. Schlussbestimmungen",
      content: [
        "Es gilt das Recht der Bundesrepublik Deutschland unter Ausschluss des UN-Kaufrechts.",
        "Gerichtsstand ist Berlin, sofern der Kunde Kaufmann, juristische Person des öffentlichen Rechts oder öffentlich-rechtliches Sondervermögen ist."
      ]
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Back Button */}
        <div className="mb-8">
          <BackButton variant="legal" onBack={onBack} />
        </div>
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="mb-4" style={{ 
            fontSize: '3rem',
            lineHeight: '3.5rem',
            fontWeight: '700',
            background: 'linear-gradient(135deg, var(--accent-pink) 0%, var(--accent-cyan) 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Allgemeine Geschäftsbedingungen
          </h1>
          <p style={{ 
            fontSize: '1.125rem',
            color: '#0F172A',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Gültig ab 01.01.2025
          </p>
        </div>

        <div className="content-box">
          <h2 style={{ 
            fontSize: '2rem',
            lineHeight: '2.5rem',
            fontWeight: '700',
            color: '#0F172A',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            marginBottom: '2rem'
          }}>
            Geschäftsbedingungen
          </h2>
          <div className="space-y-6">
            {sections.map((section, index) => (
              <div key={index}>
                <h3 style={{ 
                  fontSize: '1.25rem',
                  lineHeight: '1.75rem',
                  fontWeight: '600',
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  marginBottom: '0.5rem'
                }}>
                  {section.title}
                </h3>
                {section.content.map((paragraph, pIndex) => (
                  <p key={pIndex} style={{ 
                    color: '#0F172A',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    lineHeight: '1.6',
                    marginBottom: '0.5rem'
                  }}>
                    {paragraph}
                  </p>
                ))}
              </div>
            ))}

            <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: '1rem', marginTop: '2rem' }}>
              <p style={{ 
                color: '#0F172A',
                fontSize: '0.875rem',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                opacity: '0.8'
              }}>
                Stand: Januar 2025<br />
                André Schuman - Nexuno<br />
                Fließstraße 6, 12439 Berlin
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}