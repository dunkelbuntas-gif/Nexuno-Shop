import { useCart } from './CartContext';
export function CartPage({
  onBack, onCheckout, onContinueShopping, onProductClick
}: {
  onBack:()=>void; onCheckout:()=>void; onContinueShopping:()=>void; onProductClick:(id:string)=>void;
}) {
  const { items, clear } = useCart();
  return (
    <section style={{padding:24}}>
      <h2>Warenkorb</h2>
      <pre>{JSON.stringify(items, null, 2)}</pre>
      <button onClick={onCheckout}>Zur Kasse</button>{' '}
      <button onClick={onContinueShopping}>Weiter einkaufen</button>{' '}
      <button onClick={()=>onProductClick('demo')}>Produkt öffnen</button>{' '}
      <button onClick={clear}>Leeren</button>{' '}
      <button onClick={onBack}>Zurück</button>
    </section>
  );
}