import { ShoppingBag, ShoppingCart, Package, Layers3, Briefcase } from 'lucide-react';
import { useCart } from './CartContext';
import { motion } from 'motion/react';
import { useState } from 'react';

// Verschiedene coole Icon-Optionen für das Cart - aber erkennbar als Warenkorb
const CART_ICONS = {
  shoppingBag: ShoppingBag,    // Klassischer Shopping Bag - sehr erkennbar
  shoppingCart: ShoppingCart,  // Klassischer Warenkorb - am erkennbarsten
  package: Package,            // Moderne Paket-Box - für Delivery-Look
  layers: Layers3,             // 3D-Schichten - architektonisch aber weniger erkennbar
  briefcase: Briefcase,        // Business/Premium Look
};

export function CartIcon() {
  const { state, toggleCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  
  // Optimierte Icon-Auswahl für maximale Erkennbarkeit:
  // ShoppingBag als Standard (modern + erkennbar)
  // Bei Items im Cart: ShoppingCart für extra Klarheit
  const IconComponent = state.itemCount > 0 ? CART_ICONS.shoppingCart : CART_ICONS.shoppingBag;

  return (
    <motion.button
      onClick={toggleCart}
      className="relative group"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Glassmorphism Container mit futuristischen Effekten */}
      <motion.div
        className="relative p-3 rounded-xl backdrop-blur-20 transition-all duration-500"
        style={{
          background: isHovered 
            ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.25) 0%, rgba(96, 165, 250, 0.15) 100%)'
            : 'linear-gradient(135deg, rgba(255, 255, 255, 0.15) 0%, rgba(248, 250, 252, 0.1) 100%)',
          border: `1px solid ${isHovered ? 'rgba(96, 165, 250, 0.4)' : 'rgba(255, 255, 255, 0.2)'}`,
          boxShadow: isHovered 
            ? '0 8px 32px rgba(96, 165, 250, 0.2), 0 0 20px rgba(34, 211, 238, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)'
            : '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.8)'
        }}
        animate={{
          rotateY: isHovered ? 10 : 0,
          rotateX: isHovered ? -5 : 0,
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        {/* Holografische Reflektion */}
        <motion.div
          className="absolute inset-0 rounded-xl pointer-events-none"
          style={{
            background: 'linear-gradient(135deg, transparent 0%, rgba(96, 165, 250, 0.1) 25%, transparent 50%, rgba(34, 211, 238, 0.1) 75%, transparent 100%)',
            opacity: isHovered ? 0.8 : 0
          }}
          animate={{
            opacity: isHovered ? [0, 0.8, 0] : 0,
          }}
          transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
        />
        
        {/* Futuristisches Icon mit Glow-Effekt */}
        <motion.div
          className="relative z-10"
          animate={{
            rotateY: isHovered ? -10 : 0,
            scale: isHovered ? 1.1 : 1
          }}
          transition={{ duration: 0.3 }}
        >
          <IconComponent 
            size={22} 
            className="transition-all duration-300"
            style={{
              color: isHovered 
                ? 'var(--primary-blue)'
                : 'var(--text-headline)',
              filter: isHovered 
                ? 'drop-shadow(0 0 8px rgba(96, 165, 250, 0.6)) drop-shadow(0 0 16px rgba(34, 211, 238, 0.4))'
                : 'none'
            }}
          />
        </motion.div>

        {/* Architektonische Ecken-Details */}
        <div className="absolute top-1 left-1 w-2 h-2 border-l border-t border-blue-300/30 rounded-tl-sm" />
        <div className="absolute top-1 right-1 w-2 h-2 border-r border-t border-blue-300/30 rounded-tr-sm" />
        <div className="absolute bottom-1 left-1 w-2 h-2 border-l border-b border-cyan-300/30 rounded-bl-sm" />
        <div className="absolute bottom-1 right-1 w-2 h-2 border-r border-b border-cyan-300/30 rounded-br-sm" />
        
        {/* Fließender Lichtstrahl bei Hover */}
        {isHovered && (
          <motion.div
            className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent"
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
        )}
      </motion.div>
      
      {/* Counter Badge mit 3D-Effekt */}
      {state.itemCount > 0 && (
        <motion.div
          initial={{ scale: 0, rotateZ: -180 }}
          animate={{ scale: 1, rotateZ: 0 }}
          exit={{ scale: 0, rotateZ: 180 }}
          className="absolute -top-2 -right-2 min-w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
          style={{
            background: 'linear-gradient(135deg, var(--primary-blue) 0%, var(--accent-cyan) 100%)',
            boxShadow: '0 4px 12px rgba(30, 58, 138, 0.4), 0 2px 6px rgba(6, 182, 212, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.5)',
            border: '1px solid rgba(255, 255, 255, 0.3)'
          }}
          whileHover={{ scale: 1.1 }}
        >
          <motion.span
            key={state.itemCount}
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            style={{
              textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)'
            }}
          >
            {state.itemCount > 99 ? '99+' : state.itemCount}
          </motion.span>
          
          {/* Pulsierender Ring-Effekt */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-white/30"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.8, 0, 0.8]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </motion.div>
      )}
      
      {/* Ambient Glow Base */}
      <motion.div
        className="absolute inset-0 rounded-xl pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(96, 165, 250, 0.1) 0%, transparent 70%)',
          opacity: isHovered ? 0.8 : 0,
          filter: 'blur(8px)',
          transform: 'scale(1.5)'
        }}
        animate={{ opacity: isHovered ? 0.8 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  );
}