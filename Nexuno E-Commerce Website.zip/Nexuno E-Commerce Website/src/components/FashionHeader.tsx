import React, { lazy, Suspense } from 'react';
import { Search, ShoppingCart } from 'lucide-react';
import { motion } from 'motion/react';
import nexunoLogo from 'figma:asset/4ad9d5ae3940675aade2f657fdb6be9ab32df100.png';
import { PRODUCT_CATEGORIES } from '../src/lib/api';

// Lazy load SimpleChatDock for header integration
const SimpleChatDock = lazy(() => import('./chat/SimpleChatDock'));

interface FashionHeaderProps {
  currentPage?: string;
  selectedCategory?: string | null;
  cartCount?: number;
  onNavigationClick?: (page: string) => void;
  onCategoryClick?: (category: string) => void;
  onSearchClick?: () => void;
  onCartClick?: () => void;
  onContactPageNavigate?: () => void; // For chat escalation
}

export function FashionHeader({ 
  currentPage = 'home', 
  selectedCategory = null,
  cartCount = 0, 
  onNavigationClick, 
  onCategoryClick,
  onSearchClick, 
  onCartClick,
  onContactPageNavigate 
}: FashionHeaderProps) {
  // Dynamic navigation based on Printful categories
  const navigationItems = [
    { id: 'home', label: 'Home', type: 'page' as const },
    { id: 'tshirts', label: 'T-Shirts', type: 'category' as const, category: 'tshirts' },
    { id: 'hoodies', label: 'Hoodies', type: 'category' as const, category: 'hoodies' },
    { id: 'accessories', label: 'Accessories', type: 'category' as const, category: 'accessories' },
    { id: 'activewear', label: 'Activewear', type: 'category' as const, category: 'activewear' },
    { id: 'about', label: 'About', type: 'page' as const }
  ];

  const handleItemClick = (item: typeof navigationItems[0]) => {
    if (item.type === 'category' && item.category) {
      onCategoryClick?.(item.category);
    } else {
      onNavigationClick?.(item.id);
    }
  };

  const responsiveNavigationItems = {
    desktop: navigationItems,
    tablet: navigationItems.slice(0, 5), // Reduce by 1 item
    mobile: [
      { id: 'home', label: 'Home', type: 'page' as const },
      { id: 'tshirts', label: 'T-Shirts', type: 'category' as const, category: 'tshirts' },
      { id: 'hoodies', label: 'Hoodies', type: 'category' as const, category: 'hoodies' },
      { id: 'about', label: 'About', type: 'page' as const }
    ]
  };

  return (
    <motion.header
      className="fixed top-0 left-0 right-0 z-50 h-[70px] overflow-visible"
      initial={{ y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.25, 0.25, 0, 1] }}
      role="banner"
      aria-label="Hauptnavigation"
    >
      {/* Skip Link für Barrierefreiheit */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only absolute top-4 left-4 z-50 bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold"
      >
        Zum Hauptinhalt springen
      </a>

      {/* Glassmorphism Background */}
      <div 
        className="absolute inset-0 backdrop-blur-[24px]"
        style={{
          background: 'rgba(11, 19, 32, 0.8)', // #0b1320cc equivalent
          borderBottom: '1px solid rgba(6, 182, 212, 0.08)' // Subtle cyan underline
        }}
      >
        {/* Subtle Background Glow */}
        <motion.div
          className="absolute inset-0 opacity-30"
          animate={{
            background: [
              'linear-gradient(90deg, rgba(6, 182, 212, 0.05) 0%, transparent 50%, rgba(59, 130, 246, 0.05) 100%)',
              'linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, transparent 50%, rgba(6, 182, 212, 0.05) 100%)',
              'linear-gradient(90deg, rgba(6, 182, 212, 0.05) 0%, transparent 50%, rgba(59, 130, 246, 0.05) 100%)'
            ]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        
        {/* Bottom Light Line */}
        <div 
          className="absolute bottom-0 left-0 right-0 h-px"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.8), transparent)',
            opacity: 0.08
          }}
        />
      </div>

      {/* Main Header Content */}
      <div className="relative z-10 max-w-7xl mx-auto h-full flex items-center justify-between px-6 lg:px-12 xl:px-16">
        
        {/* Logo Container (Left) */}
        <motion.div 
          className="flex items-center"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <button
            onClick={() => onNavigationClick?.('home')}
            className="flex items-center space-x-3 group focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800 rounded-lg p-2"
            aria-label="Nexuno Startseite - Fashion der Zukunft"
          >
            <img 
              src={nexunoLogo}
              alt="NEXUNO - Fashion der Zukunft" 
              className="h-16 w-auto object-contain group-hover:scale-105 transition-all duration-300"
              style={{
                filter: 'drop-shadow(0 0 8px rgba(34, 211, 238, 0.3))'
              }}
            />
          </button>
        </motion.div>

        {/* Navigation (Center) */}
        <nav 
          className="hidden lg:flex items-center space-x-1"
          role="navigation"
          aria-label="Hauptnavigation"
        >
          {responsiveNavigationItems.desktop.map((item, index) => {
            const isActive = item.type === 'page' 
              ? currentPage === item.id 
              : item.type === 'category' && selectedCategory === item.category;
            
            return (
              <motion.button
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`relative px-4 py-2 rounded-full transition-all duration-300 font-semibold text-sm cursor-pointer focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-teal-600 text-white'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.05,
                  boxShadow: isActive 
                    ? '0 0 20px rgba(6, 182, 212, 0.4)' 
                    : '0 0 15px rgba(255, 255, 255, 0.1)'
                }}
                whileTap={{ scale: 0.98 }}
                aria-current={isActive ? 'page' : undefined}
                aria-label={`${item.label} ${item.type === 'category' ? 'Kategorie' : 'Seite'}`}
              >
                <span className="relative z-10">{item.label}</span>
                
                {/* Active State Glow */}
                {isActive && (
                  <motion.div
                    className="absolute inset-0 rounded-full"
                    animate={{
                      boxShadow: [
                        '0 0 0 0 rgba(6, 182, 212, 0.4)',
                        '0 0 0 4px rgba(6, 182, 212, 0.1)',
                        '0 0 0 0 rgba(6, 182, 212, 0.4)'
                      ]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}
              </motion.button>
            );
          })}
        </nav>

        {/* Tablet Navigation */}
        <nav 
          className="hidden md:flex lg:hidden items-center space-x-1"
          role="navigation"
          aria-label="Navigation"
        >
          {responsiveNavigationItems.tablet.map((item, index) => {
            const isActive = item.type === 'page' 
              ? currentPage === item.id 
              : item.type === 'category' && selectedCategory === item.category;
            
            return (
              <motion.button
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`relative px-3 py-2 rounded-full transition-all duration-300 font-semibold text-sm cursor-pointer focus:outline-none focus:ring-3 focus:ring-yellow-400 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-teal-600 text-white'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                aria-current={isActive ? 'page' : undefined}
                aria-label={`${item.label} ${item.type === 'category' ? 'Kategorie' : 'Seite'}`}
              >
                {item.label}
              </motion.button>
            );
          })}
        </nav>

        {/* Mobile Navigation */}
        <nav 
          className="flex md:hidden items-center space-x-1"
          role="navigation"
          aria-label="Mobile Navigation"
        >
          {responsiveNavigationItems.mobile.map((item, index) => {
            const isActive = item.type === 'page' 
              ? currentPage === item.id 
              : item.type === 'category' && selectedCategory === item.category;
            
            return (
              <motion.button
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`relative px-2 py-1.5 rounded-lg transition-all duration-300 font-semibold text-xs cursor-pointer focus:outline-none focus:ring-3 focus:ring-yellow-400 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-teal-600 text-white'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                aria-current={isActive ? 'page' : undefined}
                aria-label={`${item.label} ${item.type === 'category' ? 'Kategorie' : 'Seite'}`}
              >
                {item.label}
              </motion.button>
            );
          })}
        </nav>

        {/* Actions (Right) */}
        <div className="flex items-center space-x-3">
          
          {/* Search Button */}
          <motion.button
            onClick={onSearchClick}
            className="relative w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 hover:border-cyan-400/30 transition-all duration-300 flex items-center justify-center group cursor-pointer focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800"
            whileHover={{ 
              scale: 1.1,
              boxShadow: '0 0 15px rgba(6, 182, 212, 0.3)'
            }}
            whileTap={{ scale: 0.95 }}
            aria-label="Produktsuche öffnen"
          >
            <Search className="w-4 h-4 text-white/80 group-hover:text-cyan-300 transition-colors" aria-hidden="true" />
            
            {/* Subtle Glow */}
            <motion.div
              className="absolute inset-0 rounded-full bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0, 0.3, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </motion.button>

          {/* Cart Button */}
          <motion.button
            onClick={onCartClick}
            className="relative w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 hover:border-cyan-400/30 transition-all duration-300 flex items-center justify-center group cursor-pointer focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800"
            whileHover={{ 
              scale: 1.1,
              boxShadow: '0 0 15px rgba(6, 182, 212, 0.3)'
            }}
            whileTap={{ scale: 0.95 }}
            aria-label={`Warenkorb öffnen${cartCount > 0 ? `, ${cartCount} ${cartCount === 1 ? 'Artikel' : 'Artikel'}` : ', leer'}`}
          >
            <ShoppingCart className="w-4 h-4 text-white/80 group-hover:text-cyan-300 transition-colors" aria-hidden="true" />
            
            {/* Cart Count Badge */}
            {cartCount > 0 && (
              <motion.span
                className="absolute -top-1 -right-1 bg-gradient-to-r from-cyan-500 to-teal-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold border border-white/30"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                aria-hidden="true"
              >
                {cartCount > 99 ? '99+' : cartCount}
              </motion.span>
            )}
            
            {/* Subtle Glow */}
            <motion.div
              className="absolute inset-0 rounded-full bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0, 0.3, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.5,
              }}
            />
          </motion.button>

          {/* Chat Button - Integrated in Header */}
          <Suspense fallback={
            <div className="h-10 px-4 bg-white/10 rounded-lg animate-pulse" />
          }>
            <SimpleChatDock 
              position="header-integrated"
              onEscalateToHuman={() => onContactPageNavigate?.()}
            />
          </Suspense>
        </div>
      </div>


    </motion.header>
  );
}