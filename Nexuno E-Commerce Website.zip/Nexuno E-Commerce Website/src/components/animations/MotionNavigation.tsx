import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart } from 'lucide-react';

interface FloatingCartButtonProps {
  cartCount: number;
  onClick: () => void;
  className?: string;
}

export function FloatingCartButton({ cartCount, onClick, className = '' }: FloatingCartButtonProps) {
  return (
    <motion.button
      className={`fixed bottom-6 right-6 z-40 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-full p-4 shadow-lg ${className}`}
      onClick={onClick}
      whileHover={{ 
        scale: 1.1,
        boxShadow: '0 8px 25px rgba(6, 182, 212, 0.4)'
      }}
      whileTap={{ scale: 0.95 }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 20
      }}
      drag
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      dragElastic={0.2}
    >
      <ShoppingCart className="h-6 w-6" />
      <AnimatePresence>
        {cartCount > 0 && (
          <motion.span
            key={cartCount}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ 
              type: "spring", 
              stiffness: 500, 
              damping: 20 
            }}
            className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold"
          >
            {cartCount > 99 ? '99+' : cartCount}
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
}