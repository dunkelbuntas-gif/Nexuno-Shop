import { Sparkles, Target, Users, Zap } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { BackButton } from '../BackButton';

interface AboutPageProps {
  onBack?: () => void;
}

export function AboutPage({ onBack }: AboutPageProps) {
  const values = [
    {
      icon: Target,
      title: 'Vision',
      description: 'Wir gestalten die Zukunft der Mode - minimalistisch, nachhaltig und immer einen Schritt voraus.'
    },
    {
      icon: Sparkles,
      title: 'Innovation',
      description: 'Jedes Design entsteht durch die Fusion von Technologie, Kreativität und zukunftsweisenden Materialien.'
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Unsere Community teilt die Leidenschaft für authentische, rebellische Mode der Zukunft.'
    },
    {
      icon: Zap,
      title: 'Nachhaltigkeit',
      description: 'Verantwortungsvolle Produktion für eine bessere Zukunft - für uns und kommende Generationen.'
    }
  ];

  const teamMembers = [
    {
      name: 'André Schumann',
      role: 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1614028609503-590a6a47146a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxjcmVhdGl2ZSUyMHRlYW0lMjBmYXNoaW9uJTIwZGVzaWduZXJzfGVufDF8fHx8MTc1NjI0MzkwNXww&ixlib=rb-4.1.0&q=80&w=400'
    },
    {
      name: 'Jonas Müller',
      role: 'Sustainability Lead',
      image: 'https://images.unsplash.com/photo-1614028609503-590a6a47146a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxjcmVhdGl2ZSUyMHRlYW0lMjBmYXNoaW9uJTIwZGVzaWduZXJzfGVufDF8fHx8MTc1NjI0MzkwNXww&ixlib=rb-4.1.0&q=80&w=400'
    }
  ];

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-secondary)' }}>
      {/* Hero Section */}
      <section className="gradient-footer py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <div className="mb-8">
            <BackButton onBack={onBack} />
          </div>
          
          {/* Header */}
          <div className="text-center">
            <h1 className="mb-6 text-5xl font-bold text-white font-['Poppins']">
              <span className="bg-gradient-to-r from-[var(--accent-cyan)] to-[var(--accent-magenta)] bg-clip-text text-transparent">
                Beyond Fashion – it's a Statement.
              </span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto font-['Inter']" style={{ lineHeight: '1.7' }}>
              Nexuno steht für futuristische Mode, die minimalistisch und rebellisch zugleich ist. 
              Wir erschaffen nicht nur Kleidung – wir kreieren Statements für eine neue Generation.
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Story Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="content-box">
              <h2 className="text-4xl font-bold mb-6 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                Unsere Geschichte
              </h2>
              <div className="space-y-6">
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Gegründet 2023 mit der Vision, Mode neu zu definieren. Nexuno entstand aus der 
                  Überzeugung, dass Fashion mehr sein kann als nur Trends – es kann ein Statement 
                  für die Zukunft sein.
                </p>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Inspiriert von der digitalen Revolution und dem Wunsch nach authentischem 
                  Ausdruck, verbinden wir minimalistisches Design mit futuristischen Elementen. 
                  Jedes Piece erzählt eine Geschichte von Innovation und Individualität.
                </p>
                <p className="text-lg font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  Heute steht Nexuno für eine Community von Visionären, die nicht nur Mode tragen, 
                  sondern die Zukunft gestalten. Minimalistisch. Modern. Für dich gemacht.
                </p>
              </div>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1633767448607-64876fa0978e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwZmFzaGlvbiUyMG1vZGVsJTIwaG9vZGllJTIwbmVvbnxlbnwxfHx8fDE3NTYyNDM4OTB8MA&ixlib=rb-4.1.0&q=80&w=600"
                alt="Nexuno Story"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -inset-4 bg-gradient-to-r from-[var(--accent-cyan)] via-[var(--accent-pink)] to-[var(--accent-violet)] rounded-2xl -z-10 opacity-20 blur-lg"></div>
          </div>
        </div>

        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Unsere Werte
            </h2>
            <p className="text-lg font-['Inter'] max-w-2xl mx-auto" style={{ color: 'var(--text-body)' }}>
              Diese Prinzipien leiten uns bei allem, was wir tun
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="content-box text-center">
                <div 
                  className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center gradient-primary"
                >
                  <value.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-4 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  {value.title}
                </h3>
                <p className="font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Das Team
            </h2>
            <p className="text-lg font-['Inter'] max-w-2xl mx-auto" style={{ color: 'var(--text-body)' }}>
              Kreative Köpfe, die die Zukunft der Mode gestalten
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
            {teamMembers.map((member, index) => (
              <div key={index} className="content-box group cursor-pointer">
                <div className="aspect-square overflow-hidden rounded-lg mb-4">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold mb-2 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                    {member.name}
                  </h3>
                  <p className="font-medium font-['Inter']" style={{ color: 'var(--primary-blue)' }}>
                    {member.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          <div className="content-box text-center">
            <h2 className="text-4xl font-bold mb-6 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Bereit für die Zukunft?
            </h2>
            <p className="text-lg font-['Inter'] mb-8 max-w-2xl mx-auto" style={{ color: 'var(--text-body)' }}>
              Werde Teil der Nexuno Community und gestalte mit uns die Zukunft der Mode.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary px-8 py-3">
                Shop entdecken
              </button>
              <button className="btn-secondary px-8 py-3">
                Newsletter abonnieren
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}