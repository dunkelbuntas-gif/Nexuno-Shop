import { ShoppingBag, ShoppingCart, Package, Briefcase, ShoppingBasket } from 'lucide-react';
import { useCart } from './CartContext';
import { motion } from 'motion/react';
import { useState } from 'react';

// Erkennbare Warenkorb-Icons mit verschiedenen Stilen
const RECOGNIZABLE_CART_ICONS = {
  // Am erkennbarsten - klassische Warenkorb-Symbole
  shoppingCart: {
    icon: ShoppingCart,
    name: 'Shopping Cart',
    recognizability: 10, // Skala 1-10
    description: 'Klassischer Warenkorb - sofort erkennbar'
  },
  shoppingBag: {
    icon: ShoppingBag,
    name: 'Shopping Bag',
    recognizability: 9,
    description: 'Moderne Einkaufstasche - sehr erkennbar'
  },
  shoppingBasket: {
    icon: ShoppingBasket,
    name: 'Shopping Basket',
    recognizability: 8,
    description: 'Einkaufskorb - traditionell erkennbar'
  },
  
  // Weniger erkennbar aber moderner
  package: {
    icon: Package,
    name: 'Package',
    recognizability: 6,
    description: 'Paket-Symbol - für E-Commerce geeignet'
  },
  briefcase: {
    icon: Briefcase,
    name: 'Briefcase',
    recognizability: 4,
    description: 'Business-Tasche - weniger erkennbar als Cart'
  }
};

interface CartIconRecognizableProps {
  variant?: keyof typeof RECOGNIZABLE_CART_ICONS;
  style?: 'classic' | 'modern' | 'futuristic';
  showTooltip?: boolean;
}

export function CartIconRecognizable({ 
  variant = 'shoppingBag', 
  style = 'futuristic',
  showTooltip = false 
}: CartIconRecognizableProps) {
  const { state, toggleCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  
  const iconConfig = RECOGNIZABLE_CART_ICONS[variant];
  const IconComponent = iconConfig.icon;

  // Style-spezifische Konfigurationen
  const styleConfigs = {
    classic: {
      container: 'p-2 rounded-lg bg-white border border-gray-300 shadow-sm hover:shadow-md',
      icon: 'text-gray-700 hover:text-blue-600',
      effects: false
    },
    modern: {
      container: 'p-3 rounded-xl bg-white/80 backdrop-blur-sm border border-gray-200/60 shadow-lg hover:shadow-xl',
      icon: 'text-gray-800 hover:text-blue-600',
      effects: true
    },
    futuristic: {
      container: 'p-3 rounded-xl backdrop-blur-20',
      icon: '',
      effects: true
    }
  };

  const currentStyle = styleConfigs[style];

  return (
    <div className="relative">
      <motion.button
        onClick={toggleCart}
        className="relative group"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Futuristischer Container (wie vorher) */}
        {style === 'futuristic' ? (
          <motion.div
            className="relative p-3 rounded-xl backdrop-blur-20 transition-all duration-500"
            style={{
              background: isHovered 
                ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.25) 0%, rgba(96, 165, 250, 0.15) 100%)'
                : 'linear-gradient(135deg, rgba(255, 255, 255, 0.15) 0%, rgba(248, 250, 252, 0.1) 100%)',
              border: `1px solid ${isHovered ? 'rgba(96, 165, 250, 0.4)' : 'rgba(255, 255, 255, 0.2)'}`,
              boxShadow: isHovered 
                ? '0 8px 32px rgba(96, 165, 250, 0.2), 0 0 20px rgba(34, 211, 238, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)'
                : '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.8)'
            }}
            animate={{
              rotateY: isHovered ? 10 : 0,
              rotateX: isHovered ? -5 : 0,
            }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {/* Holographische Reflektion */}
            <motion.div
              className="absolute inset-0 rounded-xl pointer-events-none"
              style={{
                background: 'linear-gradient(135deg, transparent 0%, rgba(96, 165, 250, 0.1) 25%, transparent 50%, rgba(34, 211, 238, 0.1) 75%, transparent 100%)',
                opacity: isHovered ? 0.8 : 0
              }}
              animate={{ opacity: isHovered ? [0, 0.8, 0] : 0 }}
              transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
            />
            
            {/* Icon mit Glow-Effekt */}
            <motion.div
              className="relative z-10"
              animate={{
                rotateY: isHovered ? -10 : 0,
                scale: isHovered ? 1.1 : 1
              }}
              transition={{ duration: 0.3 }}
            >
              <IconComponent 
                size={22} 
                className="transition-all duration-300"
                style={{
                  color: isHovered 
                    ? 'var(--primary-blue)'
                    : 'var(--text-headline)',
                  filter: isHovered 
                    ? 'drop-shadow(0 0 8px rgba(96, 165, 250, 0.6)) drop-shadow(0 0 16px rgba(34, 211, 238, 0.4))'
                    : 'none'
                }}
              />
            </motion.div>

            {/* Architektonische Ecken-Details */}
            <div className="absolute top-1 left-1 w-2 h-2 border-l border-t border-blue-300/30 rounded-tl-sm" />
            <div className="absolute top-1 right-1 w-2 h-2 border-r border-t border-blue-300/30 rounded-tr-sm" />
            <div className="absolute bottom-1 left-1 w-2 h-2 border-l border-b border-cyan-300/30 rounded-bl-sm" />
            <div className="absolute bottom-1 right-1 w-2 h-2 border-r border-b border-cyan-300/30 rounded-br-sm" />
            
            {/* Fließender Lichtstrahl bei Hover */}
            {isHovered && (
              <motion.div
                className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent"
                initial={{ x: '-100%' }}
                animate={{ x: '100%' }}
                transition={{ duration: 0.8, ease: "easeInOut" }}
              />
            )}
          </motion.div>
        ) : (
          /* Klassische/Modern Styles */
          <div className={currentStyle.container}>
            <IconComponent 
              size={22} 
              className={`transition-all duration-300 ${currentStyle.icon}`}
            />
          </div>
        )}
        
        {/* Counter Badge (einheitlich für alle Styles) */}
        {state.itemCount > 0 && (
          <motion.div
            initial={{ scale: 0, rotateZ: -180 }}
            animate={{ scale: 1, rotateZ: 0 }}
            exit={{ scale: 0, rotateZ: 180 }}
            className="absolute -top-2 -right-2 min-w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
            style={{
              background: style === 'futuristic' 
                ? 'linear-gradient(135deg, var(--primary-blue) 0%, var(--accent-cyan) 100%)'
                : 'linear-gradient(135deg, #3B82F6 0%, #06B6D4 100%)',
              boxShadow: style === 'futuristic'
                ? '0 4px 12px rgba(30, 58, 138, 0.4), 0 2px 6px rgba(6, 182, 212, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.5)'
                : '0 4px 12px rgba(59, 130, 246, 0.4)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
            whileHover={{ scale: 1.1 }}
          >
            <motion.span
              key={state.itemCount}
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              style={{ textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)' }}
            >
              {state.itemCount > 99 ? '99+' : state.itemCount}
            </motion.span>
            
            {/* Pulsierender Ring-Effekt nur bei futuristic */}
            {style === 'futuristic' && (
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-white/30"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.8, 0, 0.8]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
          </motion.div>
        )}
        
        {/* Ambient Glow Base nur bei futuristic */}
        {style === 'futuristic' && (
          <motion.div
            className="absolute inset-0 rounded-xl pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(96, 165, 250, 0.1) 0%, transparent 70%)',
              opacity: isHovered ? 0.8 : 0,
              filter: 'blur(8px)',
              transform: 'scale(1.5)'
            }}
            animate={{ opacity: isHovered ? 0.8 : 0 }}
            transition={{ duration: 0.3 }}
          />
        )}
      </motion.button>
      
      {/* Tooltip für bessere Erkennbarkeit */}
      {showTooltip && isHovered && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-2 py-1 bg-gray-900 text-white text-xs rounded whitespace-nowrap z-50"
        >
          {iconConfig.description}
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-b-gray-900"></div>
        </motion.div>
      )}
    </div>
  );
}

// Vordefinierte erkennbare Varianten
export function CartIconClassic() {
  return <CartIconRecognizable variant="shoppingCart" style="classic" />;
}

export function CartIconModern() {
  return <CartIconRecognizable variant="shoppingBag" style="modern" />;
}

export function CartIconFuturistic() {
  return <CartIconRecognizable variant="shoppingBag" style="futuristic" />;
}

// Für Extra-Erkennbarkeit
export function CartIconUltraRecognizable() {
  return <CartIconRecognizable variant="shoppingCart" style="futuristic" showTooltip={true} />;
}