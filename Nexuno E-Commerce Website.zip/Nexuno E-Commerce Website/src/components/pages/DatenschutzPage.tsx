import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { BackButton } from '../BackButton';

interface DatenschutzPageProps {
  onBack?: () => void;
}

export function DatenschutzPage({ onBack }: DatenschutzPageProps) {
  const sections = [
    {
      title: "1. Verantwortlicher",
      content: [
        "André Schumann – Nexuno, Fließstraße 6, 12439 Berlin",
        "E-Mail: info@nexuno.eu"
      ]
    },
    {
      title: "2. Erhebung & Speicherung personenbezogener Daten",
      content: [
        "Wir erheben und speichern personenbezogene Daten, die Sie uns freiwillig übermitteln (z. B. bei Bestellung oder Kontaktaufnahme). Dazu gehören: Name, Anschrift, E-Mail, Telefonnummer, Zahlungs- sowie Bestell-/Lieferdaten.",
        "Die Rechtsgrundlage für die Verarbeitung ist Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung) und Art. 6 Abs. 1 lit. f DSGVO (berechtigte Interessen)."
      ]
    },
    {
      title: "3. Hosting & CDN",
      content: [
        "Unsere Website wird bei Netlify gehostet. Beim Aufruf der Website werden technisch notwendige Zugriffsdaten (IP-Adresse, Zeitpunkt, Browser) verarbeitet.",
        "Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO (berechtigte Interessen zur Bereitstellung der Website)."
      ]
    },
    {
      title: "4. Weitergabe von Daten",
      content: [
        "Eine Weitergabe erfolgt nur an Dienstleister zur Vertragserfüllung: Zahlungsdienste (z. B. Stripe, PayPal) und Versandunternehmen (z. B. DHL/Hermes).",
        "Diese Dienstleister sind vertraglich zur Einhaltung der datenschutzrechtlichen Bestimmungen verpflichtet."
      ]
    },
    {
      title: "5. Cookies & Tracking",
      content: [
        "Wir verwenden technisch notwendige Cookies zur Funktionsfähigkeit der Website. Derzeit setzen wir keine Tracking-Tools wie Google Analytics ein.",
        "Sie können Cookies in Ihrem Browser deaktivieren, dies kann jedoch die Funktionalität der Website beeinträchtigen."
      ]
    },
    {
      title: "6. Zahlungsanbieter",
      content: [
        "Bei Nutzung von externen Zahlungsdienstleistern werden Ihre Zahlungsdaten direkt an diese übermittelt. Es gelten zusätzlich deren Datenschutzerklärungen.",
        "Wir speichern keine Kreditkartendaten oder Bankverbindungen."
      ]
    },
    {
      title: "7. Ihre Rechte",
      content: [
        "Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Widerspruch und Datenübertragbarkeit.",
        "Sie können Ihre Einwilligung jederzeit widerrufen. Wenden Sie sich hierzu an info@nexuno.eu.",
        "Sie haben das Recht, sich bei einer Datenschutz-Aufsichtsbehörde zu beschweren."
      ]
    },
    {
      title: "8. Speicherdauer",
      content: [
        "Personenbezogene Daten werden nur solange gespeichert, wie es für die Zweckerfüllung erforderlich ist oder gesetzliche Aufbewahrungsfristen bestehen.",
        "Bestelldaten werden gemäß handels- und steuerrechtlichen Vorschriften für 10 Jahre aufbewahrt."
      ]
    },
    {
      title: "9. SSL-Verschlüsselung",
      content: [
        "Diese Website nutzt SSL-Verschlüsselung zum Schutz der Datenübertragung. Verschlüsselte Verbindungen erkennen Sie an dem Schlosssymbol in der Adresszeile Ihres Browsers."
      ]
    },
    {
      title: "10. Kontakt bei Datenschutzfragen",
      content: [
        "Bei Fragen zum Datenschutz wenden Sie sich bitte an:",
        "André Schuman - Nexuno, Fließstraße 6, 12439 Berlin",
        "E-Mail: info@nexuno.eu"
      ]
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Back Button */}
        <div className="mb-8">
          <BackButton variant="legal" onBack={onBack} />
        </div>
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="mb-4" style={{ 
            fontSize: '3rem',
            lineHeight: '3.5rem',
            fontWeight: '700',
            background: 'linear-gradient(135deg, var(--accent-pink) 0%, var(--accent-cyan) 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Datenschutzerklärung
          </h1>
          <p style={{ 
            fontSize: '1.125rem',
            color: '#0F172A',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Informationen zum Umgang mit Ihren personenbezogenen Daten
          </p>
        </div>

        <div className="content-box">
          <h2 style={{ 
            fontSize: '2rem',
            lineHeight: '2.5rem',
            fontWeight: '700',
            color: '#0F172A',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            marginBottom: '2rem'
          }}>
            Datenschutz
          </h2>
          <div className="space-y-6">
            {sections.map((section, index) => (
              <div key={index}>
                <h3 style={{ 
                  fontSize: '1.25rem',
                  lineHeight: '1.75rem',
                  fontWeight: '600',
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  marginBottom: '0.5rem'
                }}>
                  {section.title}
                </h3>
                {section.content.map((paragraph, pIndex) => (
                  <p key={pIndex} style={{ 
                    color: '#0F172A',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    lineHeight: '1.6',
                    marginBottom: '0.5rem'
                  }}>
                    {paragraph}
                  </p>
                ))}
              </div>
            ))}

            <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: '1rem', marginTop: '2rem' }}>
              <p style={{ 
                color: '#0F172A',
                fontSize: '0.875rem',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                opacity: '0.8'
              }}>
                Stand: Januar 2025<br />
                André Schuman - Nexuno<br />
                Fließstraße 6, 12439 Berlin
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}