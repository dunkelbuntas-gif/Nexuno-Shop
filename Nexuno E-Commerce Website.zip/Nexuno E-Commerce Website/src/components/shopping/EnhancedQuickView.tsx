/**
 * ⚠️ COMPONENT REMOVED - USE EnhancedQuickViewModal INSTEAD
 * 
 * This component has been migrated to EnhancedQuickViewModal in /components/product/
 * Please update your imports to use the new component:
 * 
 * OLD: import { EnhancedQuickView } from '../shopping/EnhancedQuickView';
 * NEW: import { EnhancedQuickViewModal } from '../product/EnhancedQuickViewModal';
 * 
 * The new component offers better TypeScript support, improved accessibility,
 * and enhanced functionality.
 */

export function EnhancedQuickView() {
  console.error('⚠️ EnhancedQuickView has been removed. Use EnhancedQuickViewModal from /components/product/ instead.');
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-lg p-8 max-w-md mx-4">
        <h2 className="text-xl font-bold mb-4 text-red-600">Component Deprecated</h2>
        <p className="text-gray-700 mb-4">
          EnhancedQuickView has been replaced with EnhancedQuickViewModal.
        </p>
        <p className="text-sm text-gray-600">
          Please update your imports to use the new component from /components/product/
        </p>
      </div>
    </div>
  );
}

export default EnhancedQuickView;