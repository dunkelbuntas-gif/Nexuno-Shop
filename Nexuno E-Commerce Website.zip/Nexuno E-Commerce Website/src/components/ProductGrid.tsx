/**
 * ProductGrid - Lokales Produktsystem (KEINE APIs)
 * 
 * Zeigt Produkte aus lokalen statischen Daten an
 */

import React, { useState, useEffect } from 'react';
import { NEXUNO_PRODUCTS, getProductsByCategory, getCategories, searchProducts, type Product } from '../lib/local-products';
import { CategoryQuickNav } from './CategoryQuickNav';
import { ProductSearch } from './ProductSearch';
import { toast } from 'sonner@2.0.3';
import { Heart, ShoppingCart, Eye, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductGridProps {
  selectedCategory?: string | null;
  onProductClick?: (productId: string) => void;
  category?: string;
  featured?: boolean;
}

// Product Card Component (Inline)
interface ProductCardProps {
  product: {
    id: string;
    name: string;
    price: number;
    thumbnail_url: string;
    description: string;
    category: string;
    categoryName: string;
    variants: number;
    images: { url: string; type: string; alt: string; }[];
    imageCount: number;
  };
  onQuickView: (productId: string) => void;
  onAddToWishlist: (productId: string) => void;
}

function ProductCard({ product, onQuickView, onAddToWishlist }: ProductCardProps) {
  return (
    <Card 
      className="group relative overflow-hidden hover:shadow-xl transition-all duration-300 border-slate-700 bg-slate-900/50 backdrop-blur-sm"
      role="article"
      aria-labelledby={`product-title-${product.id}`}
    >
      <div className="relative overflow-hidden">
        <ImageWithFallback
          src={product.thumbnail_url}
          alt={`${product.name} - ${product.description}`}
          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
        />
        
        {/* Overlay Buttons */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => onQuickView(product.id)}
              className="bg-white/90 hover:bg-white text-slate-900 focus:outline-none focus:ring-3 focus:ring-yellow-400"
              aria-label={`${product.name} Schnellansicht öffnen`}
            >
              <Eye className="h-4 w-4 mr-1" aria-hidden="true" />
              Quick View
            </Button>
          </div>
        </div>

        {/* Wishlist Button */}
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onAddToWishlist(product.id)}
          className="absolute top-3 right-3 bg-white/80 hover:bg-white text-slate-900 h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 focus:outline-none focus:ring-3 focus:ring-yellow-400"
          aria-label={`${product.name} zur Wunschliste hinzufügen`}
        >
          <Heart className="h-4 w-4" aria-hidden="true" />
        </Button>

        {/* Category Badge */}
        <Badge className="absolute top-3 left-3 bg-cyan-500/90 hover:bg-cyan-500 text-white">
          {product.categoryName}
        </Badge>
      </div>

      <CardContent className="p-4">
        <div className="space-y-2">
          <h3 
            id={`product-title-${product.id}`}
            className="font-semibold text-white text-lg line-clamp-2 group-hover:text-cyan-400 transition-colors"
          >
            {product.name}
          </h3>
          <p className="text-slate-400 text-sm line-clamp-2">
            {product.description}
          </p>
          <div className="flex items-center justify-between pt-2">
            <span className="text-2xl font-bold text-white" aria-label={`Preis: ${product.price.toFixed(2)} Euro`}>
              €{product.price.toFixed(2)}
            </span>
            <div className="flex items-center gap-1 text-slate-400 text-sm" aria-label="Bewertung: 4.8 von 5 Sternen">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" aria-hidden="true" />
              <span>4.8</span>
            </div>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{product.variants} Varianten verfügbar</span>
            <span>{product.imageCount} Produktbilder</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Enhanced Quick View Modal Component (Inline)
interface QuickViewModalProps {
  productId: string | null;
  product: {
    id: string;
    name: string;
    description: string;
    thumbnail_url: string;
    price: number;
    images: { url: string; type: string; alt: string; }[];
    variants: any[];
    options: {
      sizes: string[];
      colors: string[];
    };
  } | null;
  isOpen: boolean;
  onClose: () => void;
}

function EnhancedQuickViewModal({ product, isOpen, onClose }: QuickViewModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  useEffect(() => {
    if (product) {
      setSelectedSize(product.options.sizes[0] || '');
      setSelectedColor(product.options.colors[0] || '');
      setSelectedImageIndex(0);
    }
  }, [product]);

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white">{product.name}</DialogTitle>
          <DialogDescription className="text-slate-400">
            Produktdetails für {product.name} - Preis: €{product.price.toFixed(2)}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square overflow-hidden rounded-lg bg-slate-800">
              <ImageWithFallback
                src={product.images[selectedImageIndex]?.url || product.thumbnail_url}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImageIndex === index 
                        ? 'border-cyan-400' 
                        : 'border-slate-600 hover:border-slate-500'
                    }`}
                    aria-label={`Bild ${index + 1} von ${product.name} anzeigen`}
                  >
                    <ImageWithFallback
                      src={image.url}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <p className="text-slate-300 text-lg mb-4">{product.description}</p>
              <div className="text-3xl font-bold text-white">
                €{product.price.toFixed(2)}
              </div>
            </div>

            {/* Size Selection */}
            {product.options.sizes.length > 0 && (
              <div>
                <h4 className="text-white font-semibold mb-3">Größe</h4>
                <div className="flex gap-2 flex-wrap" role="group" aria-label="Größenauswahl">
                  {product.options.sizes.map((size) => (
                    <Button
                      key={size}
                      variant={selectedSize === size ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedSize(size)}
                      aria-pressed={selectedSize === size}
                      className={selectedSize === size 
                        ? "bg-cyan-500 hover:bg-cyan-600 text-white border-cyan-500" 
                        : "border-slate-600 text-slate-300 hover:border-cyan-400 hover:text-white"
                      }
                    >
                      {size}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Selection */}
            {product.options.colors.length > 0 && (
              <div>
                <h4 className="text-white font-semibold mb-3">Farbe</h4>
                <div className="flex gap-2 flex-wrap" role="group" aria-label="Farbauswahl">
                  {product.options.colors.map((color) => (
                    <Button
                      key={color}
                      variant={selectedColor === color ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedColor(color)}
                      aria-pressed={selectedColor === color}
                      className={selectedColor === color 
                        ? "bg-cyan-500 hover:bg-cyan-600 text-white border-cyan-500" 
                        : "border-slate-600 text-slate-300 hover:border-cyan-400 hover:text-white"
                      }
                    >
                      {color}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button 
                className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white"
                onClick={() => {
                  toast.success('Zum Warenkorb hinzugefügt!');
                  onClose();
                }}
                aria-label={`${product.name} zum Warenkorb hinzufügen`}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                In den Warenkorb
              </Button>
              <Button 
                variant="outline"
                className="border-slate-600 text-slate-300 hover:border-cyan-400 hover:text-white"
                onClick={() => {
                  toast.success('Zur Wunschliste hinzugefügt!');
                }}
                aria-label={`${product.name} zur Wunschliste hinzufügen`}
              >
                <Heart className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function ProductGrid({
  selectedCategory: externalSelectedCategory,
  onProductClick,
  category,
  featured = false
}: ProductGridProps) {
  const [products] = useState<Product[]>(NEXUNO_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(NEXUNO_PRODUCTS);
  
  // Enhanced Quick View functionality
  const [quickViewProductId, setQuickViewProductId] = useState<string | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);

  const openQuickView = (productId: string) => {
    const product = products.find(p => p.id === productId);
    console.log('Opening QuickView for product:', productId, product?.name);
    setQuickViewProductId(productId);
    setQuickViewProduct(product || null);
    setIsQuickViewOpen(true);
  };

  const closeQuickView = () => {
    setIsQuickViewOpen(false);
    setQuickViewProductId(null);
    setQuickViewProduct(null);
  };

  // Synchronize external category selection
  useEffect(() => {
    if (externalSelectedCategory) {
      setSelectedCategory(externalSelectedCategory);
    } else if (category) {
      setSelectedCategory(category);
    }
  }, [externalSelectedCategory, category]);

  // Filter products based on selected category
  useEffect(() => {
    if (selectedCategory === 'all') {
      setFilteredProducts(products);
    } else {
      setFilteredProducts(getProductsByCategory(selectedCategory));
    }
  }, [products, selectedCategory]);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
  };

  const handleProductClick = (productId: string) => {
    if (onProductClick) {
      onProductClick(productId);
    } else {
      openQuickView(productId);
    }
  };

  const categories = getCategories();
  const categoryNames = categories.reduce((acc, cat) => {
    acc[cat.id] = cat.name;
    return acc;
  }, {} as Record<string, string>);

  return (
    <div className="w-full">
      {/* Category Navigation */}
      <div className="mb-8">
        <CategoryQuickNav
          categories={['all', ...categories.map(c => c.id)]}
          selectedCategory={selectedCategory}
          onCategoryChange={handleCategorySelect}
          productCounts={{
            all: products.length,
            ...categories.reduce((acc, cat) => {
              acc[cat.id] = cat.count;
              return acc;
            }, {} as Record<string, number>)
          }}
        />
      </div>

      {/* Search */}
      <div className="mb-8">
        <ProductSearch
          products={products}
          onFilteredProducts={setFilteredProducts}
          selectedCategory={selectedCategory}
        />
      </div>

      {/* Product Grid */}
      <section 
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        aria-label="Produktgalerie"
        aria-describedby="product-count"
      >
        <div id="product-count" className="sr-only">
          {filteredProducts.length} {filteredProducts.length === 1 ? 'Produkt' : 'Produkte'} 
          {selectedCategory !== 'all' ? ` in der Kategorie ${categoryNames[selectedCategory]}` : ''}
        </div>
        
        {filteredProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={{
              id: product.id,
              name: product.name,
              price: product.price,
              thumbnail_url: product.image,
              description: product.description,
              category: product.category,
              categoryName: product.categoryName,
              variants: product.sizes.length * product.colors.length,
              images: product.images.map(img => ({ url: img, type: 'image', alt: product.name })),
              imageCount: product.images.length
            }}
            onQuickView={openQuickView}
            onAddToWishlist={(productId) => {
              console.log('Add to wishlist:', productId);
              toast.success('Zur Wunschliste hinzugefügt');
            }}
          />
        ))}
      </section>

      {/* Empty State */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-12" role="status" aria-live="polite">
          <div className="text-slate-400 mb-4 text-6xl" aria-hidden="true">🔍</div>
          <h3 className="text-xl font-semibold text-white mb-2">Keine Produkte gefunden</h3>
          <p className="text-slate-400 mb-4">
            {selectedCategory === 'all' 
              ? 'Es sind derzeit keine Produkte verfügbar.'
              : `Keine Produkte in der Kategorie "${categoryNames[selectedCategory]}" gefunden.`
            }
          </p>
          {selectedCategory !== 'all' && (
            <button
              onClick={() => setSelectedCategory('all')}
              className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-2 rounded-lg transition-colors focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-900"
              aria-label="Alle Kategorien anzeigen und Filter zurücksetzen"
            >
              Alle Kategorien anzeigen
            </button>
          )}
        </div>
      )}

      {/* Enhanced Quick View Modal */}
      <EnhancedQuickViewModal
        productId={quickViewProductId}
        product={quickViewProduct ? {
          id: quickViewProduct.id,
          name: quickViewProduct.name,
          description: quickViewProduct.description,
          thumbnail_url: quickViewProduct.image,
          price: quickViewProduct.price,
          images: quickViewProduct.images.map(url => ({
            url,
            type: 'image',
            alt: quickViewProduct.name
          })),
          variants: [],
          options: {
            sizes: quickViewProduct.sizes,
            colors: quickViewProduct.colors
          }
        } : null}
        isOpen={isQuickViewOpen}
        onClose={closeQuickView}
      />
    </div>
  );
}

export default ProductGrid;