export function FashionDatenschutzPage({ onBack }: { onBack:()=>void }) {
  return (<div style={{padding:24}}><h2>Datenschutz</h2><button onClick={onBack}>Zurück</button></div>);
}