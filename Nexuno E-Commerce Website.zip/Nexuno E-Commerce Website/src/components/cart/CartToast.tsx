import { useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { ShoppingBag, Check } from 'lucide-react';
import { useCart } from './CartContext';

let lastItemCount = 0;

export function CartToast() {
  const { state } = useCart();

  useEffect(() => {
    // Only show toast when items are added (not on initial load or removal)
    if (state.itemCount > lastItemCount) {
      const addedItems = state.itemCount - lastItemCount;
      
      toast.custom((t) => (
        <div
          className="flex items-center gap-3 p-4 rounded-lg shadow-lg"
          style={{
            background: 'var(--surface-dark)',
            border: '1px solid rgba(0, 255, 255, 0.3)',
            color: 'var(--text-white)'
          }}
        >
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, var(--accent-pink) 0%, var(--accent-cyan) 100%)'
            }}
          >
            <Check size={20} className="text-white" />
          </div>
          
          <div className="flex-1">
            <p style={{ 
              fontWeight: '600',
              fontSize: '0.875rem',
              marginBottom: '0.25rem'
            }}>
              {addedItems === 1 ? 'Artikel hinzugefügt!' : `${addedItems} Artikel hinzugefügt!`}
            </p>
            <p style={{ 
              fontSize: '0.75rem',
              color: 'var(--text-muted)'
            }}>
              {state.itemCount} {state.itemCount === 1 ? 'Artikel' : 'Artikel'} im Warenkorb
            </p>
          </div>

          <ShoppingBag size={16} style={{ color: 'var(--accent-cyan)' }} />
        </div>
      ), {
        duration: 3000,
        position: 'top-right'
      });
    }

    lastItemCount = state.itemCount;
  }, [state.itemCount]);

  return null;
}