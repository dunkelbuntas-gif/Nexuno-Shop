import React, { useMemo, useState, useRef, useEffect } from "react";
import { ArrowRight, Menu, X, User, Search } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CartIcon } from './cart/CartIcon';
import type { Page } from '../App';
import referenceImage from 'figma:asset/a5c6e7e8662005139629ba7328feb60041cb02f8.png';
import nexunoLogo from 'figma:asset/84ac582a90684d8cb0342fab1247d589eef95963.png';

const NAV = [
  { page: 'shop' as Page, label: 'Shop' },
  { page: 'tshirts' as Page, label: 'T-Shirts' },
  { page: 'hoodies' as Page, label: 'Hoodies' },
  { page: 'accessories' as Page, label: 'Accessories' },
  { page: 'about' as Page, label: 'Über uns' },
  { page: 'contact' as Page, label: 'Kontakt' },
];

interface HeroSectionProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export function HeroSection({ currentPage, onNavigate }: HeroSectionProps) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [focusIndex, setFocusIndex] = useState(-1);
  const boxRef = useRef<HTMLDivElement>(null);

  const searchData = useMemo(() => [
    ...NAV,
    { page: 'home' as Page, label: 'Startseite' },
  ], []);

  const filtered = useMemo(() => {
    if (!q.trim()) return [];
    return searchData.filter(item => 
      item.label.toLowerCase().includes(q.toLowerCase())
    );
  }, [q, searchData]);

  const handleSuggestionClick = (suggestion: { page: Page; label: string }) => {
    setQ('');
    setFocusIndex(-1);
    onNavigate(suggestion.page);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(event.target as Node)) {
        setQ('');
        setFocusIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <section className="hero-minimal min-h-screen relative overflow-hidden">
      {/* 3D Pastel Geometric Background */}
      <div className="absolute inset-0">
        {/* Base 3D Scene Image */}
        <div 
          className="absolute inset-0 opacity-90"
          style={{
            backgroundImage: `url(${referenceImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        />
        
        {/* Soft Gradient Overlay */}
        <div className="pastel-overlay" />
        
        {/* 3D Floating Spheres */}
        <div className="floating-spheres">
          <div className="sphere sphere-cyan sphere-1"></div>
          <div className="sphere sphere-blue sphere-2"></div>
          <div className="sphere sphere-lavender sphere-3"></div>
          <div className="sphere sphere-white sphere-4"></div>
          <div className="sphere sphere-purple sphere-5"></div>
        </div>
        
        {/* 3D Floating Arches */}
        <div className="floating-arches">
          <div className="arch arch-lavender arch-1"></div>
          <div className="arch arch-blue arch-2"></div>
          <div className="arch arch-white arch-3"></div>
        </div>
        
        {/* 3D Floating Cubes */}
        <div className="floating-cubes">
          <div className="cube cube-blue cube-1"></div>
          <div className="cube cube-purple cube-2"></div>
          <div className="cube cube-cyan cube-3"></div>
          <div className="cube cube-white cube-4"></div>
        </div>
        
        {/* Floating Rectangles */}
        <div className="floating-rectangles">
          <div className="rectangle rectangle-cyan rectangle-1"></div>
          <div className="rectangle rectangle-blue rectangle-2"></div>
        </div>
        
        {/* Soft Ambient Lights */}
        <div className="ambient-lights">
          <div className="ambient-light ambient-light-1"></div>
          <div className="ambient-light ambient-light-2"></div>
          <div className="ambient-light ambient-light-3"></div>
        </div>
        
        {/* Reflective Floor Simulation */}
        <div className="reflective-floor"></div>
      </div>
      
      {/* Content Overlay */}
      <div className="absolute inset-0 z-10 flex flex-col">
        
        {/* Spektakuläres Logo - Separater Container oben links */}
        <div className="absolute top-4 left-4 lg:top-8 lg:left-8 z-[1100]">
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-0 bg-transparent border-0 cursor-pointer group relative p-2 rounded-xl transition-all duration-500 hover:bg-white/5"
          >
            <div className="relative">
              {/* Logo direkt ohne Container */}
              <img
                src={nexunoLogo}
                alt="Nexuno - Fashion der Zukunft"
                className="h-16 lg:h-20 w-auto object-contain transition-all duration-700 group-hover:scale-110 rounded-xl"
                style={{
                  filter: 'brightness(1.05) contrast(1.15) saturate(1.1) drop-shadow(0 8px 25px rgba(30, 58, 138, 0.25)) drop-shadow(0 0 15px rgba(6, 182, 212, 0.2))',
                  mixBlendMode: 'normal'
                }}
              />
              
              {/* Subtile Floating Particles */}
              <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-70 transition-all duration-1000">
                <div className="absolute -top-2 -right-2 w-2 h-2 bg-gradient-to-br from-blue-400 to-blue-300 rounded-full animate-pulse shadow-lg shadow-blue-400/40"></div>
                <div className="absolute -bottom-2 -left-2 w-1.5 h-1.5 bg-gradient-to-br from-cyan-300 to-cyan-200 rounded-full animate-pulse shadow-lg shadow-cyan-300/40" style={{ animationDelay: '0.5s' }}></div>
                <div className="absolute -top-1 left-1/2 w-1 h-1 bg-gradient-to-br from-purple-300 to-purple-200 rounded-full animate-pulse shadow-lg shadow-purple-300/40" style={{ animationDelay: '1s' }}></div>
              </div>
            </div>
          </button>
        </div>

        {/* Glass Navigation - ohne Logo, neue Struktur */}
        <nav className="nav-glass relative z-[1000] max-w-screen-2xl mx-auto w-full flex items-center justify-between px-6 lg:px-8 py-4 gap-6 mt-4">
          
          {/* Platzhalter links für symmetrische Balance */}
          <div className="flex-1 lg:flex-none"></div>

          {/* Navigation Links - Desktop - Zentriert */}
          <div className="hidden lg:flex items-center gap-2 justify-center flex-1">
            {NAV.map((item) => (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className={`nav-link relative bg-transparent border-0 cursor-pointer px-4 py-2 rounded-lg transition-all duration-500 group ${
                  currentPage === item.page 
                    ? 'text-[var(--primary-blue)] bg-white/30' 
                    : 'text-[var(--text-body)] hover:text-[var(--primary-blue)] hover:bg-white/20'
                }`}
                style={{ 
                  fontSize: '14px', 
                  fontWeight: '600',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                }}
              >
                <span className="relative z-10">{item.label}</span>
                
                {/* Active Indicator */}
                {currentPage === item.page && (
                  <span className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-6 h-0.5 bg-[var(--primary-blue)] rounded-full"></span>
                )}
                
                {/* Hover Effect */}
                <span className="absolute inset-0 rounded-lg border border-transparent group-hover:border-white/20 group-hover:bg-white/10 transition-all duration-500"></span>
              </button>
            ))}
          </div>

          {/* Mobile Menu Button für kleine Bildschirme */}
          <button 
            className="lg:hidden relative bg-white/40 border border-white/30 cursor-pointer p-2.5 rounded-lg transition-all duration-500 text-[var(--text-body)] hover:text-[var(--primary-blue)] hover:bg-white/60 hover:border-[var(--primary-blue)] group"
            onClick={() => setOpen(!open)}
          >
            {open ? (
              <X size={16} className="transition-all duration-500 group-hover:scale-110 group-hover:rotate-90" />
            ) : (
              <Menu size={16} className="transition-all duration-500 group-hover:scale-110" />
            )}
          </button>

          {/* Tools - Rechts */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Search */}
            <div className="relative" ref={boxRef}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-muted)] h-4 w-4 z-10" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={(e) => {
                    if (filtered.length === 0) return;
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      setFocusIndex((i) => (i + 1) % filtered.length);
                    } else if (e.key === "ArrowUp") {
                      e.preventDefault();
                      setFocusIndex((i) => (i - 1 + filtered.length) % filtered.length);
                    } else if (e.key === "Enter" && focusIndex >= 0) {
                      handleSuggestionClick(filtered[focusIndex]);
                    }
                  }}
                  placeholder="Suchen..."
                  className="w-64 lg:w-80 h-10 pl-10 pr-4 bg-white/50 backdrop-blur-md border-2 border-white/40 rounded-lg text-[var(--text-body)] placeholder:text-[var(--text-muted)] transition-all duration-500 focus:bg-white/70 focus:border-blue-300/60 focus:outline-none shadow-lg shadow-blue-100/20 hover:border-cyan-200/50 hover:shadow-cyan-100/30 search-field-pastel"
                  style={{ 
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    fontSize: '14px'
                  }}
                />
              </div>
              
              {/* Search Dropdown */}
              {filtered.length > 0 && (
                <div 
                  className="absolute right-0 top-full mt-2 w-80 max-w-[100vw] rounded-xl shadow-2xl overflow-hidden z-[1001] glass-card"
                >
                  <div className="px-4 py-3 border-b border-white/20">
                    <p className="text-sm font-medium text-[var(--text-body)] font-['Inter']">
                      Suchvorschläge
                    </p>
                  </div>
                  {filtered.map((s, i) => (
                    <button
                      key={s.page}
                      onClick={() => handleSuggestionClick(s)}
                      className="w-full text-left px-4 py-3 bg-transparent border-0 cursor-pointer transition-all duration-500 relative group"
                      style={{
                        backgroundColor: i === focusIndex ? 'rgba(30, 58, 138, 0.1)' : 'transparent',
                        color: i === focusIndex ? 'var(--primary-blue)' : 'var(--text-body)',
                        fontSize: '14px',
                        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                        fontWeight: i === focusIndex ? '500' : '400'
                      }}
                      onMouseEnter={() => setFocusIndex(i)}
                    >
                      <span className="relative z-10">{s.label}</span>
                      <div className="absolute inset-0 bg-gradient-to-r from-white/0 to-white/0 group-hover:from-[var(--primary-blue)]/5 group-hover:to-[var(--accent-cyan)]/5 transition-all duration-500"></div>
                      {i === focusIndex && (
                        <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-4 bg-[var(--primary-blue)] rounded-r-full"></div>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <CartIcon />
              </div>

              <button 
                className="relative bg-white/40 border border-white/30 cursor-pointer p-2.5 rounded-lg transition-all duration-500 text-[var(--text-body)] hover:text-[var(--primary-blue)] hover:bg-white/60 hover:border-[var(--primary-blue)] hover:shadow-[0_0_15px_rgba(30,58,138,0.2)] group"
              >
                <User size={16} className="transition-all duration-500 group-hover:scale-110" />
              </button>
            </div>
          </div>
        </nav>

        {/* Mobile Navigation */}
        {open && (
          <div className="lg:hidden px-6 py-4 glass-surface border-b border-white/20 animate-slide-down absolute top-full left-0 right-0 z-[999]">
            <div className="grid grid-cols-1 gap-1">
              {NAV.map((item) => (
                <button
                  key={item.page}
                  onClick={() => {
                    onNavigate(item.page);
                    setOpen(false);
                  }}
                  className={`relative w-full text-left bg-transparent border-0 cursor-pointer px-4 py-3 rounded-lg transition-all duration-500 group ${
                    currentPage === item.page 
                      ? 'text-[var(--primary-blue)] bg-white/30' 
                      : 'text-[var(--text-body)] hover:text-[var(--primary-blue)] hover:bg-white/20'
                  }`}
                  style={{ 
                    fontSize: '14px', 
                    fontWeight: '500',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                  }}
                >
                  <span className="relative z-10">{item.label}</span>
                  {currentPage === item.page && (
                    <div className="absolute inset-0 rounded-lg bg-white/20 border border-white/30"></div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Hero Content - 10% nach rechts verschoben */}
        <div className="flex-1 flex items-center justify-start px-6 lg:px-12 py-20 relative z-20">
          <div className="hero-content-advanced max-w-3xl text-center relative m-[0px] px-[10px] py-[0px] ml-[10%]">
            {/* Animated Halo Effect */}
            <div className="hero-halo"></div>
            
            {/* Main Headline with Advanced Effects */}
            <div className="relative mb-6">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-[var(--text-headline)] leading-tight relative z-10">
                <span className="block mb-3 animate-fade-in-up text-slate-600" style={{ animationDelay: '0.2s' }}>Dein Design.</span>
                <span 
                  className="bg-gradient-to-r from-blue-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent animate-gradient-shift animate-fade-in-up glow-text-pastel"
                  style={{ animationDelay: '0.4s' }}
                >
                  On Demand.
                </span>
              </h1>
              
              {/* Floating Accent Lines */}
              <div className="accent-lines">
                <div className="accent-line accent-line-1"></div>
                <div className="accent-line accent-line-2"></div>
              </div>
            </div>
            
            {/* Enhanced Subline */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-500 mb-10 max-w-2xl mx-auto leading-relaxed animate-fade-in-up relative z-10" style={{ animationDelay: '0.6s' }}>
              Personalisierte Fashion, nachhaltig produziert.<br />
              <span className="text-blue-400 font-medium">Einzigartige Designs</span> für jeden Stil.
            </p>
            
            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up relative z-10" style={{ animationDelay: '0.8s' }}>
              <Button 
                onClick={() => onNavigate('shop')}
                className="btn-primary-enhanced text-base px-8 py-3 group"
              >
                Shop entdecken
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button 
                onClick={() => onNavigate('about')}
                className="btn-secondary-enhanced text-base px-8 py-3 group"
              >
                Über Nexuno
              </Button>
            </div>
            
            {/* Floating Particles around Content */}
            <div className="content-particles">
              <div className="content-particle content-particle-1"></div>
              <div className="content-particle content-particle-2"></div>
              <div className="content-particle content-particle-3"></div>
              <div className="content-particle content-particle-4"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}