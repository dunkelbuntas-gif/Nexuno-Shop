import React from 'react';

interface SafeSkeletonLoaderProps {
  type?: 'card' | 'text' | 'image' | 'button' | 'product';
  width?: string;
  height?: string;
  className?: string;
  count?: number;
  animated?: boolean;
}

export function SafeSkeletonLoader({ 
  type = 'card', 
  width = 'w-full', 
  height = 'h-48',
  className = '',
  count = 1,
  animated = true
}: SafeSkeletonLoaderProps) {

  const getTypeClasses = () => {
    switch (type) {
      case 'text':
        return 'h-4 w-3/4';
      case 'image':
        return 'aspect-square';
      case 'button':
        return 'h-10 w-32';
      case 'product':
        return 'h-80 w-full';
      default:
        return `${width} ${height}`;
    }
  };

  const SkeletonElement = ({ index = 0 }: { index?: number }) => {
    const baseClasses = "bg-slate-200 rounded-lg relative overflow-hidden";
    const animationClasses = animated ? "safe-skeleton-shimmer" : "safe-skeleton-pulse";
    const delayClass = `safe-skeleton-delay-${Math.min(index, 5)}`;
    
    return (
      <div
        className={`${baseClasses} ${getTypeClasses()} ${animationClasses} ${delayClass} ${className}`}
        style={{ animationDelay: `${index * 0.1}s` }}
      >
        {/* Product Skeleton Details */}
        {type === 'product' && (
          <div className="absolute bottom-4 left-4 right-4 space-y-2">
            <div className="h-3 bg-slate-300 rounded w-3/4 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.2}s` }} />
            <div className="h-3 bg-slate-300 rounded w-1/2 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.4}s` }} />
            <div className="h-4 bg-slate-300 rounded w-1/3 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.6}s` }} />
          </div>
        )}
      </div>
    );
  };

  if (count === 1) {
    return <SkeletonElement />;
  }

  return (
    <div className="space-y-4">
      {Array.from({ length: count }, (_, index) => (
        <SkeletonElement key={index} index={index} />
      ))}
    </div>
  );
}

// Specialized Product Grid Skeleton - CSS Only
export function SafeProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }, (_, index) => (
        <div
          key={index}
          className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 animate-fade-in-up"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          {/* Image Skeleton */}
          <div className="aspect-square bg-slate-200 rounded-xl mb-4 relative overflow-hidden safe-skeleton-shimmer">
          </div>
          
          {/* Title Skeleton */}
          <div className="space-y-2">
            <div className="h-4 bg-slate-200 rounded w-3/4 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1}s` }} />
            <div className="h-3 bg-slate-200 rounded w-1/2 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.2}s` }} />
          </div>
          
          {/* Price Skeleton */}
          <div className="h-5 bg-slate-200 rounded w-1/3 mt-3 safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.4}s` }} />
          
          {/* Button Skeleton */}
          <div className="h-10 bg-slate-200 rounded-lg mt-4 w-full safe-skeleton-pulse" style={{ animationDelay: `${index * 0.1 + 0.6}s` }} />
        </div>
      ))}
    </div>
  );
}