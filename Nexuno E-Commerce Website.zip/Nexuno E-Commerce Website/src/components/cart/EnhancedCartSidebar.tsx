import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Plus, Minus, Trash2, Heart, ArrowRight, Star, Shield } from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { toast } from 'sonner@2.0.3';

interface EnhancedCartSidebarProps {
  onCheckout?: () => void;
  onContinueShopping?: () => void;
}

export function EnhancedCartSidebar({ onCheckout, onContinueShopping }: EnhancedCartSidebarProps) {
  const { state, removeItem, updateQuantity, clearCart, closeCart } = useCart();

  const handleRemoveItem = (id: string, size?: string, color?: string, name?: string) => {
    removeItem(id, size, color);
    toast.success(`${name || 'Artikel'} wurde entfernt`);
  };

  const handleUpdateQuantity = (id: string, quantity: number, size?: string, color?: string) => {
    updateQuantity(id, quantity, size, color);
  };

  const handleClearCart = () => {
    clearCart();
    toast.success('Warenkorb geleert');
  };

  const handleCheckout = () => {
    if (state.items.length === 0) {
      toast.error('Ihr Warenkorb ist leer');
      return;
    }
    onCheckout?.();
    toast.success('Weiter zur Kasse...');
  };

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const subtotal = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);
  const shipping = subtotal > 69 ? 0 : 4.99;
  const total = subtotal + shipping;

  return (
    <AnimatePresence>
      {state.isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={closeCart}
          />

          {/* Cart Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white/95 backdrop-blur-xl border-l border-white/20 shadow-2xl z-50 flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-200/50 bg-gradient-to-r from-white/90 to-gray-50/90">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-lg">
                    <ShoppingBag className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">Warenkorb</h2>
                    <p className="text-sm text-gray-600">
                      {state.itemCount} {state.itemCount === 1 ? 'Artikel' : 'Artikel'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={closeCart}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  aria-label="Warenkorb schließen"
                >
                  <X className="w-6 h-6 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {state.items.length === 0 ? (
                /* Empty Cart */
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <ShoppingBag className="w-10 h-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Ihr Warenkorb ist leer
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Entdecken Sie unsere neuesten Fashion-Kollektionen
                  </p>
                  <Button
                    onClick={() => {
                      closeCart();
                      onContinueShopping?.();
                    }}
                    className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white px-6 py-3"
                  >
                    Jetzt shoppen
                  </Button>
                </div>
              ) : (
                <>
                  {/* Cart Items */}
                  <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
                    <AnimatePresence mode="popLayout">
                      {state.items.map((item, index) => (
                        <motion.div
                          key={`${item.id}-${item.size}-${item.color}`}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -100, height: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-gray-200/50 shadow-sm hover:shadow-md transition-all duration-300"
                        >
                          <div className="flex gap-4">
                            {/* Product Image */}
                            <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-100">
                              <img
                                src={item.image}
                                alt={item.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
                            </div>

                            {/* Product Details */}
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-gray-900 truncate mb-1">
                                {item.name}
                              </h4>
                              <div className="flex items-center gap-2 mb-2">
                                {item.size && (
                                  <Badge variant="outline" className="text-xs">
                                    {item.size}
                                  </Badge>
                                )}
                                {item.color && (
                                  <Badge variant="outline" className="text-xs">
                                    {item.color}
                                  </Badge>
                                )}
                              </div>
                              
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => handleUpdateQuantity(item.id, item.quantity - 1, item.size, item.color)}
                                    className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                    disabled={item.quantity <= 1}
                                  >
                                    <Minus className="w-4 h-4" />
                                  </button>
                                  <span className="w-8 text-center font-medium">
                                    {item.quantity}
                                  </span>
                                  <button
                                    onClick={() => handleUpdateQuantity(item.id, item.quantity + 1, item.size, item.color)}
                                    className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                </div>

                                <div className="text-right">
                                  <p className="font-semibold text-gray-900">
                                    {formatPrice(getItemTotal(item.price, item.quantity))}
                                  </p>
                                  {item.quantity > 1 && (
                                    <p className="text-xs text-gray-500">
                                      {formatPrice(item.price)} / Stück
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Remove Button */}
                            <button
                              onClick={() => handleRemoveItem(item.id, item.size, item.color, item.name)}
                              className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              aria-label="Artikel entfernen"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  {/* Summary */}
                  <div className="p-6 border-t border-gray-200/50 bg-gradient-to-b from-white/90 to-gray-50/90">
                    {/* Shipping Info */}
                    <div className="mb-4 p-3 bg-cyan-50 rounded-lg border border-cyan-200">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-cyan-600" />
                        <span className="text-sm text-cyan-800">
                          {shipping === 0 ? (
                            'Kostenloser Versand!'
                          ) : (
                            `Noch €${(69 - subtotal).toFixed(2)} für kostenlosen Versand`
                          )}
                        </span>
                      </div>
                    </div>

                    {/* Price Breakdown */}
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Zwischensumme</span>
                        <span className="text-gray-900">{formatPrice(subtotal)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Versand</span>
                        <span className="text-gray-900">
                          {shipping === 0 ? 'Kostenlos' : formatPrice(shipping)}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex justify-between font-semibold text-lg">
                        <span className="text-gray-900">Gesamt</span>
                        <span className="text-gray-900">{formatPrice(total)}</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="space-y-3">
                      <Button
                        onClick={handleCheckout}
                        className="w-full h-12 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                      >
                        Zur Kasse
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                      
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          onClick={() => {
                            closeCart();
                            onContinueShopping?.();
                          }}
                          className="flex-1 border-gray-300 hover:bg-gray-50"
                        >
                          Weiter shoppen
                        </Button>
                        
                        <Button
                          variant="outline"
                          onClick={handleClearCart}
                          className="px-4 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Trust Indicators */}
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          <span>SSL Verschlüsselt</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3" />
                          <span>14 Tage Rückgabe</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}