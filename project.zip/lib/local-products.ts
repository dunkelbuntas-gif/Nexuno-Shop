/**
 * NEXUNO Fashion Store - Lokale Produktdaten
 * 100% statische Demo-Produkte ohne Backend-Dependencies
 */

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  images: string[];
  category: string;
  categoryName: string;
  sizes: string[];
  colors: string[];
  inStock: boolean;
  featured: boolean;
  tags: string[];
}

export interface Category {
  id: string;
  name: string;
  count: number;
}

// Demo-Produktdaten für Nexuno Fashion Store
export const NEXUNO_PRODUCTS: Product[] = [
  // T-Shirts
  {
    id: 'future-tech-tee-black',
    name: 'Future Tech T-Shirt',
    description: 'Minimalistisches T-Shirt mit futuristischem Design. Perfekt für den modernen Look.',
    price: 39.99,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1582767652261-c90f54e3a3bb?w=500&h=500&fit=crop'
    ],
    category: 'tshirts',
    categoryName: 'T-Shirts',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Schwarz', 'Weiß', 'Grau'],
    inStock: true,
    featured: true,
    tags: ['casual', 'tech', 'minimalist']
  },
  {
    id: 'neon-glow-tee',
    name: 'Neon Glow T-Shirt',
    description: 'T-Shirt mit leuchtenden Neon-Akzenten. Perfekt für Events und Partys.',
    price: 44.99,
    image: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=500&fit=crop'
    ],
    category: 'tshirts',
    categoryName: 'T-Shirts',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Neon Grün', 'Neon Pink', 'Cyber Blau'],
    inStock: true,
    featured: false,
    tags: ['neon', 'party', 'futuristic']
  },
  {
    id: 'circuit-pattern-tee',
    name: 'Circuit Pattern T-Shirt',
    description: 'T-Shirt mit digitalem Schaltkreis-Muster. Für alle Tech-Enthusiasten.',
    price: 42.99,
    image: 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1562181324-fce4ff56b19b?w=500&h=500&fit=crop'
    ],
    category: 'tshirts',
    categoryName: 'T-Shirts',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Schwarz', 'Dunkelblau', 'Grau'],
    inStock: true,
    featured: true,
    tags: ['tech', 'pattern', 'digital']
  },

  // Hoodies
  {
    id: 'cyber-hoodie-black',
    name: 'Cyber Future Hoodie',
    description: 'Premium Hoodie mit futuristischem Cyber-Design. Warm und stylisch.',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1582767652261-c90f54e3a3bb?w=500&h=500&fit=crop'
    ],
    category: 'hoodies',
    categoryName: 'Hoodies',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Schwarz', 'Dunkelgrau', 'Navy'],
    inStock: true,
    featured: true,
    tags: ['hoodie', 'cyber', 'premium']
  },
  {
    id: 'neon-tech-hoodie',
    name: 'Neon Tech Hoodie',
    description: 'Hoodie mit leuchtenden Tech-Details und reflektierenden Elementen.',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop'
    ],
    category: 'hoodies',
    categoryName: 'Hoodies',
    sizes: ['M', 'L', 'XL'],
    colors: ['Schwarz/Neon', 'Grau/Cyan', 'Navy/Pink'],
    inStock: true,
    featured: false,
    tags: ['hoodie', 'neon', 'reflective']
  },
  {
    id: 'minimal-future-hoodie',
    name: 'Minimal Future Hoodie',
    description: 'Minimalistischer Hoodie mit subtilen futuristischen Details.',
    price: 74.99,
    image: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=500&h=500&fit=crop'
    ],
    category: 'hoodies',
    categoryName: 'Hoodies',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Weiß', 'Hellgrau', 'Beige'],
    inStock: true,
    featured: true,
    tags: ['minimal', 'clean', 'subtle']
  },

  // Accessoires
  {
    id: 'tech-cap-black',
    name: 'Tech Cap',
    description: 'Futuristische Cap mit LED-Details und Tech-Emblem.',
    price: 34.99,
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=500&h=500&fit=crop'
    ],
    category: 'accessories',
    categoryName: 'Accessoires',
    sizes: ['One Size'],
    colors: ['Schwarz', 'Weiß', 'Grau'],
    inStock: true,
    featured: false,
    tags: ['cap', 'tech', 'led']
  },
  {
    id: 'cyber-backpack',
    name: 'Cyber Backpack',
    description: 'Futuristischer Rucksack mit LED-Panels und smarten Fächern.',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1622560480654-d96214fdc887?w=500&h=500&fit=crop'
    ],
    category: 'accessories',
    categoryName: 'Accessoires',
    sizes: ['One Size'],
    colors: ['Schwarz', 'Grau', 'Navy'],
    inStock: true,
    featured: true,
    tags: ['backpack', 'smart', 'led']
  },
  {
    id: 'neon-wristband',
    name: 'Neon Wristband',
    description: 'Leuchtende Armbänder mit programmierbaren LED-Effekten.',
    price: 24.99,
    image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500&h=500&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=500&h=500&fit=crop'
    ],
    category: 'accessories',
    categoryName: 'Accessoires',
    sizes: ['S/M', 'L/XL'],
    colors: ['Neon Grün', 'Cyber Blau', 'Hot Pink'],
    inStock: true,
    featured: false,
    tags: ['wristband', 'led', 'programmable']
  }
];

// Kategorie-Definitionen
export const CATEGORIES: Category[] = [
  { id: 'tshirts', name: 'T-Shirts', count: 3 },
  { id: 'hoodies', name: 'Hoodies', count: 3 },
  { id: 'accessories', name: 'Accessoires', count: 3 }
];

// Utility Functions
export function getProductsByCategory(categoryId: string): Product[] {
  if (categoryId === 'all') {
    return NEXUNO_PRODUCTS;
  }
  return NEXUNO_PRODUCTS.filter(product => product.category === categoryId);
}

export function getCategories(): Category[] {
  return CATEGORIES;
}

export function searchProducts(query: string): Product[] {
  if (!query.trim()) {
    return NEXUNO_PRODUCTS;
  }
  
  const lowercaseQuery = query.toLowerCase();
  return NEXUNO_PRODUCTS.filter(product =>
    product.name.toLowerCase().includes(lowercaseQuery) ||
    product.description.toLowerCase().includes(lowercaseQuery) ||
    product.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery)) ||
    product.categoryName.toLowerCase().includes(lowercaseQuery)
  );
}

export function getFeaturedProducts(): Product[] {
  return NEXUNO_PRODUCTS.filter(product => product.featured);
}

export function getProductById(id: string): Product | undefined {
  return NEXUNO_PRODUCTS.find(product => product.id === id);
}

// Utility: Get products by multiple categories
export function getProductsByCategories(categoryIds: string[]): Product[] {
  if (categoryIds.includes('all')) {
    return NEXUNO_PRODUCTS;
  }
  return NEXUNO_PRODUCTS.filter(product => categoryIds.includes(product.category));
}

// Price filtering
export function getProductsByPriceRange(min: number, max: number): Product[] {
  return NEXUNO_PRODUCTS.filter(product => product.price >= min && product.price <= max);
}

// Sort products
export function sortProducts(products: Product[], sortBy: 'price-asc' | 'price-desc' | 'name' | 'featured'): Product[] {
  const sortedProducts = [...products];
  
  switch (sortBy) {
    case 'price-asc':
      return sortedProducts.sort((a, b) => a.price - b.price);
    case 'price-desc':
      return sortedProducts.sort((a, b) => b.price - a.price);
    case 'name':
      return sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
    case 'featured':
      return sortedProducts.sort((a, b) => {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return 0;
      });
    default:
      return sortedProducts;
  }
}

// Get all available sizes
export function getAllSizes(): string[] {
  const allSizes = new Set<string>();
  NEXUNO_PRODUCTS.forEach(product => {
    product.sizes.forEach(size => allSizes.add(size));
  });
  return Array.from(allSizes).sort();
}

// Get all available colors
export function getAllColors(): string[] {
  const allColors = new Set<string>();
  NEXUNO_PRODUCTS.forEach(product => {
    product.colors.forEach(color => allColors.add(color));
  });
  return Array.from(allColors).sort();
}

// Filter products by size
export function getProductsBySize(size: string): Product[] {
  return NEXUNO_PRODUCTS.filter(product => product.sizes.includes(size));
}

// Filter products by color
export function getProductsByColor(color: string): Product[] {
  return NEXUNO_PRODUCTS.filter(product => product.colors.includes(color));
}

// Advanced search with filters
export interface SearchFilters {
  query?: string;
  categories?: string[];
  priceMin?: number;
  priceMax?: number;
  sizes?: string[];
  colors?: string[];
  inStock?: boolean;
  featured?: boolean;
}

export function searchProductsAdvanced(filters: SearchFilters): Product[] {
  let results = NEXUNO_PRODUCTS;

  // Text search
  if (filters.query) {
    results = searchProducts(filters.query);
  }

  // Category filter
  if (filters.categories && filters.categories.length > 0 && !filters.categories.includes('all')) {
    results = results.filter(product => filters.categories!.includes(product.category));
  }

  // Price range filter
  if (filters.priceMin !== undefined) {
    results = results.filter(product => product.price >= filters.priceMin!);
  }
  if (filters.priceMax !== undefined) {
    results = results.filter(product => product.price <= filters.priceMax!);
  }

  // Size filter
  if (filters.sizes && filters.sizes.length > 0) {
    results = results.filter(product => 
      filters.sizes!.some(size => product.sizes.includes(size))
    );
  }

  // Color filter
  if (filters.colors && filters.colors.length > 0) {
    results = results.filter(product => 
      filters.colors!.some(color => product.colors.includes(color))
    );
  }

  // Stock filter
  if (filters.inStock === true) {
    results = results.filter(product => product.inStock);
  }

  // Featured filter
  if (filters.featured === true) {
    results = results.filter(product => product.featured);
  }

  return results;
}

export default {
  NEXUNO_PRODUCTS,
  CATEGORIES,
  getProductsByCategory,
  getCategories,
  searchProducts,
  getFeaturedProducts,
  getProductById,
  getProductsByCategories,
  getProductsByPriceRange,
  sortProducts,
  getAllSizes,
  getAllColors,
  getProductsBySize,
  getProductsByColor,
  searchProductsAdvanced
};