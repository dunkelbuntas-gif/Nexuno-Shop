import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'green' | 'blue' | 'cyan' | 'white';
  className?: string;
}

export function MotionSpinner({ 
  size = 'md', 
  color = 'green', 
  className = '' 
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  const colorClasses = {
    green: 'border-store-green border-t-transparent',
    blue: 'border-blue-500 border-t-transparent',
    cyan: 'border-cyan-500 border-t-transparent',
    white: 'border-white border-t-transparent'
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} border-2 rounded-full ${colorClasses[color]} ${className}`}
      animate={{ rotate: 360 }}
      transition={{
        duration: 1,
        repeat: Infinity,
        ease: "linear"
      }}
    />
  );
}

interface MotionDotsProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'green' | 'blue' | 'cyan' | 'white';
  className?: string;
}

export function MotionDots({ 
  size = 'md', 
  color = 'green', 
  className = '' 
}: MotionDotsProps) {
  const dotSizes = {
    sm: 'w-2 h-2',
    md: 'w-3 h-3',
    lg: 'w-4 h-4'
  };

  const colorClasses = {
    green: 'bg-store-green',
    blue: 'bg-blue-500',
    cyan: 'bg-cyan-500',
    white: 'bg-white'
  };

  const containerVariants = {
    animate: {
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const dotVariants = {
    animate: {
      y: [0, -10, 0],
      transition: {
        duration: 0.6,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <motion.div
      className={`flex space-x-1 ${className}`}
      variants={containerVariants}
      animate="animate"
    >
      {[0, 1, 2].map((index) => (
        <motion.div
          key={index}
          className={`${dotSizes[size]} ${colorClasses[color]} rounded-full`}
          variants={dotVariants}
        />
      ))}
    </motion.div>
  );
}

interface MotionProgressProps {
  progress: number;
  className?: string;
  color?: 'green' | 'blue' | 'cyan';
  showPercentage?: boolean;
}

export function MotionProgress({ 
  progress, 
  className = '', 
  color = 'green',
  showPercentage = false
}: MotionProgressProps) {
  const colorClasses = {
    green: 'bg-store-green',
    blue: 'bg-blue-500',
    cyan: 'bg-cyan-500'
  };

  return (
    <div className={`relative ${className}`}>
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <motion.div
          className={`h-full ${colorClasses[color]} rounded-full`}
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
          transition={{
            duration: 0.5,
            ease: [0.25, 0.25, 0, 1]
          }}
        />
      </div>
      
      {showPercentage && (
        <motion.div
          className="absolute -top-6 right-0 text-sm font-medium text-gray-600"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {Math.round(progress)}%
        </motion.div>
      )}
    </div>
  );
}

interface SkeletonItemProps {
  width?: string;
  height?: string;
  className?: string;
  variant?: 'rectangular' | 'circular' | 'text';
}

export function MotionSkeleton({ 
  width = 'w-full', 
  height = 'h-4', 
  className = '',
  variant = 'rectangular'
}: SkeletonItemProps) {
  const variantClasses = {
    rectangular: 'rounded',
    circular: 'rounded-full',
    text: 'rounded'
  };

  return (
    <motion.div
      className={`${width} ${height} ${variantClasses[variant]} bg-gray-200 ${className}`}
      animate={{
        opacity: [0.4, 0.8, 0.4]
      }}
      transition={{
        duration: 1.5,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    />
  );
}

interface SkeletonGridProps {
  rows?: number;
  className?: string;
}

export function MotionSkeletonGrid({ rows = 3, className = '' }: SkeletonGridProps) {
  const containerVariants = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    animate: {
      opacity: [0.4, 0.8, 0.4],
      transition: {
        duration: 1.5,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <motion.div
      className={`space-y-4 ${className}`}
      variants={containerVariants}
      animate="animate"
    >
      {Array.from({ length: rows }).map((_, index) => (
        <motion.div
          key={index}
          className="space-y-2"
          variants={itemVariants}
        >
          <div className="h-4 bg-gray-200 rounded w-3/4" />
          <div className="h-4 bg-gray-200 rounded w-full" />
          <div className="h-4 bg-gray-200 rounded w-5/6" />
        </motion.div>
      ))}
    </motion.div>
  );
}

interface LoadingOverlayProps {
  isVisible: boolean;
  message?: string;
  className?: string;
}

export function MotionLoadingOverlay({ 
  isVisible, 
  message = 'Laden...', 
  className = '' 
}: LoadingOverlayProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center ${className}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="bg-white rounded-xl p-8 flex flex-col items-center space-y-4"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ 
              duration: 0.3,
              type: "spring",
              stiffness: 300
            }}
          >
            <MotionSpinner size="lg" />
            <p className="text-lg font-medium text-gray-700">{message}</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface TypewriterTextProps {
  text: string;
  speed?: number;
  className?: string;
  onComplete?: () => void;
}

export function MotionTypewriter({ 
  text, 
  speed = 50, 
  className = '',
  onComplete
}: TypewriterTextProps) {
  const [displayText, setDisplayText] = React.useState('');
  const [currentIndex, setCurrentIndex] = React.useState(0);

  React.useEffect(() => {
    if (currentIndex < text.length) {
      const timer = setTimeout(() => {
        setDisplayText(prev => prev + text[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, speed);

      return () => clearTimeout(timer);
    } else if (onComplete) {
      onComplete();
    }
  }, [currentIndex, text, speed, onComplete]);

  return (
    <motion.span
      className={className}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {displayText}
      <motion.span
        className="inline-block w-0.5 h-5 bg-current ml-1"
        animate={{ opacity: [1, 0] }}
        transition={{
          duration: 0.8,
          repeat: Infinity,
          repeatType: "reverse"
        }}
      />
    </motion.span>
  );
}

interface SuccessCheckmarkProps {
  isVisible: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function MotionSuccessCheckmark({ 
  isVisible, 
  size = 'md', 
  className = '' 
}: SuccessCheckmarkProps) {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  const pathVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: { 
      pathLength: 1, 
      opacity: 1,
      transition: {
        pathLength: { duration: 0.6, ease: "easeInOut" },
        opacity: { duration: 0.2 }
      }
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className={`${sizeClasses[size]} ${className}`}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          exit={{ scale: 0 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20
          }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            className="w-full h-full text-green-500"
          >
            <motion.circle
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="2"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.4 }}
            />
            <motion.path
              d="M8 12l2 2 4-4"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              variants={pathVariants}
              initial="hidden"
              animate="visible"
            />
          </svg>
        </motion.div>
      )}
    </AnimatePresence>
  );
}