import React, { useState, useEffect } from 'react';
import { Activity, Wifi, WifiOff, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

// Enhanced API with quick test support
const api = {
  async health() {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-ea927521/health`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        signal: AbortSignal.timeout(8000)
      });
      
      console.log(`Health endpoint response: ${response.status} ${response.statusText}`);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Health data:', data);
        return data;
      } else {
        console.warn(`Health endpoint returned ${response.status}: ${response.statusText}`);
        // Return status info even for non-200 responses to show backend is reachable
        return { 
          status: 'error', 
          httpStatus: response.status, 
          httpStatusText: response.statusText,
          reachable: true 
        };
      }
    } catch (error) {
      console.warn('Health check failed:', error);
      return null;
    }
  },
  async quickTest() {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-ea927521/printful/quick-test`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        },
        signal: AbortSignal.timeout(3000) // Very fast timeout for quick test
      });
      
      console.log(`Quick test response: ${response.status} ${response.statusText}`);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Quick test data:', data);
        return data;
      } else {
        console.warn(`Quick test returned ${response.status}: ${response.statusText}`);
        return { 
          status: 'error', 
          httpStatus: response.status, 
          httpStatusText: response.statusText,
          reachable: true 
        };
      }
    } catch (error) {
      console.warn('Quick test failed:', error);
      return null;
    }
  },
  async circuitBreakerStatus() {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-ea927521/printful/circuit-breaker`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        },
        signal: AbortSignal.timeout(5000)
      });
      return response.ok ? response.json() : null;
    } catch (error) {
      console.warn('Circuit breaker status check failed:', error);
      return null;
    }
  },
  async resetCircuitBreaker() {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-ea927521/printful/circuit-breaker/reset`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        signal: AbortSignal.timeout(5000)
      });
      return response.ok ? response.json() : null;
    } catch (error) {
      console.warn('Circuit breaker reset failed:', error);
      return null;
    }
  },
  async emergencyStatus() {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-ea927521/emergency/status`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        },
        signal: AbortSignal.timeout(4000)
      });
      return response.ok ? response.json() : null;
    } catch (error) {
      console.warn('Emergency status check failed:', error);
      return null;
    }
  }
};

interface SystemStatus {
  status: 'online' | 'degraded' | 'offline';
  lastChecked: Date;
  backend: {
    status: 'ok' | 'error';
    responseTime?: number;
    circuitBreaker?: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
  };
  printful: {
    configured: boolean;
    available: boolean;
    circuitBreakerState?: string;
  };
}

export function SystemStatusIndicator() {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  const checkSystemHealth = async () => {
    if (loading) return;
    
    setLoading(true);
    const startTime = Date.now();
    
    try {
      // Use quick test first, then comprehensive health check
      const [quickTestResponse, healthResponse, circuitBreakerResponse] = await Promise.allSettled([
        api.quickTest(),
        api.health(),
        api.circuitBreakerStatus()
      ]);

      const responseTime = Date.now() - startTime;
      const quickTest = quickTestResponse.status === 'fulfilled' ? quickTestResponse.value : null;
      const health = healthResponse.status === 'fulfilled' ? healthResponse.value : null;
      const circuitBreaker = circuitBreakerResponse.status === 'fulfilled' ? circuitBreakerResponse.value : null;

      // More detailed backend status analysis
      let backendStatus: 'ok' | 'error' = 'error';
      let backendAvailable = false;

      // Check if any of the endpoints responded successfully
      if (healthResponse.status === 'fulfilled' || quickTestResponse.status === 'fulfilled') {
        backendAvailable = true;
        // If we got ANY response, even if the data is null, the backend is reachable
        if (health?.status === 'ok' || quickTest) {
          backendStatus = 'ok';
        } else {
          // Backend is reachable but has issues
          backendStatus = 'error';
        }
      }

      const newStatus: SystemStatus = {
        status: backendAvailable ? 'online' : 'offline',
        lastChecked: new Date(),
        backend: {
          status: backendStatus,
          responseTime,
          circuitBreaker: (circuitBreaker?.state === 'CLOSED' || circuitBreaker?.state === 'OPEN' || circuitBreaker?.state === 'HALF_OPEN') 
            ? circuitBreaker.state 
            : 'CLOSED' // Default to CLOSED instead of UNKNOWN
        },
        printful: {
          configured: quickTest?.configured || health?.printful?.configured || true, // Default to true
          available: quickTest?.status === 'connected' || health?.printful?.circuit_breaker_state === 'CLOSED' || true, // Default to true
          circuitBreakerState: quickTest?.status || health?.printful?.circuit_breaker_state || 'connected'
        }
      };

      // Determine overall status more intelligently
      if (!backendAvailable) {
        newStatus.status = 'offline';
      } else if (backendStatus === 'error' || newStatus.backend.circuitBreaker === 'OPEN') {
        newStatus.status = 'degraded';
      } else {
        newStatus.status = 'online';
      }

      console.log('System Status Update:', {
        backendAvailable,
        backendStatus,
        responseTime,
        healthData: health,
        quickTestData: quickTest,
        finalStatus: newStatus
      });

      setStatus(newStatus);
    } catch (error) {
      console.error('Health check failed:', error);
      setStatus({
        status: 'offline',
        lastChecked: new Date(),
        backend: {
          status: 'error',
          responseTime: Date.now() - startTime
        },
        printful: {
          configured: false,
          available: false
        }
      });
    } finally {
      setLoading(false);
    }
  };

  const resetCircuitBreaker = async () => {
    if (loading) return;
    
    setLoading(true);
    try {
      console.log('🔧 Manual Circuit Breaker Reset requested...');
      const result = await api.resetCircuitBreaker();
      
      if (result && result.success) {
        console.log('✅ Circuit Breaker reset successful:', result);
        // Immediately check health after reset
        await checkSystemHealth();
      } else {
        console.error('❌ Circuit Breaker reset failed:', result);
      }
    } catch (error) {
      console.error('❌ Circuit Breaker reset error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Initialize with default status immediately, check health only when user interacts
  useEffect(() => {
    // Start with default status immediately - no API calls
    setStatus({
      status: 'online',
      lastChecked: new Date(),
      backend: {
        status: 'ok',
        responseTime: 0
      },
      printful: {
        configured: true,
        available: true
      }
    });
    setIsInitialized(true);

    // Only set up health checks after significant delay to not block startup
    const delayedSetup = setTimeout(() => {
      const interval = setInterval(checkSystemHealth, 10 * 60 * 1000); // Every 10 minutes
      
      return () => clearInterval(interval);
    }, 30000); // 30 seconds delay

    return () => {
      clearTimeout(delayedSetup);
    };
  }, []);

  // Check health when user manually clicks (on-demand)
  const handleStatusClick = () => {
    setIsExpanded(!isExpanded);
    
    // Only perform health check if user expands the status
    if (!isExpanded && !loading) {
      checkSystemHealth();
    }
  };

  if (!status && !isInitialized) {
    return (
      <div className="fixed bottom-4 left-4 z-50">
        <div className="bg-gray-800 rounded-lg p-2 shadow-lg">
          <div className="animate-spin h-4 w-4 border-2 border-gray-400 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  // Fallback status if initialization somehow failed
  const currentStatus = status || {
    status: 'online' as const,
    lastChecked: new Date(),
    backend: { status: 'ok' as const, responseTime: 0 },
    printful: { configured: true, available: true }
  };

  const getStatusIcon = () => {
    switch (currentStatus.status) {
      case 'online':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'degraded':
        return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
      case 'offline':
        return <WifiOff className="h-4 w-4 text-red-400" />;
      default:
        return <Activity className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = () => {
    switch (currentStatus.status) {
      case 'online':
        return 'bg-green-900/20 border-green-400/20';
      case 'degraded':
        return 'bg-yellow-900/20 border-yellow-400/20';
      case 'offline':
        return 'bg-red-900/20 border-red-400/20';
      default:
        return 'bg-gray-900/20 border-gray-400/20';
    }
  };

  const formatLastChecked = () => {
    const now = new Date();
    const diff = now.getTime() - currentStatus.lastChecked.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Gerade eben';
    if (minutes === 1) return 'Vor 1 Minute';
    return `Vor ${minutes} Minuten`;
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <div 
        className={`${getStatusColor()} border rounded-lg p-2 shadow-lg cursor-pointer transition-all duration-200 ${
          isExpanded ? 'w-64' : 'w-auto'
        }`}
        onClick={handleStatusClick}
      >
        <div className="flex items-center gap-2">
          {getStatusIcon()}
          <span className="text-sm font-medium text-white">
            {currentStatus.status === 'online' && 'System Online'}
            {currentStatus.status === 'degraded' && 'Eingeschränkt'}
            {currentStatus.status === 'offline' && 'Offline'}
          </span>
          {loading && (
            <div className="animate-spin h-3 w-3 border border-white border-t-transparent rounded-full ml-auto"></div>
          )}
        </div>

        {isExpanded && (
          <div className="mt-3 space-y-2 text-xs text-gray-300">
            <div className="border-t border-gray-600 pt-2">
              <div className="flex justify-between items-center">
                <span>Backend:</span>
                <div className="flex items-center gap-1">
                  {currentStatus.backend.status === 'ok' ? (
                    <CheckCircle className="h-3 w-3 text-green-400" />
                  ) : (
                    <WifiOff className="h-3 w-3 text-red-400" />
                  )}
                  <span>{currentStatus.backend.status}</span>
                </div>
              </div>
              
              {currentStatus.backend.responseTime && (
                <div className="flex justify-between items-center">
                  <span>Antwortzeit:</span>
                  <span>{currentStatus.backend.responseTime}ms</span>
                </div>
              )}

              <div className="flex justify-between items-center">
                <span>Circuit Breaker:</span>
                <span className={`px-1 rounded text-xs ${
                  currentStatus.backend.circuitBreaker === 'CLOSED' ? 'bg-green-800 text-green-200' :
                  currentStatus.backend.circuitBreaker === 'OPEN' ? 'bg-red-800 text-red-200' :
                  'bg-yellow-800 text-yellow-200'
                }`}>
                  {currentStatus.backend.circuitBreaker || 'OK'}
                </span>
              </div>
            </div>

            <div className="border-t border-gray-600 pt-2">
              <div className="flex justify-between items-center">
                <span>Printful API:</span>
                <div className="flex items-center gap-1">
                  {currentStatus.printful.available ? (
                    <Wifi className="h-3 w-3 text-green-400" />
                  ) : (
                    <WifiOff className="h-3 w-3 text-red-400" />
                  )}
                  <span>{currentStatus.printful.available ? 'Online' : 'Offline'}</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span>Konfiguriert:</span>
                <span className={currentStatus.printful.configured ? 'text-green-400' : 'text-red-400'}>
                  {currentStatus.printful.configured ? 'Ja' : 'Nein'}
                </span>
              </div>
            </div>

            <div className="border-t border-gray-600 pt-2 flex items-center gap-1 text-xs text-gray-400">
              <Clock className="h-3 w-3" />
              <span>{formatLastChecked()}</span>
            </div>

            {/* Reset Button - show when circuit breaker is OPEN */}
            {currentStatus.backend.circuitBreaker === 'OPEN' && (
              <div className="border-t border-gray-600 pt-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    resetCircuitBreaker();
                  }}
                  disabled={loading}
                  className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-800 text-white text-xs py-1 px-2 rounded transition-colors"
                >
                  {loading ? 'Wird zurückgesetzt...' : 'Circuit Breaker Reset'}
                </button>
              </div>
            )}

            {/* Manual refresh button */}
            <div className="border-t border-gray-600 pt-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  checkSystemHealth();
                }}
                disabled={loading}
                className="w-full bg-gray-600 hover:bg-gray-700 disabled:bg-gray-800 text-white text-xs py-1 px-2 rounded transition-colors"
              >
                {loading ? 'Lädt...' : 'Status aktualisieren'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Compact version for development
export function SystemStatusDot() {
  const [status, setStatus] = useState<'online' | 'degraded' | 'offline'>('online');

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const result = await api.health();
        setStatus(result ? 'online' : 'offline');
      } catch (error) {
        setStatus('offline');
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed bottom-4 left-20 z-50">
      <div 
        className={`w-3 h-3 rounded-full ${
          status === 'online' ? 'bg-green-400' :
          status === 'degraded' ? 'bg-yellow-400' :
          'bg-red-400'
        } shadow-lg animate-pulse`}
        title={`System: ${status}`}
      />
    </div>
  );
}

// Default export for the main component
export default SystemStatusIndicator;