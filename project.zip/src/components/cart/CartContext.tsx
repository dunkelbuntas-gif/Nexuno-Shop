import { createContext, useContext, useState, ReactNode } from 'react';
type CartItem = { id: string; qty: number };
type Ctx = { items: CartItem[]; add:(id:string)=>void; remove:(id:string)=>void; clear:()=>void; };
const C = createContext<Ctx | null>(null);
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, set] = useState<CartItem[]>([]);
  return (
    <C.Provider value={{
      items,
      add: id => set(prev => [...prev, { id, qty: 1 }]),
      remove: id => set(prev => prev.filter(i => i.id !== id)),
      clear: () => set([])
    }}>
      {children}
    </C.Provider>
  );
}
export const useCart = () => {
  const v = useContext(C);
  if (!v) throw new Error('CartContext missing');
  return v;
};