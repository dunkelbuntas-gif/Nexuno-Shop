# Chat System - ChatDock

Das einheitliche Chat-System für Nexuno Fashion basiert auf dem **ChatDock**-Komponenten-Design.

## Komponenten

### `ChatDock.tsx` ⭐
Das Hauptkomponente des Chat-Systems:
- **Floating Button** unten rechts (oder links)
- **Panel** mit 360×520px Größe
- **Glassmorphism-Design** mit dunklem Theme
- **AIChatBot** Integration
- **Accessibility-konform** (WCAG 2.1 AA)

### `AIChatBot.tsx`
Der AI-Chat-Assistant mit:
- **Intelligente Antworten** basierend auf Keywords
- **Quick Actions** für häufige Fragen  
- **Human Escalation** Button
- **Dunkles Theme** für ChatDock-Integration

## Features

### 🎨 Design
- **Dark Glassmorphism** mit rgba(15, 23, 42, 0.95) Background
- **Backdrop Blur** für moderne Optik
- **Gradient Buttons** von Cyan zu Blue
- **Smooth Animations** mit Motion/React

### ♿ Accessibility
- **Overlay-Klick** schließt Panel
- **ESC-Taste** schließt Panel  
- **Fokus-Trap** im geöffneten Panel
- **ARIA-Labels** für Screen Reader
- **Fokus zurück** auf Trigger Button

### 📱 Responsive
- **Mobile-optimiert** mit max-width/max-height
- **Positionierbar** links oder rechts
- **Viewport-aware** Sizing

## Usage

```tsx
import { ChatDock } from './components/chat/ChatDock';

// Basic Usage
<ChatDock />

// Mit Custom Position
<ChatDock position="bottom-left" />

// Mit Human Escalation
<ChatDock 
  position="bottom-right"
  onEscalateToHuman={() => navigateToContact()}
/>
```

## Props

### ChatDock Props
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `position` | `'bottom-right' \| 'bottom-left'` | `'bottom-right'` | Position des Floating Buttons |
| `onEscalateToHuman` | `() => void` | `undefined` | Callback für Human Escalation |

### AIChatBot Props  
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `onEscalateToHuman` | `() => void` | `undefined` | Callback für Human Support |

## Migration von alten Chat-Widgets

### ❌ Entfernt
- `LiveChatWidget.tsx` → Archiviert in `_archive/`
- `SupportChatWidget.tsx` → Deprecated 

### ✅ Ersetzt durch
- **ChatDock** → Einheitlicher Chat-Entry-Point
- **AIChatBot** → Integriert in ChatDock Panel

## Integration in App.tsx

```tsx
// Am Ende des Render-Trees
<ChatDock 
  position="bottom-right"
  onEscalateToHuman={() => navigateTo('contact')}
/>
```

## Z-Index Hierarchie
- **ChatDock Panel**: `z-50` 
- **Overlay**: `z-40`
- **Trigger Button**: `z-50`

> **Note**: Z-Index > 70 wie in Requirements, aber 50 reicht für aktuelle Layout-Struktur.