import { useCart } from './CartContext';
import { motion } from 'motion/react';
import { useState } from 'react';

// Custom SVG Cart Icon - Ultra-futuristisches Design
export function CartIconCustom() {
  const { state, toggleCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.button
      onClick={toggleCart}
      className="relative group"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Glassmorphism Container */}
      <motion.div
        className="relative p-3 rounded-2xl backdrop-blur-20 transition-all duration-500"
        style={{
          background: isHovered 
            ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.3) 0%, rgba(96, 165, 250, 0.2) 100%)'
            : 'linear-gradient(135deg, rgba(255, 255, 255, 0.2) 0%, rgba(248, 250, 252, 0.15) 100%)',
          border: `1px solid ${isHovered ? 'rgba(96, 165, 250, 0.5)' : 'rgba(255, 255, 255, 0.3)'}`,
          boxShadow: isHovered 
            ? '0 12px 40px rgba(96, 165, 250, 0.25), 0 0 30px rgba(34, 211, 238, 0.15), inset 0 2px 4px rgba(255, 255, 255, 0.9)'
            : '0 6px 20px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.8)'
        }}
        animate={{
          rotateY: isHovered ? 15 : 0,
          rotateX: isHovered ? -8 : 0,
        }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        {/* Custom SVG Cart Icon */}
        <motion.div
          className="relative z-10"
          animate={{
            rotateY: isHovered ? -15 : 0,
            scale: isHovered ? 1.15 : 1
          }}
          transition={{ duration: 0.4 }}
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="transition-all duration-500"
            style={{
              filter: isHovered 
                ? 'drop-shadow(0 0 12px rgba(96, 165, 250, 0.8)) drop-shadow(0 0 24px rgba(34, 211, 238, 0.5))'
                : 'none'
            }}
          >
            {/* Futuristische Cart-Base */}
            <motion.path
              d="M3 3H5L5.4 5M7 13H17L21 5H5.4M7 13L5.4 5M7 13L4.7 15.3C4.3 15.7 4.6 16.5 5.1 16.5H17M17 13V16.5"
              stroke={isHovered ? '#1E3A8A' : '#475569'}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
            
            {/* 3D-Effekt Linien */}
            <motion.path
              d="M8 13L9 14M16 13L15 14"
              stroke={isHovered ? '#06B6D4' : '#94A3B8'}
              strokeWidth="1.5"
              strokeLinecap="round"
              opacity={isHovered ? 0.8 : 0.4}
              animate={{
                opacity: isHovered ? [0.4, 0.8, 0.4] : 0.4
              }}
              transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
            />
            
            {/* Futuristische Räder */}
            <motion.circle
              cx="9"
              cy="20"
              r="1"
              stroke={isHovered ? '#1E3A8A' : '#475569'}
              strokeWidth="2"
              fill="none"
              animate={{
                rotate: isHovered ? 360 : 0
              }}
              transition={{ duration: 2, ease: "linear", repeat: isHovered ? Infinity : 0 }}
            />
            <motion.circle
              cx="20"
              cy="20"
              r="1"
              stroke={isHovered ? '#1E3A8A' : '#475569'}
              strokeWidth="2"
              fill="none"
              animate={{
                rotate: isHovered ? -360 : 0
              }}
              transition={{ duration: 2, ease: "linear", repeat: isHovered ? Infinity : 0 }}
            />
            
            {/* Architektonische Details */}
            <motion.path
              d="M6 8H18M10 8V12M14 8V12"
              stroke={isHovered ? '#06B6D4' : '#CBD5E1'}
              strokeWidth="1"
              strokeLinecap="round"
              opacity={isHovered ? 0.6 : 0.3}
              animate={{
                opacity: isHovered ? [0.3, 0.6, 0.3] : 0.3
              }}
              transition={{ duration: 2, repeat: isHovered ? Infinity : 0 }}
            />
            
            {/* Holographische Scan-Linien */}
            {isHovered && (
              <motion.g>
                <motion.line
                  x1="4"
                  y1="6"
                  x2="20"
                  y2="6"
                  stroke="#00F5FF"
                  strokeWidth="0.5"
                  opacity="0.8"
                  initial={{ x1: 4, x2: 4 }}
                  animate={{ x1: 4, x2: 20 }}
                  transition={{ duration: 1, ease: "easeInOut", repeat: Infinity, repeatDelay: 0.5 }}
                />
                <motion.line
                  x1="4"
                  y1="10"
                  x2="20"
                  y2="10"
                  stroke="#00F5FF"
                  strokeWidth="0.5"
                  opacity="0.6"
                  initial={{ x1: 4, x2: 4 }}
                  animate={{ x1: 4, x2: 20 }}
                  transition={{ duration: 1, ease: "easeInOut", repeat: Infinity, repeatDelay: 1 }}
                />
                <motion.line
                  x1="4"
                  y1="14"
                  x2="20"
                  y2="14"
                  stroke="#00F5FF"
                  strokeWidth="0.5"
                  opacity="0.4"
                  initial={{ x1: 4, x2: 4 }}
                  animate={{ x1: 4, x2: 20 }}
                  transition={{ duration: 1, ease: "easeInOut", repeat: Infinity, repeatDelay: 1.5 }}
                />
              </motion.g>
            )}
          </svg>
        </motion.div>

        {/* Quantum Particles */}
        {isHovered && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-cyan-400 rounded-full"
                style={{
                  top: `${20 + i * 10}%`,
                  left: `${15 + i * 12}%`,
                }}
                animate={{
                  y: [-5, -15, -5],
                  x: [-3, 3, -3],
                  opacity: [0, 1, 0],
                  scale: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 2,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            ))}
          </div>
        )}

        {/* Architektonische Rahmen */}
        <div className="absolute inset-0 rounded-2xl pointer-events-none">
          <div className="absolute top-2 left-2 w-3 h-3 border-l-2 border-t-2 border-blue-300/40 rounded-tl-md" />
          <div className="absolute top-2 right-2 w-3 h-3 border-r-2 border-t-2 border-cyan-300/40 rounded-tr-md" />
          <div className="absolute bottom-2 left-2 w-3 h-3 border-l-2 border-b-2 border-cyan-300/40 rounded-bl-md" />
          <div className="absolute bottom-2 right-2 w-3 h-3 border-r-2 border-b-2 border-blue-300/40 rounded-br-md" />
        </div>
        
        {/* Fließender Energy-Beam */}
        {isHovered && (
          <motion.div
            className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400/80 to-transparent rounded-full"
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 1, ease: "easeInOut", repeat: Infinity, repeatDelay: 0.5 }}
          />
        )}
      </motion.div>
      
      {/* Ultra-futuristischer Counter Badge */}
      {state.itemCount > 0 && (
        <motion.div
          initial={{ scale: 0, rotateZ: -180 }}
          animate={{ scale: 1, rotateZ: 0 }}
          exit={{ scale: 0, rotateZ: 180 }}
          className="absolute -top-3 -right-3 min-w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-2xl"
          style={{
            background: 'linear-gradient(135deg, #1E3A8A 0%, #06B6D4 50%, #3B82F6 100%)',
            boxShadow: '0 0 20px rgba(30, 58, 138, 0.6), 0 0 40px rgba(6, 182, 212, 0.4), 0 8px 16px rgba(0, 0, 0, 0.3), inset 0 2px 4px rgba(255, 255, 255, 0.6)',
            border: '2px solid rgba(255, 255, 255, 0.4)'
          }}
          whileHover={{ scale: 1.15 }}
        >
          <motion.span
            key={state.itemCount}
            initial={{ y: 12, opacity: 0, rotateX: -90 }}
            animate={{ y: 0, opacity: 1, rotateX: 0 }}
            style={{
              textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 800
            }}
          >
            {state.itemCount > 99 ? '99+' : state.itemCount}
          </motion.span>
          
          {/* Dreifacher Puls-Ring */}
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute inset-0 rounded-full border-2 border-cyan-400/60"
              animate={{
                scale: [1, 1.6, 1],
                opacity: [0.8, 0, 0.8]
              }}
              transition={{
                duration: 2,
                delay: i * 0.4,
                repeat: Infinity,
                ease: "easeOut"
              }}
            />
          ))}
          
          {/* Rotating Ring */}
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background: 'conic-gradient(from 0deg, rgba(6, 182, 212, 0.8), rgba(30, 58, 138, 0.4), rgba(59, 130, 246, 0.6), rgba(6, 182, 212, 0.8))',
              mask: 'radial-gradient(circle, transparent 60%, black 65%)'
            }}
            animate={{ rotate: 360 }}
            transition={{ duration: 3, ease: "linear", repeat: Infinity }}
          />
        </motion.div>
      )}
      
      {/* Quantum Field Glow */}
      <motion.div
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(96, 165, 250, 0.15) 0%, rgba(34, 211, 238, 0.1) 40%, transparent 70%)',
          opacity: isHovered ? 0.9 : 0,
          filter: 'blur(12px)',
          transform: 'scale(1.8)'
        }}
        animate={{ 
          opacity: isHovered ? 0.9 : 0,
          scale: isHovered ? 1.8 : 1.5
        }}
        transition={{ duration: 0.4 }}
      />
      
      {/* Orbiting Particles */}
      {isHovered && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(4)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 bg-blue-400/80 rounded-full"
              style={{
                top: '50%',
                left: '50%',
                originX: 0,
                originY: 0
              }}
              animate={{
                rotate: 360,
                scale: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 3,
                delay: i * 0.5,
                repeat: Infinity,
                ease: "linear"
              }}
              transform={`translate(-50%, -50%) translate(${25 + i * 5}px, 0)`}
            />
          ))}
        </div>
      )}
    </motion.button>
  );
}