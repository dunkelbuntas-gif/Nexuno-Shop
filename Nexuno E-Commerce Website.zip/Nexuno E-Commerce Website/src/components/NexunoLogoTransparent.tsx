import React from 'react';
import nexunoLogo from 'figma:asset/dc274090c09a9c81d77ec4f6306cfa2f84599213.png';

interface NexunoLogoTransparentProps {
  size?: number;
  onClick?: () => void;
  className?: string;
  glowEffect?: boolean;
}

export function NexunoLogoTransparent({ 
  size = 64, 
  onClick,
  className = '',
  glowEffect = false
}: NexunoLogoTransparentProps) {
  
  const logoStyle: React.CSSProperties = {
    width: `${size}px`,
    height: 'auto',
    maxWidth: '100%',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    
    // Optimiert für das neue Chrom-Logo mit blauen Akzenten
    filter: glowEffect 
      ? 'brightness(1.1) contrast(1.2) saturate(1.1) drop-shadow(0 0 15px rgba(30, 58, 138, 0.3)) drop-shadow(0 0 30px rgba(6, 182, 212, 0.15))'
      : 'brightness(1.05) contrast(1.1) saturate(1.02)',
    
    // Blend-Mode für natürliche Integration
    mixBlendMode: 'normal',
    
    // Das neue Logo ist bereits perfekt freigestellt
    background: 'transparent',
  };

  const containerStyle: React.CSSProperties = {
    position: 'relative',
    display: 'inline-block',
    background: 'transparent',
    borderRadius: '12px',
    padding: '4px',
    cursor: onClick ? 'pointer' : 'default',
  };

  // Fortgeschrittene Hintergrundentfernung mit CSS
  const logoWithTransparency = (
    <div 
      className="relative"
      style={{
        background: 'transparent',
        borderRadius: '12px',
        overflow: 'hidden',
      }}
    >
      {/* Basis-Logo mit Transparenz-Effekt */}
      {/* Logo entfernt - nur Text wird verwendet */}
      
      {/* Das neue Logo benötigt keine Hintergrund-Maskierung */}
    </div>
  );

  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={`group relative transition-all duration-500 hover:scale-105 border-0 bg-transparent ${className}`}
        style={containerStyle}
      >
        {logoWithTransparency}
        
        {/* Hover Glow Effect */}
        <div 
          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(30, 58, 138, 0.15) 0%, transparent 70%)',
            filter: 'blur(10px)',
            transform: 'scale(1.4)'
          }}
        />
      </button>
    );
  }

  return (
    <div className={className} style={containerStyle}>
      {logoWithTransparency}
    </div>
  );
}

// Pure CSS-basierte Alternative mit Clipping
export function NexunoLogoClipped({ 
  size = 64, 
  onClick,
  className = ''
}: {
  size?: number;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <div 
      className={`relative inline-block ${className}`}
      onClick={onClick}
      style={{ cursor: onClick ? 'pointer' : 'default' }}
    >
      <img
        src={nexunoLogo}
        alt="Nexuno"
        style={{
          width: `${size}px`,
          height: 'auto',
          // Experimenteller Ansatz für Transparenz
          filter: 'brightness(1.1) contrast(1.2) saturate(1.1)',
          background: 'transparent',
          // Verwende Clip-Path um nur das Logo zu zeigen
          clipPath: 'circle(45% at 50% 50%)',
          transition: 'all 0.3s ease',
        }}
      />
    </div>
  );
}

// SVG Mask Approach
export function NexunoLogoMasked({ 
  size = 64, 
  onClick,
  className = ''
}: {
  size?: number;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <div className={`relative inline-block ${className}`}>
      <div
        onClick={onClick}
        className="cursor-pointer transition-transform duration-300 hover:scale-105"
        style={{
          width: `${size}px`,
          height: `${size}px`,
          background: `url(${nexunoLogo}) center/contain no-repeat`,
          
          // Maske um grauen Hintergrund zu entfernen
          maskImage: `
            radial-gradient(circle at 50% 40%, black 35%, transparent 65%),
            radial-gradient(circle at 50% 80%, black 20%, transparent 40%)
          `,
          WebkitMaskImage: `
            radial-gradient(circle at 50% 40%, black 35%, transparent 65%),
            radial-gradient(circle at 50% 80%, black 20%, transparent 40%)
          `,
          maskComposite: 'add',
          WebkitMaskComposite: 'source-over',
          
          // Zusätzliche Verbesserungen
          filter: 'brightness(1.1) contrast(1.2)',
        }}
      />
    </div>
  );
}