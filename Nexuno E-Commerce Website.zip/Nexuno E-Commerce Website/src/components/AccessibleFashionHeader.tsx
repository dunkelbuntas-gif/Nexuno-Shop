import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ShoppingCart, Menu, X, ChevronDown, Home, Package, Shirt, Headphones, User } from 'lucide-react';
import nexunoLogo from 'figma:asset/4ad9d5ae3940675aade2f657fdb6be9ab32df100.png';

interface AccessibleFashionHeaderProps {
  currentPage?: string;
  selectedCategory?: string | null;
  cartCount?: number;
  onNavigationClick?: (page: string) => void;
  onCategoryClick?: (category: string) => void;
  onSearchClick?: () => void;
  onCartClick?: () => void;
  onContactPageNavigate?: () => void;
}

export function AccessibleFashionHeader({ 
  currentPage = 'home', 
  selectedCategory = null,
  cartCount = 0, 
  onNavigationClick, 
  onCategoryClick,
  onSearchClick, 
  onCartClick,
  onContactPageNavigate 
}: AccessibleFashionHeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [announceMessage, setAnnounceMessage] = useState('');
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  // Navigation items with ARIA-compliant structure
  const navigationItems = [
    { 
      id: 'home', 
      label: 'Startseite', 
      type: 'page' as const,
      icon: Home,
      ariaLabel: 'Zur Startseite navigieren'
    },
    { 
      id: 'tshirts', 
      label: 'T-Shirts', 
      type: 'category' as const, 
      category: 'tshirts',
      icon: Shirt,
      ariaLabel: 'T-Shirts Kategorie anzeigen'
    },
    { 
      id: 'hoodies', 
      label: 'Hoodies', 
      type: 'category' as const, 
      category: 'hoodies',
      icon: Package,
      ariaLabel: 'Hoodies Kategorie anzeigen'
    },
    { 
      id: 'accessories', 
      label: 'Accessoires', 
      type: 'category' as const, 
      category: 'accessories',
      icon: Headphones,
      ariaLabel: 'Accessoires Kategorie anzeigen'
    },
    { 
      id: 'about', 
      label: 'Über uns', 
      type: 'page' as const,
      icon: User,
      ariaLabel: 'Über uns Seite öffnen'
    }
  ];

  // Screen reader announcements
  const announceToScreenReader = (message: string) => {
    setAnnounceMessage(message);
    setTimeout(() => setAnnounceMessage(''), 1000);
  };

  // Handle navigation with accessibility
  const handleItemClick = (item: typeof navigationItems[0]) => {
    const actionMessage = `Navigation zu ${item.label}`;
    announceToScreenReader(actionMessage);
    
    if (item.type === 'category' && item.category) {
      onCategoryClick?.(item.category);
    } else {
      onNavigationClick?.(item.id);
    }
    
    // Close mobile menu after navigation
    if (isMobileMenuOpen) {
      setIsMobileMenuOpen(false);
      menuButtonRef.current?.focus();
    }
  };

  // Handle cart click with accessibility
  const handleCartClick = () => {
    const message = cartCount > 0 
      ? `Warenkorb öffnen, ${cartCount} ${cartCount === 1 ? 'Artikel' : 'Artikel'}`
      : 'Warenkorb ist leer';
    announceToScreenReader(message);
    onCartClick?.();
  };

  // Handle search click
  const handleSearchClick = () => {
    announceToScreenReader('Suche öffnen');
    onSearchClick?.();
  };

  // Keyboard navigation for mobile menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isMobileMenuOpen) return;

      if (e.key === 'Escape') {
        setIsMobileMenuOpen(false);
        menuButtonRef.current?.focus();
        announceToScreenReader('Menü geschlossen');
      }

      // Tab trapping in mobile menu
      if (e.key === 'Tab' && mobileMenuRef.current) {
        const focusableElements = mobileMenuRef.current.querySelectorAll(
          'button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault();
          firstElement?.focus();
        } else if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault();
          lastElement?.focus();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isMobileMenuOpen]);

  // Focus management for mobile menu
  useEffect(() => {
    if (isMobileMenuOpen) {
      // Focus first interactive element in mobile menu
      setTimeout(() => {
        const firstFocusable = mobileMenuRef.current?.querySelector(
          'button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])'
        ) as HTMLElement;
        firstFocusable?.focus();
      }, 100);
    }
  }, [isMobileMenuOpen]);

  const isItemActive = (item: typeof navigationItems[0]) => {
    return item.type === 'page' 
      ? currentPage === item.id 
      : item.type === 'category' && selectedCategory === item.category;
  };

  return (
    <>
      {/* Header */}
      <header 
        className="fixed top-0 left-0 right-0 z-50 h-[70px]"
        role="banner"
        id="navigation"
      >
        {/* Glassmorphism Background with sufficient contrast */}
        <div 
          className="absolute inset-0 backdrop-blur-[24px]"
          style={{
            background: 'rgba(15, 23, 42, 0.95)', // Higher opacity for better contrast
            borderBottom: '1px solid rgba(34, 211, 238, 0.3)' // More visible border
          }}
        >
          {/* Subtle glow effect - reduced for accessibility */}
          <motion.div
            className="absolute inset-0 opacity-20"
            animate={{
              background: [
                'linear-gradient(90deg, rgba(34, 211, 238, 0.05) 0%, transparent 50%, rgba(59, 130, 246, 0.05) 100%)',
                'linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, transparent 50%, rgba(34, 211, 238, 0.05) 100%)'
              ]
            }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </div>

        {/* Main Header Content */}
        <div className="relative z-10 max-w-7xl mx-auto h-full flex items-center justify-between px-6 lg:px-12 xl:px-16">
          
          {/* Logo Container */}
          <motion.div 
            className="flex items-center"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <button
              onClick={() => handleItemClick(navigationItems[0])}
              className="flex items-center space-x-3 group focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800 rounded-lg p-2"
              aria-label="Nexuno Startseite - Fashion der Zukunft"
            >
              <img 
                src={nexunoLogo}
                alt="Nexuno Logo - Fashion der Zukunft" 
                className="h-16 w-auto object-contain group-hover:scale-105 transition-all duration-300"
                style={{
                  filter: 'drop-shadow(0 0 8px rgba(34, 211, 238, 0.4)) brightness(1.1) contrast(1.2)',
                }}
              />
            </button>
          </motion.div>

          {/* Desktop Navigation */}
          <nav 
            className="hidden lg:flex items-center space-x-1"
            role="navigation"
            aria-label="Hauptnavigation"
          >
            {navigationItems.map((item, index) => {
              const isActive = isItemActive(item);
              const Icon = item.icon;
              
              return (
                <motion.button
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className={`
                    relative px-4 py-3 rounded-full transition-all duration-300 font-semibold text-sm
                    focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800
                    ${isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/25'
                      : 'text-cyan-100 hover:text-white hover:bg-white/10 hover:shadow-lg hover:shadow-white/10'
                    }
                  `}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ 
                    scale: 1.05,
                    boxShadow: isActive 
                      ? '0 0 25px rgba(34, 211, 238, 0.5)' 
                      : '0 0 20px rgba(255, 255, 255, 0.15)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  aria-label={item.ariaLabel}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <span className="flex items-center gap-2">
                    <Icon className="w-4 h-4" aria-hidden="true" />
                    <span>{item.label}</span>
                  </span>
                  
                  {/* Active state indicator */}
                  {isActive && (
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-cyan-400"
                      animate={{
                        boxShadow: [
                          '0 0 0 0 rgba(34, 211, 238, 0.4)',
                          '0 0 0 4px rgba(34, 211, 238, 0.1)',
                          '0 0 0 0 rgba(34, 211, 238, 0.4)'
                        ]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                  )}
                </motion.button>
              );
            })}
          </nav>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-3">
            <button
              ref={menuButtonRef}
              onClick={() => {
                setIsMobileMenuOpen(!isMobileMenuOpen);
                announceToScreenReader(isMobileMenuOpen ? 'Menü schließen' : 'Menü öffnen');
              }}
              className="p-3 text-cyan-100 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800"
              aria-label={isMobileMenuOpen ? 'Menü schließen' : 'Menü öffnen'}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" aria-hidden="true" />
              ) : (
                <Menu className="w-6 h-6" aria-hidden="true" />
              )}
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            
            {/* Search Button */}
            <motion.button
              onClick={handleSearchClick}
              className="relative w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 hover:border-cyan-400/30 transition-all duration-300 flex items-center justify-center group focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800"
              whileHover={{ 
                scale: 1.1,
                boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
              }}
              whileTap={{ scale: 0.95 }}
              aria-label="Produktsuche öffnen"
            >
              <Search className="w-5 h-5 text-cyan-100 group-hover:text-cyan-300 transition-colors" aria-hidden="true" />
            </motion.button>

            {/* Cart Button */}
            <motion.button
              onClick={handleCartClick}
              className="relative w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 hover:border-cyan-400/30 transition-all duration-300 flex items-center justify-center group focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800"
              whileHover={{ 
                scale: 1.1,
                boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
              }}
              whileTap={{ scale: 0.95 }}
              aria-label={`Warenkorb öffnen${cartCount > 0 ? `, ${cartCount} ${cartCount === 1 ? 'Artikel' : 'Artikel'}` : ', leer'}`}
            >
              <ShoppingCart className="w-5 h-5 text-cyan-100 group-hover:text-cyan-300 transition-colors" aria-hidden="true" />
              
              {/* Cart Count Badge */}
              {cartCount > 0 && (
                <motion.span
                  className="absolute -top-1 -right-1 bg-gradient-to-r from-cyan-500 to-teal-600 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold border-2 border-slate-800 shadow-lg"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  aria-hidden="true"
                >
                  {cartCount > 99 ? '99+' : cartCount}
                </motion.span>
              )}
            </motion.button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Mobile Menu Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsMobileMenuOpen(false);
                announceToScreenReader('Menü geschlossen');
              }}
              aria-hidden="true"
            />

            {/* Mobile Menu Panel */}
            <motion.div
              ref={mobileMenuRef}
              id="mobile-menu"
              className="fixed top-[70px] left-0 right-0 bg-slate-900/95 backdrop-blur-xl border-b border-cyan-500/20 shadow-2xl z-50 lg:hidden"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              role="navigation"
              aria-label="Mobile Navigation"
            >
              <div className="max-w-7xl mx-auto px-6 py-6">
                <nav className="space-y-2">
                  {navigationItems.map((item, index) => {
                    const isActive = isItemActive(item);
                    const Icon = item.icon;
                    
                    return (
                      <motion.button
                        key={item.id}
                        onClick={() => handleItemClick(item)}
                        className={`
                          w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all duration-300 font-semibold
                          focus:outline-none focus:ring-3 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-900
                          ${isActive
                            ? 'bg-gradient-to-r from-cyan-500 to-teal-600 text-white shadow-lg'
                            : 'text-cyan-100 hover:text-white hover:bg-white/10'
                          }
                        `}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        aria-label={item.ariaLabel}
                        aria-current={isActive ? 'page' : undefined}
                      >
                        <Icon className="w-5 h-5" aria-hidden="true" />
                        <span>{item.label}</span>
                        {isActive && (
                          <motion.div
                            className="ml-auto w-2 h-2 bg-cyan-300 rounded-full"
                            animate={{ scale: [1, 1.3, 1] }}
                            transition={{ duration: 2, repeat: Infinity }}
                            aria-hidden="true"
                          />
                        )}
                      </motion.button>
                    );
                  })}
                </nav>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Screen Reader Live Region */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      >
        {announceMessage}
      </div>
    </>
  );
}