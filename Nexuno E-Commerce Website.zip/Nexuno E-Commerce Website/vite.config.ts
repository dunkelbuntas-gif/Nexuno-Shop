import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
    alias: {
      '@': path.resolve(__dirname, './src'),
      // Assets aus Figma sauber eingebunden:
      'figma:asset/dc274090c09a9c81d77ec4f6306cfa2f84599213.png': path.resolve(__dirname, './src/assets/dc274090c09a9c81d77ec4f6306cfa2f84599213.png'),
      'figma:asset/db9b1a940f86a71b32d08f262eb4b3ead661e592.png': path.resolve(__dirname, './src/assets/db9b1a940f86a71b32d08f262eb4b3ead661e592.png'),
      'figma:asset/a5c6e7e8662005139629ba7328feb60041cb02f8.png': path.resolve(__dirname, './src/assets/a5c6e7e8662005139629ba7328feb60041cb02f8.png'),
      'figma:asset/84ac582a90684d8cb0342fab1247d589eef95963.png': path.resolve(__dirname, './src/assets/84ac582a90684d8cb0342fab1247d589eef95963.png'),
      'figma:asset/57b9a3671729d05d31e4544f2743178209cfda41.png': path.resolve(__dirname, './src/assets/57b9a3671729d05d31e4544f2743178209cfda41.png'),
      'figma:asset/4ad9d5ae3940675aade2f657fdb6be9ab32df100.png': path.resolve(__dirname, './src/assets/4ad9d5ae3940675aade2f657fdb6be9ab32df100.png'),
      'figma:asset/4728a1be20e4308ce92fe6224a7df676f8b7c2a2.png': path.resolve(__dirname, './src/assets/4728a1be20e4308ce92fe6224a7df676f8b7c2a2.png'),
      'figma:asset/2d04372e838a9cca216f6ce55ecc0e6d045f9f70.png': path.resolve(__dirname, './src/assets/2d04372e838a9cca216f6ce55ecc0e6d045f9f70.png'),
    },
  },
  build: {
    target: 'esnext',
    outDir: 'dist', // Wichtig: Vercel erkennt nur "dist" als Standard
    emptyOutDir: true, // räumt den Ordner bei jedem Build auf
  },
  server: {
    port: 3000,
    open: true,
  },
  preview: {
    port: 4173,
    open: true,
  },
});