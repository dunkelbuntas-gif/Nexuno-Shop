import React, { useState } from 'react';
import { X, Heart, ShoppingCart, Trash2, Share2 } from 'lucide-react';
import { useWishlist } from './WishlistContext';
import { useCart } from '../cart/CartContext';
import { motion, AnimatePresence } from 'motion/react';

interface WishlistSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WishlistSidebar({ isOpen, onClose }: WishlistSidebarProps) {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addItem } = useCart();
  const [movingToCart, setMovingToCart] = useState<number | null>(null);

  const moveToCart = async (product: any) => {
    setMovingToCart(product.id);
    
    // Add to cart
    addItem({
      id: product.id,
      name: product.name,
      price: parseFloat(product.price?.replace('€', '') || '0'),
      image: product.thumbnail_url,
      quantity: 1,
    });

    // Wait for animation
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Remove from wishlist
    removeFromWishlist(product.id);
    setMovingToCart(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="ml-auto h-full w-full max-w-md bg-white shadow-2xl"
          >
            <div className="flex h-full flex-col">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-gray-200 p-6">
                <div className="flex items-center gap-3">
                  <Heart className="w-6 h-6 text-red-500 fill-current" />
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900">Wunschliste</h2>
                    <p className="text-sm text-gray-500">{wishlist.length} Artikel</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto">
                {wishlist.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center p-6">
                    <Heart className="w-16 h-16 text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Ihre Wunschliste ist leer
                    </h3>
                    <p className="text-gray-500 mb-6">
                      Speichern Sie Ihre Lieblingsprodukte für später
                    </p>
                    <button
                      onClick={onClose}
                      className="bg-gradient-to-r from-cyan-500 to-teal-600 text-white px-6 py-2 rounded-lg hover:from-cyan-600 hover:to-teal-700 transition-all duration-200"
                    >
                      Weiter einkaufen
                    </button>
                  </div>
                ) : (
                  <div className="p-4 space-y-4">
                    <AnimatePresence>
                      {wishlist.map((item) => (
                        <motion.div
                          key={item.id}
                          layout
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ 
                            opacity: movingToCart === item.id ? 0.5 : 1, 
                            y: 0,
                            scale: movingToCart === item.id ? 0.95 : 1
                          }}
                          exit={{ opacity: 0, x: 100 }}
                          transition={{ duration: 0.2 }}
                          className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-all duration-200"
                        >
                          <div className="flex gap-4">
                            <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                              {item.thumbnail_url ? (
                                <img
                                  src={item.thumbnail_url}
                                  alt={item.name}
                                  className="w-full h-full object-cover"
                                  loading="lazy"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-400">
                                  <Heart className="w-6 h-6" />
                                </div>
                              )}
                            </div>

                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-gray-900 line-clamp-2 mb-1">
                                {item.name}
                              </h3>
                              <p className="text-sm text-gray-500 mb-2">
                                {item.categoryName}
                              </p>
                              <div className="flex items-center justify-between">
                                <span className="font-semibold text-lg text-cyan-600">
                                  {item.price}
                                </span>
                                <div className="flex gap-2">
                                  <motion.button
                                    onClick={() => moveToCart(item)}
                                    disabled={movingToCart === item.id}
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    className="p-2 bg-gradient-to-r from-cyan-500 to-teal-600 text-white rounded-lg hover:from-cyan-600 hover:to-teal-700 transition-all duration-200 disabled:opacity-50"
                                    title="In den Warenkorb"
                                  >
                                    <ShoppingCart className="w-4 h-4" />
                                  </motion.button>
                                  <motion.button
                                    onClick={() => removeFromWishlist(item.id)}
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                                    title="Entfernen"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </motion.button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>

              {/* Footer */}
              {wishlist.length > 0 && (
                <div className="border-t border-gray-200 p-6 space-y-3">
                  <button
                    onClick={() => {
                      // Move all items to cart
                      wishlist.forEach(item => moveToCart(item));
                    }}
                    className="w-full bg-gradient-to-r from-cyan-500 to-teal-600 text-white py-3 rounded-lg hover:from-cyan-600 hover:to-teal-700 transition-all duration-200 font-medium"
                  >
                    Alle in den Warenkorb
                  </button>
                  <button
                    onClick={clearWishlist}
                    className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                  >
                    Wunschliste leeren
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}