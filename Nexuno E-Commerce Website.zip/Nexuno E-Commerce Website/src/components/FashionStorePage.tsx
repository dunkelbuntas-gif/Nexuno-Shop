import React, { useState, useEffect } from "react";
import { SearchOverlay } from "./SearchOverlay";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import ErrorBoundary from "./ErrorBoundary";
import { useCart } from './cart/CartContext';
import { ProductGrid } from './ProductGrid'; // Lokaler Katalog
// ✨ Updated import - using the new EnhancedQuickViewModal instead of deprecated EnhancedQuickView
import { EnhancedQuickViewModal } from './product/EnhancedQuickViewModal';

// ✨ PRINTFUL INTEGRATION - Now fully activated!
import { PrintfulProductGrid } from './printful/PrintfulProductGrid';
import { PrintfulDesignStudio } from './printful/PrintfulDesignStudio';
import type { PrintfulProduct } from '../lib/printful-api';

import {
  Search,
  ShoppingCart,
  Star,
  Truck,
  Shield,
  Headphones,
  Award,
  Heart,
  Filter,
  List,
  Grid3X3,
  // ✨ Printful Icons
  Palette,
  Shirt,
  Package,
  Zap,
} from "lucide-react";
import exampleImage from "figma:asset/4728a1be20e4308ce92fe6224a7df676f8b7c2a2.png";

import { FashionImpressumPage } from "./fashion/FashionImpressumPage";
import { FashionDatenschutzPage } from "./fashion/FashionDatenschutzPage";
import { FashionAGBPage } from "./fashion/FashionAGBPage";
import { FashionWiderrufsrechtPage } from "./fashion/FashionWiderrufsrechtPage";
import { FashionContactPage } from "./fashion/FashionContactPage";

import { EnhancedHeroSection } from "./EnhancedHeroSection";
import { FashionHeader } from "./FashionHeader";

interface FashionStorePageProps {
  onNavigate?: (page: string) => void;
}

export function FashionStorePage({ onNavigate }: FashionStorePageProps = {}) {
  const [currentPage, setCurrentPage] = useState<"shop" | "impressum" | "datenschutz" | "agb" | "widerruf" | "contact" | "product">("shop");
  const [isLoading, setIsLoading] = useState(false);
  const [productsLoaded, setProductsLoaded] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [openId, setOpenId] = React.useState<number | null>(null);
  const [componentErrors, setComponentErrors] = useState<Set<string>>(new Set());

  // ✨ PRINTFUL STATE MANAGEMENT
  const [showPrintfulSection, setShowPrintfulSection] = useState(false);
  const [selectedPrintfulProduct, setSelectedPrintfulProduct] = useState<any>(null);
  const [showDesignStudio, setShowDesignStudio] = useState(false);
  const [currentTab, setCurrentTab] = useState<'collection' | 'printful'>('collection');

  // Use real cart state from CartContext
  const { state: cartState, toggleCart } = useCart();

  // Emergency initialization - set loaded immediately
  React.useEffect(() => {
    // Immediate initialization to prevent timeout - no delay
    setProductsLoaded(true);
    setIsLoading(false);
  }, []);

  React.useEffect(() => {
    const timeoutId = setTimeout(() => {
      const handler = (e: any) => {
        try {
          setOpenId(e.detail?.id ?? null);
        } catch (error) {
          console.warn('Error handling open-product event:', error);
        }
      };
      
      window.addEventListener('open-product', handler as any);
      return () => window.removeEventListener('open-product', handler as any);
    }, 100);

    return () => clearTimeout(timeoutId);
  }, []);

  // Component error handler
  const handleComponentError = React.useCallback((componentName: string, error: Error) => {
    console.warn(`Component error in ${componentName}:`, error.message);
    setComponentErrors(prev => new Set([...prev, componentName]));
  }, []);

  const handleNavigation = (page: string) => {
    if (page === "search") return setShowSearch((v) => !v);
    if (page === "cart") return onNavigate?.('cart'); // Navigate to cart page
    console.log("Navigate to:", page);
    // Reset category when navigating to pages
    setSelectedCategory(null);
  };

  const handleCategoryClick = (category: string) => {
    console.log("Category selected:", category);
    setSelectedCategory(category);
    // Scroll to products section
    const productsSection = document.getElementById('products-section');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBackToShop = () => setCurrentPage("shop");
  const handleProductClick = (productId: string) => { setSelectedProductId(productId); setCurrentPage("product"); };
  const openCart = () => {
    toggleCart();
  };
  
  const addItem = (item: any) => {
    // Add item functionality is handled in App.tsx - this is just a placeholder
    console.log("Adding item:", item);
  };

  // ✨ PRINTFUL HANDLERS
  const handlePrintfulProductSelect = (product: any) => {
    setSelectedPrintfulProduct(product);
    setShowDesignStudio(true);
  };

  const handleDesignStudioClose = () => {
    setShowDesignStudio(false);
    setSelectedPrintfulProduct(null);
  };

  const handlePrintfulAddToCart = (designData: any) => {
    // Add Printful product to cart
    console.log('Adding Printful design to cart:', designData);
    // Here you would integrate with your cart system
    setShowDesignStudio(false);
    setSelectedPrintfulProduct(null);
    // Show success toast
  };

  const handleTabSwitch = (tab: 'collection' | 'printful') => {
    setCurrentTab(tab);
    if (tab === 'printful') {
      setShowPrintfulSection(true);
    }
  };

  const featuredProducts = [
    { id: 1, name: "AI Neural Backpack", category: "Tech Bags", price: "€299.99", originalPrice: "€349.99", image: exampleImage, rating: 4.9, reviews: 127, badge: "AI-Enhanced", badgeColor: "bg-cyan-500" },
    { id: 2, name: "Smart Hoodie Pro", category: "Tech Wear", price: "€189.99", originalPrice: "€229.99", image: exampleImage, rating: 4.8, reviews: 93, badge: "New Tech", badgeColor: "bg-blue-500" },
    { id: 3, name: "Future Runners X1", category: "Smart Shoes", price: "€399.99", originalPrice: "€449.99", image: exampleImage, rating: 5.0, reviews: 156, badge: "Limited AI", badgeColor: "bg-teal-500" },
    { id: 4, name: "Neural Interface Band", category: "AI Accessories", price: "€149.99", originalPrice: "€199.99", image: exampleImage, rating: 4.7, reviews: 64, badge: "Future Tech", badgeColor: "bg-slate-500" },
  ];

  const usps = [
    { icon: <Truck className="h-8 w-8" />, title: "Kostenloser Versand", description: "Bei Bestellungen über € 69", color: "text-green-500" },
    { icon: <Shield className="h-8 w-8" />, title: "14 Tage Rückgaberecht", description: "Einfache Rücksendung", color: "text-blue-500" },
    { icon: <Headphones className="h-8 w-8" />, title: "24/7 Support", description: "Immer für dich da", color: "text-purple-500" },
    { icon: <Award className="h-8 w-8" />, title: "Premium Qualität", description: "Nur das Beste für dich", color: "text-orange-500" },
  ];

  // Legal pages
  if (currentPage === "impressum") return <FashionImpressumPage onBack={handleBackToShop} />;
  if (currentPage === "datenschutz") return <FashionDatenschutzPage onBack={handleBackToShop} />;
  if (currentPage === "agb") return <FashionAGBPage onBack={handleBackToShop} />;
  if (currentPage === "widerruf") return <FashionWiderrufsrechtPage onBack={handleBackToShop} />;
  if (currentPage === "contact") return <FashionContactPage onBack={handleBackToShop} />;

  if (currentPage === "product") {
    return (
      <>
        <EnhancedQuickViewModal
          productId={selectedProductId}
          isOpen={true}
          onClose={() => setCurrentPage("shop")}
          onNavigate={(page) => (page === "shop" ? setCurrentPage("shop") : console.log("Navigate to:", page))}
          onBack={() => setCurrentPage("shop")}
        />
      </>
    );
  }

  // MAIN
  return (
    <div className={`transition-opacity duration-300 ${isLoading ? 'opacity-50' : 'opacity-100'}`}>
        {/* Wichtig: Top-Padding, damit der fixed Header nichts überlappt */}
        <div className="min-h-screen bg-slate-950 text-white pt-[70px] relative">
          {/* HEADER */}
          <FashionHeader
            currentPage={currentPage}
            selectedCategory={selectedCategory}
            cartCount={cartState.itemCount}
            onNavigationClick={handleNavigation}
            onCategoryClick={handleCategoryClick}
            onSearchClick={() => setShowSearch(true)}
            onCartClick={openCart}
            onContactPageNavigate={() => setCurrentPage('contact')}
          />

          {/* SEARCH OVERLAY */}
          <SearchOverlay isOpen={showSearch} onClose={() => setShowSearch(false)} onProductSelect={handleProductClick} />

          {/* HERO (eigenen Stacking-Context geben) */}
          <section className="relative z-0 overflow-hidden isolate">
            <EnhancedHeroSection />
          </section>


          {/* USPs */}
          <section className="relative z-10 py-20 bg-gradient-to-bl from-slate-600 via-slate-700 to-blue-800 text-white overflow-hidden isolate">
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="tech-grid-minimal"></div>
            </div>
            <div className="max-w-7xl mx-auto px-6 relative z-10">
              <div className="text-center mb-14">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white glow-text-tech">
                  Deine Zukunft trägt Intelligence
                </h2>
                <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
                  Erlebe Mode, die mit dir denkt, sich anpasst und deine Persönlichkeit 
                  in jedem Stoff zum Leben erweckt. Willkommen in der Neural Fashion Era.
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {usps.map((usp, index) => (
                  <div key={index} className="text-center group">
                    <div className={`inline-flex items-center justify-center w-14 h-14 rounded-xl bg-slate-800 group-hover:bg-slate-700 transition-all duration-200 mb-5 ${usp.color}`}>{usp.icon}</div>
                    <h3 className="text-lg font-semibold mb-2">{usp.title}</h3>
                    <p className="text-slate-300 text-sm">{usp.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>         

          {/* Local Catalog Products with Categories */}
          <section id="products-section" className="relative z-10 py-20 bg-gradient-to-br from-slate-700 via-slate-800 to-blue-900 text-white overflow-hidden isolate">
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="tech-grid-minimal"></div>
            </div>
            <div className="max-w-7xl mx-auto px-6 relative z-10">
              {/* ✨ TAB NAVIGATION */}
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white glow-text-tech">
                  Nexuno Fashion Store
                </h2>
                <div className="flex justify-center mb-8">
                  <div className="bg-slate-800/50 rounded-xl p-2 backdrop-blur-lg border border-slate-600">
                    <button
                      onClick={() => handleTabSwitch('collection')}
                      className={`px-6 py-3 rounded-lg transition-all duration-300 font-medium ${
                        currentTab === 'collection'
                          ? 'bg-gradient-to-r from-cyan-500 to-cyan-600 text-white shadow-lg'
                          : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Package className="w-5 h-5" />
                        Ready-to-Wear Collection
                      </div>
                    </button>
                    <button
                      onClick={() => handleTabSwitch('printful')}
                      className={`px-6 py-3 rounded-lg transition-all duration-300 font-medium ${
                        currentTab === 'printful'
                          ? 'bg-gradient-to-r from-cyan-500 to-cyan-600 text-white shadow-lg'
                          : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Palette className="w-5 h-5" />
                        Design Your Own
                      </div>
                    </button>
                  </div>
                </div>
              </div>

              {/* COLLECTION TAB */}
              {currentTab === 'collection' && (
                <ErrorBoundary 
                  onError={(error) => handleComponentError('ProductGrid', error)}
                  fallback={
                    <div className="text-center py-12">
                      <div className="bg-slate-800/50 rounded-lg p-8 max-w-md mx-auto">
                        <h3 className="text-xl font-semibold mb-4">Produkte werden geladen...</h3>
                        <p className="text-slate-300 mb-4">
                          Die Produktdaten werden von unserem lokalen Katalog abgerufen.
                        </p>
                        <div className="animate-pulse bg-slate-700 h-8 rounded-lg mx-auto w-32"></div>
                      </div>
                    </div>
                  }
                >
                  {productsLoaded && !componentErrors.has('ProductGrid') ? (
                    <ProductGrid selectedCategory={selectedCategory} />
                  ) : (
                    <div className="text-center py-12">
                      <div className="bg-slate-800/50 rounded-lg p-8 max-w-md mx-auto">
                        <div className="animate-pulse">
                          <div className="bg-slate-700 h-6 rounded mb-4 mx-auto w-48"></div>
                          <div className="bg-slate-700 h-4 rounded mb-3 mx-auto w-64"></div>
                          <div className="bg-slate-700 h-8 rounded mx-auto w-32"></div>
                        </div>
                      </div>
                    </div>
                  )}
                </ErrorBoundary>
              )}

              {/* ✨ PRINTFUL TAB */}
              {currentTab === 'printful' && (
                <div className="space-y-8">
                  {/* Print-on-Demand Hero */}
                  <div className="text-center mb-12">
                    <div className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 rounded-2xl p-8 backdrop-blur-sm border border-slate-600">
                      <div className="flex justify-center mb-6">
                        <div className="flex items-center gap-4">
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Shirt className="w-8 h-8 text-cyan-400" />
                          </div>
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Palette className="w-8 h-8 text-cyan-400" />
                          </div>
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Zap className="w-8 h-8 text-cyan-400" />
                          </div>
                        </div>
                      </div>
                      <h3 className="text-2xl font-bold mb-4 text-white">
                        Design Your Perfect Style
                      </h3>
                      <p className="text-slate-300 max-w-2xl mx-auto leading-relaxed">
                        Erstelle einzigartige Designs auf Premium-Produkten. Von T-Shirts bis Hoodies - 
                        deine Kreativität wird Realität durch unsere Print-on-Demand Technologie.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                        <div className="text-center">
                          <div className="bg-slate-700/50 rounded-lg p-4 mb-3">
                            <Palette className="w-6 h-6 text-cyan-400 mx-auto" />
                          </div>
                          <h4 className="font-semibold text-white mb-2">Design Upload</h4>
                          <p className="text-sm text-slate-400">Lade dein Design hoch oder erstelle Text-Designs</p>
                        </div>
                        <div className="text-center">
                          <div className="bg-slate-700/50 rounded-lg p-4 mb-3">
                            <Shirt className="w-6 h-6 text-cyan-400 mx-auto" />
                          </div>
                          <h4 className="font-semibold text-white mb-2">Premium Products</h4>
                          <p className="text-sm text-slate-400">Hochwertige Materialien von Printful</p>
                        </div>
                        <div className="text-center">
                          <div className="bg-slate-700/50 rounded-lg p-4 mb-3">
                            <Package className="w-6 h-6 text-cyan-400 mx-auto" />
                          </div>
                          <h4 className="font-semibold text-white mb-2">Global Fulfillment</h4>
                          <p className="text-sm text-slate-400">Weltweiter Versand direkt zu dir</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Printful Products Grid */}
                  <ErrorBoundary 
                    onError={(error) => handleComponentError('PrintfulProductGrid', error)}
                    fallback={
                      <div className="text-center py-12">
                        <div className="bg-slate-800/50 rounded-lg p-8 max-w-md mx-auto">
                          <h3 className="text-xl font-semibold mb-4">Loading Printful Products...</h3>
                          <p className="text-slate-300 mb-4">
                            Connecting to Printful API via Cloudflare Workers...
                          </p>
                          <div className="animate-pulse bg-slate-700 h-8 rounded-lg mx-auto w-48"></div>
                        </div>
                      </div>
                    }
                  >
                    <PrintfulProductGrid 
                      onProductSelect={handlePrintfulProductSelect}
                    />
                  </ErrorBoundary>
                </div>
              )}
            </div>
          </section>

          {/* ✨ PRINTFUL DESIGN STUDIO MODAL */}
          {showDesignStudio && selectedPrintfulProduct && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <PrintfulDesignStudio
                product={selectedPrintfulProduct}
                onClose={handleDesignStudioClose}
                onAddToCart={handlePrintfulAddToCart}
              />
            </div>
          )} 

          {/* Footer */}
          <footer className="bg-slate-600 text-white py-16 relative z-10">
            <div className="max-w-7xl mx-auto px-6">
              <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p className="text-gray-400 text-sm mb-4 md:mb-0">© 2025 FashionStore. Alle Rechte vorbehalten.</p>
                <div className="flex flex-wrap gap-4 justify-center md:justify-end">
                  <button onClick={() => setCurrentPage("impressum")} className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Impressum</button>
                  <button onClick={() => setCurrentPage("datenschutz")} className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Datenschutz</button>
                  <button onClick={() => setCurrentPage("agb")} className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">AGB</button>
                  <button onClick={() => setCurrentPage("widerruf")} className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Widerrufsrecht</button>
                  <button onClick={() => setCurrentPage("contact")} className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">Kontakt</button>
                </div>
              </div>
            </div>
          </footer>

          {/* CART wird in App.tsx gerendert */}

          {/* CHECKOUT */}
          {showCheckout && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg p-6 max-w-md w-full">
                <h3 className="text-lg font-semibold mb-4">Checkout</h3>
                <p className="text-gray-600 mb-4">Checkout-Funktionalität wird bald verfügbar sein.</p>
                <button 
                  onClick={() => setShowCheckout(false)}
                  className="w-full bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700 transition-colors"
                >
                  Schließen
                </button>
              </div>
            </div>
          )}

          {/* Local Product Detail Modal */}
          {openId !== null && (
            <EnhancedQuickViewModal id={openId} isOpen={true} onClose={() => setOpenId(null)} />
          )}

          {/* Debug Tools removed to prevent timeout issues - consolidated to centralized debug component */}
        </div>
    </div>
  );
}