import React from 'react';
import { Heart } from 'lucide-react';
import { useWishlist } from './WishlistContext';
import { CategorizedProduct } from '../../src/lib/api';
import { motion } from 'motion/react';

interface WishlistButtonProps {
  product: CategorizedProduct;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export function WishlistButton({ 
  product, 
  size = 'md', 
  showText = false, 
  className = '' 
}: WishlistButtonProps) {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const isWishlisted = isInWishlist(product.id);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isWishlisted) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const sizeClasses = {
    sm: 'p-1.5',
    md: 'p-2',
    lg: 'p-3'
  };

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };

  return (
    <motion.button
      onClick={handleClick}
      className={`
        relative rounded-full transition-all duration-200 
        ${isWishlisted 
          ? 'bg-red-50 hover:bg-red-100 text-red-600 border-red-200' 
          : 'bg-white/80 backdrop-blur hover:bg-white text-slate-600 hover:text-red-500 border-white/30'
        } 
        border hover:scale-110 focus:outline-none focus:ring-2 focus:ring-red-400/60 
        focus:ring-offset-2 focus:ring-offset-slate-900
        ${sizeClasses[size]} ${className}
      `}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      title={isWishlisted ? 'Aus Wunschliste entfernen' : 'Zur Wunschliste hinzufügen'}
    >
      <motion.div
        animate={{
          scale: isWishlisted ? [1, 1.3, 1] : 1,
        }}
        transition={{ duration: 0.3 }}
      >
        <Heart 
          className={`${iconSizes[size]} transition-all duration-200 ${
            isWishlisted ? 'fill-current' : ''
          }`} 
        />
      </motion.div>
      
      {showText && (
        <span className="ml-2 text-sm font-medium">
          {isWishlisted ? 'Gespeichert' : 'Speichern'}
        </span>
      )}

      {/* Pulse effect when added */}
      {isWishlisted && (
        <motion.div
          className="absolute inset-0 rounded-full bg-red-400"
          initial={{ scale: 1, opacity: 0.5 }}
          animate={{ scale: 1.5, opacity: 0 }}
          transition={{ duration: 0.6 }}
        />
      )}
    </motion.button>
  );
}