import { useState } from 'react';
import { ShoppingBag, Check } from 'lucide-react';
import { useCart } from './CartContext';
import { motion } from 'motion/react';
import { Button } from '../ui/button';

interface AddToCartButtonProps {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    category: string;
  };
  selectedSize?: string;
  selectedColor?: string;
  disabled?: boolean;
  className?: string;
}

export function AddToCartButton({ 
  product, 
  selectedSize, 
  selectedColor, 
  disabled = false,
  className = ""
}: AddToCartButtonProps) {
  const { addItem, openCart } = useCart();
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      size: selectedSize,
      color: selectedColor
    });

    setIsAdded(true);
    
    // Reset the success state after 2 seconds
    setTimeout(() => {
      setIsAdded(false);
    }, 2000);

    // Open cart sidebar
    setTimeout(() => {
      openCart();
    }, 500);
  };

  return (
    <motion.div 
      className={className}
      whileHover={!disabled ? { scale: 1.02 } : undefined}
      whileTap={!disabled ? { scale: 0.98 } : undefined}
    >
      <Button
        onClick={handleAddToCart}
        disabled={disabled || isAdded}
        className="w-full relative overflow-hidden"
        style={{
          background: isAdded 
            ? 'linear-gradient(135deg, #10B981 0%, #059669 100%)'
            : 'linear-gradient(135deg, var(--accent-pink) 0%, var(--accent-cyan) 100%)',
          border: 'none',
          color: 'var(--text-white)',
          opacity: disabled ? 0.5 : 1,
          cursor: disabled ? 'not-allowed' : 'pointer'
        }}
      >
        <motion.div
          initial={false}
          animate={{
            x: isAdded ? 0 : 0,
            opacity: 1
          }}
          className="flex items-center justify-center gap-2"
        >
          <motion.div
            initial={false}
            animate={{
              rotate: isAdded ? 360 : 0,
              scale: isAdded ? [1, 1.2, 1] : 1
            }}
            transition={{ duration: 0.5 }}
          >
            {isAdded ? (
              <Check size={20} />
            ) : (
              <ShoppingBag size={20} />
            )}
          </motion.div>
          
          <span>
            {isAdded ? 'Hinzugefügt!' : 'In den Warenkorb'}
          </span>
        </motion.div>

        {/* Success animation overlay */}
        {isAdded && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)'
            }}
          />
        )}
      </Button>
    </motion.div>
  );
}