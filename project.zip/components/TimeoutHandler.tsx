/**
 * TimeoutHandler - Prevents app-wide timeout issues
 * Handles component loading timeouts gracefully
 */

import React, { useState, useEffect, useRef } from 'react';

interface TimeoutHandlerProps {
  timeout?: number;
  fallback?: React.ReactNode;
  errorMessage?: string;
  retryable?: boolean;
  children: React.ReactNode;
}

export const TimeoutHandler: React.FC<TimeoutHandlerProps> = ({
  timeout = 10000,
  fallback,
  errorMessage = 'Komponente konnte nicht geladen werden',
  retryable = true,
  children
}) => {
  const [hasTimedOut, setHasTimedOut] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    setHasTimedOut(false);

    // Set timeout
    timeoutRef.current = setTimeout(() => {
      if (mounted.current) {
        console.warn(`Component timed out after ${timeout}ms`);
        setHasTimedOut(true);
      }
    }, timeout);

    return () => {
      mounted.current = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [timeout, retryKey]);

  const handleRetry = () => {
    setRetryKey(prev => prev + 1);
  };

  if (hasTimedOut) {
    if (fallback) {
      return <>{fallback}</>;
    }

    return (
      <div className="flex items-center justify-center p-8 bg-slate-900/50 rounded-lg border border-slate-700">
        <div className="text-center">
          <div className="text-yellow-400 mb-3 text-2xl">⏱️</div>
          <p className="text-white mb-4">{errorMessage}</p>
          {retryable && (
            <button
              onClick={handleRetry}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors"
            >
              Erneut versuchen
            </button>
          )}
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default TimeoutHandler;