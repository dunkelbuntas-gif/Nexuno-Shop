import { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { Input } from './ui/input';
import type { Page } from '../App';

interface SearchBarProps {
  onNavigate: (page: Page, productId?: string) => void;
  variant?: 'header' | 'footer' | 'header-large' | 'mobile';
}

// Mock product data for search suggestions
const products = [
  { id: '1', name: 'Neon Circuit Hoodie', category: 'hoodies' },
  { id: '2', name: 'Future Tech T-Shirt', category: 'tshirts' },
  { id: '3', name: 'Cyber Mesh Tank Top', category: 'tshirts' },
  { id: '4', name: 'Digital Dreams Hoodie', category: 'hoodies' },
  { id: '5', name: 'Holographic Beanie', category: 'accessories' },
  { id: '6', name: 'Neo Matrix T-Shirt', category: 'tshirts' },
  { id: '7', name: 'Quantum Pulse Hoodie', category: 'hoodies' },
  { id: '8', name: 'Futuristic Backpack', category: 'accessories' },
  { id: '9', name: 'Binary Code T-Shirt', category: 'tshirts' },
  { id: '10', name: 'Neon City Oversized Hoodie', category: 'hoodies' },
  { id: '11', name: 'Tech Wear Cap', category: 'accessories' },
  { id: '12', name: 'Cyber Grid T-Shirt', category: 'tshirts' },
];

export function SearchBar({ onNavigate, variant = 'header' }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<typeof products>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (searchTerm.length >= 2) {
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setSuggestions(filtered.slice(0, 6)); // Limit to 6 suggestions
      setShowSuggestions(filtered.length > 0);
      setSelectedIndex(-1);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => Math.min(prev + 1, suggestions.length - 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => Math.max(prev - 1, -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0) {
          handleSuggestionClick(suggestions[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowSuggestions(false);
        setSelectedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  const handleSuggestionClick = (product: typeof products[0]) => {
    setSearchTerm(product.name);
    setShowSuggestions(false);
    onNavigate('product', product.id);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleInputFocus = () => {
    if (suggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  const isFooter = variant === 'footer';
  const isHeaderLarge = variant === 'header-large';
  const isMobile = variant === 'mobile';

  const getSearchStyles = () => {
    if (isFooter) {
      return {
        container: 'w-64',
        input: 'w-64 bg-white border-gray-300 text-[#333333] placeholder:text-gray-500 focus:border-[#00E5FF] focus:ring-[#00E5FF]',
        icon: 'text-gray-400'
      };
    }
    
    if (isHeaderLarge) {
      return {
        container: 'w-[420px] max-w-[480px] min-w-[280px]',
        input: 'w-full rounded-md bg-slate-800/70 text-slate-100 placeholder:text-slate-300/60 shadow-sm focus:outline-none focus:ring-2 focus:ring-[var(--neon-cyan)]/70 border-0',
        icon: 'text-slate-300/70'
      };
    }
    
    if (isMobile) {
      return {
        container: 'w-full',
        input: 'w-full bg-slate-800/70 border-slate-600 text-slate-100 placeholder:text-slate-300/60 focus:border-[var(--neon-cyan)] focus:ring-[var(--neon-cyan)]',
        icon: 'text-slate-300/70'
      };
    }
    
    // Default header variant
    return {
      container: 'w-64',
      input: 'w-64 bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus:border-[var(--neon-cyan)] focus:ring-[var(--neon-cyan)]',
      icon: 'text-gray-400'
    };
  };

  const styles = getSearchStyles();

  return (
    <div ref={searchRef} className={`relative ${styles.container}`}>
      <div className="relative">
        <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 ${styles.icon}`} />
        <Input
          ref={inputRef}
          type="search"
          placeholder={isHeaderLarge ? "Suchen…" : "Suchen..."}
          value={searchTerm}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onKeyDown={handleKeyDown}
          className={`pl-10 ${styles.input}`}
          style={{ fontSize: '14px' }}
        />
      </div>

      {/* Search Suggestions Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className={`absolute top-full left-0 right-0 z-50 mt-2 ${
          isFooter 
            ? 'bg-white border-gray-200' 
            : isHeaderLarge || isMobile
              ? 'bg-slate-900/95 border-white/10'
              : 'bg-gray-800 border-gray-600'
        } border rounded-lg shadow-lg ${
          isHeaderLarge ? 'ring-1 ring-white/10' : ''
        } overflow-hidden`}>
          {suggestions.map((product, index) => (
            <button
              key={product.id}
              onClick={() => handleSuggestionClick(product)}
              className={`w-full px-4 py-3 text-left transition-all duration-200 border-b last:border-b-0 ${
                isFooter 
                  ? 'border-gray-100' 
                  : isHeaderLarge || isMobile
                    ? 'border-white/10'
                    : 'border-gray-700'
              } ${
                selectedIndex === index
                  ? isFooter
                    ? 'bg-gray-50 text-[#333333]'
                    : isHeaderLarge || isMobile
                      ? 'bg-slate-800/80 text-white'
                      : 'bg-gray-700 text-white'
                  : isFooter
                    ? 'text-[#333333] hover:bg-gray-50'
                    : isHeaderLarge || isMobile
                      ? 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              } ${
                selectedIndex === index && isFooter
                  ? 'shadow-[0_0_10px_#00E5FF] relative'
                  : ''
              }`}
              style={{
                fontSize: '14px',
                ...(selectedIndex === index && isFooter && {
                  boxShadow: '0 0 0 1px #00E5FF, 0 0 10px rgba(0,229,255,0.3)',
                })
              }}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">{product.name}</span>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  isFooter 
                    ? 'bg-gray-100 text-gray-600' 
                    : isHeaderLarge || isMobile
                      ? 'bg-slate-700 text-slate-300'
                      : 'bg-gray-600 text-gray-300'
                }`}>
                  {product.category === 'tshirts' && 'T-Shirts'}
                  {product.category === 'hoodies' && 'Hoodies'}
                  {product.category === 'accessories' && 'Accessories'}
                </span>
              </div>
              {selectedIndex === index && isFooter && (
                <div 
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[var(--neon-cyan)] to-[var(--neon-magenta)]"
                  style={{
                    background: 'linear-gradient(90deg, #00ffff 0%, #ff00ff 100%)',
                    boxShadow: '0 0 10px #00E5FF'
                  }}
                />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}