export const widerrufsTexts = {
  belehrung: {
    title: "Widerrufsbelehrung",
    sections: [
      {
        title: "Widerrufsrecht",
        content: "Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen. Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter Dritter, der nicht der Beförderer ist, die Waren in Besitz genommen haben bzw. hat."
      },
      {
        title: "Widerrufsfolgen",
        content: "Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung als die von uns angebotene, günstigste Standardlieferung gewählt haben), unverzüglich und spätestens binnen vierzehn Tagen ab dem Tag zurückzuzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist."
      }
    ]
  },
  muster: {
    title: "Muster-Widerrufsformular",
    content: "Wenn Sie den Vertrag widerrufen wollen, dann füllen Sie bitte dieses Formular aus und senden Sie es zurück.",
    fields: [
      "An: Nexuno Fashion GmbH, Fließstraße 6, 12439 Berlin, E-Mail: info@nexuno.eu",
      "Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag über den Kauf der folgenden Waren (*)/die Erbringung der folgenden Dienstleistung (*)",
      "Bestellt am (*)/erhalten am (*)",
      "Name des/der Verbraucher(s)",
      "Anschrift des/der Verbraucher(s)",
      "Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier)",
      "Datum",
      "(*) Unzutreffendes streichen."
    ]
  },
  hinweise: {
    title: "Besondere Hinweise",
    content: [
      "Das Widerrufsrecht besteht nicht bei Verträgen zur Lieferung von Waren, die nicht vorgefertigt sind und für deren Herstellung eine individuelle Auswahl oder Bestimmung durch den Verbraucher maßgeblich ist oder die eindeutig auf die persönlichen Bedürfnisse des Verbrauchers zugeschnitten sind.",
      "Bei Widerruf haben Sie die Kosten der Rücksendung zu tragen, wenn die gelieferte Ware der bestellten entspricht und wenn der Preis der zurückzusendenden Sache einen Betrag von 40 Euro nicht übersteigt oder wenn Sie bei einem höheren Preis der Sache zum Zeitpunkt des Widerrufs noch nicht die Gegenleistung oder eine vertraglich vereinbarte Teilzahlung erbracht haben."
    ]
  }
};

export const datenschutzTexts = {
  sections: [
    {
      title: "1. Datenschutz auf einen Blick",
      subsections: [
        {
          title: "Allgemeine Hinweise",
          content: "Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können."
        },
        {
          title: "Datenerfassung auf dieser Website",
          content: "Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten können Sie dem Abschnitt 'Hinweis zur Verantwortlichen Stelle' in dieser Datenschutzerklärung entnehmen."
        }
      ]
    },
    {
      title: "2. Hosting",
      subsections: [
        {
          title: "Externes Hosting",
          content: "Diese Website wird extern gehostet. Die personenbezogenen Daten, die auf dieser Website erfasst werden, werden auf den Servern des Hosters gespeichert. Hierbei kann es sich v. a. um IP-Adressen, Kontaktanfragen, Meta- und Kommunikationsdaten, Vertragsdaten, Kontaktdaten, Namen, Websitezugriffe und sonstige Daten handeln."
        }
      ]
    }
  ]
};

export const agbTexts = {
  sections: [
    {
      title: "§ 1 Geltungsbereich",
      content: [
        "(1) Diese Allgemeinen Geschäftsbedingungen (nachfolgend 'AGB') der Nexuno Fashion GmbH (nachfolgend 'Verkäufer') gelten für alle Verträge über die Lieferung von Waren, die ein Verbraucher oder Unternehmer (nachfolgend 'Kunde') mit dem Verkäufer hinsichtlich der vom Verkäufer in seinem Online-Shop dargestellten Waren abschließt.",
        "(2) Entgegenstehende oder von diesen AGB abweichende Bedingungen des Kunden werden nicht anerkannt, es sei denn, der Verkäufer stimmt ihrer Geltung ausdrücklich schriftlich zu."
      ]
    },
    {
      title: "§ 2 Vertragsschluss",
      content: [
        "(1) Die im Online-Shop des Verkäufers enthaltenen Produktbeschreibungen stellen keine verbindlichen Angebote seitens des Verkäufers dar, sondern dienen zur Abgabe eines verbindlichen Angebots durch den Kunden.",
        "(2) Der Kunde kann das Angebot über das in den Online-Shop des Verkäufers integrierte Online-Bestellsystem abgeben."
      ]
    }
  ]
};