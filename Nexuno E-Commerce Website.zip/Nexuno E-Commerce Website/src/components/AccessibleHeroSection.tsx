import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Play, Pause, ArrowDown, Sparkles, Zap, Globe } from 'lucide-react';

interface AccessibleHeroSectionProps {
  onExploreClick?: () => void;
  onShopNowClick?: () => void;
}

export function AccessibleHeroSection({ onExploreClick, onShopNowClick }: AccessibleHeroSectionProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [announceMessage, setAnnounceMessage] = useState('');
  const heroRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Hero slides with WCAG-compliant content
  const heroSlides = [
    {
      id: 1,
      title: 'Fashion der Zukunft',
      subtitle: 'Entdecken Sie Nexuno',
      description: 'Erleben Sie revolutionäre Mode, die Technologie und Style perfekt vereint. Unsere Kollektionen definieren Fashion neu.',
      cta: 'Kollektion entdecken',
      ctaAction: 'explore',
      bgGradient: 'from-slate-900 via-slate-800 to-cyan-900',
      accentColor: 'cyan',
      features: ['Nachhaltige Materialien', 'Smart Technology', 'Futuristisches Design']
    },
    {
      id: 2,
      title: 'Nachhaltiger Luxus',
      subtitle: 'Verantwortungsvoll',
      description: 'Umweltfreundliche Materialien treffen auf innovative Designs. Mode, die gut aussieht und Gutes tut.',
      cta: 'Nachhaltige Produkte',
      ctaAction: 'shop',
      bgGradient: 'from-slate-900 via-emerald-900 to-slate-800',
      accentColor: 'emerald',
      features: ['Bio-zertifiziert', 'Recycelte Materialien', 'CO2-neutral']
    },
    {
      id: 3,
      title: 'Personalisiert für Sie',
      subtitle: 'Maßgeschneidert',
      description: 'Individuelle Anpassungen und smarte Technologie schaffen einzigartige Kleidungsstücke nur für Sie.',
      cta: 'Jetzt konfigurieren',
      ctaAction: 'customize',
      bgGradient: 'from-slate-900 via-purple-900 to-slate-800',
      accentColor: 'purple',
      features: ['AI-powered Fitting', 'Custom Design', 'Express Delivery']
    }
  ];

  const currentSlideData = heroSlides[currentSlide];

  // Screen reader announcements
  const announceToScreenReader = (message: string) => {
    setAnnounceMessage(message);
    setTimeout(() => setAnnounceMessage(''), 1000);
  };

  // Auto-play functionality
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentSlide((prev) => {
          const nextSlide = (prev + 1) % heroSlides.length;
          announceToScreenReader(`Slide ${nextSlide + 1} von ${heroSlides.length}: ${heroSlides[nextSlide].title}`);
          return nextSlide;
        });
      }, 5000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPlaying, heroSlides]);

  // Handle manual slide change
  const goToSlide = (slideIndex: number) => {
    setCurrentSlide(slideIndex);
    announceToScreenReader(`Slide ${slideIndex + 1} von ${heroSlides.length}: ${heroSlides[slideIndex].title}`);
  };

  // Handle play/pause
  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
    announceToScreenReader(isPlaying ? 'Slideshow pausiert' : 'Slideshow gestartet');
  };

  // Handle CTA clicks
  const handleCTAClick = (action: string) => {
    switch (action) {
      case 'explore':
        onExploreClick?.();
        announceToScreenReader('Navigation zur Kollektion');
        break;
      case 'shop':
        onShopNowClick?.();
        announceToScreenReader('Navigation zum Shop');
        break;
      case 'customize':
        announceToScreenReader('Produktkonfigurator wird geöffnet');
        break;
      default:
        onExploreClick?.();
    }
  };

  // Skip to main content
  const handleSkipToContent = () => {
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
      mainContent.focus();
      mainContent.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Get accent colors for current slide
  const getAccentClasses = (color: string) => {
    const colorMap = {
      cyan: {
        text: 'text-cyan-400',
        bg: 'bg-cyan-500',
        hover: 'hover:bg-cyan-600',
        border: 'border-cyan-500',
        ring: 'focus:ring-cyan-400'
      },
      emerald: {
        text: 'text-emerald-400',
        bg: 'bg-emerald-500',
        hover: 'hover:bg-emerald-600',
        border: 'border-emerald-500',
        ring: 'focus:ring-emerald-400'
      },
      purple: {
        text: 'text-purple-400',
        bg: 'bg-purple-500',
        hover: 'hover:bg-purple-600',
        border: 'border-purple-500',
        ring: 'focus:ring-purple-400'
      }
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.cyan;
  };

  const accentClasses = getAccentClasses(currentSlideData.accentColor);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      role="banner"
      aria-label="Hero Bereich - Nexuno Fashion der Zukunft"
    >
      {/* Skip to content link for keyboard users */}
      <button
        onClick={handleSkipToContent}
        className="sr-only focus:not-sr-only absolute top-4 left-4 z-50 bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold focus:outline-none"
      >
        Zum Hauptinhalt springen
      </button>

      {/* Background with Animation */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          className={`absolute inset-0 bg-gradient-to-br ${currentSlideData.bgGradient}`}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
      </AnimatePresence>

      {/* Futuristic Grid Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(34, 211, 238, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(34, 211, 238, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px'
          }}
        />
      </div>

      {/* Floating Design Elements - Reduced for accessibility */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className={`absolute w-20 h-20 border-2 ${accentClasses.border} rounded-lg opacity-20`}
            style={{
              top: `${20 + i * 30}%`,
              left: `${10 + i * 25}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 5, 0],
            }}
            transition={{
              duration: 6 + i * 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 xl:px-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Text Content */}
          <motion.div 
            className="text-center lg:text-left"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.6 }}
              >
                {/* Subtitle */}
                <motion.p 
                  className={`${accentClasses.text} font-semibold text-lg mb-4 tracking-wide`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {currentSlideData.subtitle}
                </motion.p>

                {/* Main Title */}
                <motion.h1 
                  className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4, duration: 0.6 }}
                  style={{
                    textShadow: '0 0 30px rgba(34, 211, 238, 0.3)'
                  }}
                >
                  {currentSlideData.title}
                </motion.h1>

                {/* Description */}
                <motion.p 
                  className="text-xl text-cyan-100 mb-8 leading-relaxed max-w-2xl"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  {currentSlideData.description}
                </motion.p>

                {/* Features List */}
                <motion.div 
                  className="flex flex-wrap gap-4 mb-8 justify-center lg:justify-start"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  {currentSlideData.features.map((feature, index) => (
                    <div 
                      key={feature}
                      className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 text-cyan-100"
                    >
                      {index === 0 && <Sparkles className="w-4 h-4" aria-hidden="true" />}
                      {index === 1 && <Zap className="w-4 h-4" aria-hidden="true" />}
                      {index === 2 && <Globe className="w-4 h-4" aria-hidden="true" />}
                      <span className="text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </motion.div>

                {/* CTA Button */}
                <motion.button
                  onClick={() => handleCTAClick(currentSlideData.ctaAction)}
                  className={`
                    inline-flex items-center gap-3 ${accentClasses.bg} ${accentClasses.hover} text-white 
                    px-8 py-4 rounded-full font-bold text-lg shadow-2xl
                    transition-all duration-300 transform hover:scale-105
                    focus:outline-none focus:ring-4 ${accentClasses.ring} focus:ring-offset-2 focus:ring-offset-transparent
                  `}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7, duration: 0.4 }}
                  whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(0,0,0,0.3)" }}
                  whileTap={{ scale: 0.98 }}
                  aria-label={`${currentSlideData.cta} - ${currentSlideData.description}`}
                >
                  <span>{currentSlideData.cta}</span>
                  <ChevronRight className="w-6 h-6" aria-hidden="true" />
                </motion.button>
              </motion.div>
            </AnimatePresence>
          </motion.div>

          {/* Visual Content Area */}
          <motion.div 
            className="relative flex items-center justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {/* Large Brand Symbol */}
            <div className="relative">
              <motion.div
                className={`w-64 h-64 ${accentClasses.bg} rounded-full opacity-20 blur-xl`}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.2, 0.3, 0.2],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="text-white text-8xl font-bold opacity-60"
                  animate={{
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  N
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Slide Controls */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
        <div className="flex items-center gap-4 bg-black/30 backdrop-blur-sm rounded-full px-6 py-3">
          
          {/* Play/Pause Button */}
          <button
            onClick={togglePlayPause}
            className="p-2 text-white hover:text-cyan-400 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded-full"
            aria-label={isPlaying ? 'Slideshow pausieren' : 'Slideshow abspielen'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5" aria-hidden="true" />
            ) : (
              <Play className="w-5 h-5" aria-hidden="true" />
            )}
          </button>

          {/* Slide Indicators */}
          <div className="flex gap-2" role="tablist" aria-label="Slide Navigation">
            {heroSlides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => goToSlide(index)}
                className={`
                  w-3 h-3 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-yellow-400
                  ${index === currentSlide 
                    ? `${accentClasses.bg} shadow-lg` 
                    : 'bg-white/30 hover:bg-white/50'
                  }
                `}
                role="tab"
                aria-selected={index === currentSlide}
                aria-label={`Slide ${index + 1}: ${slide.title}`}
              />
            ))}
          </div>
          
          {/* Slide Counter */}
          <span className="text-white text-sm font-medium ml-2">
            {currentSlide + 1} / {heroSlides.length}
          </span>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 right-8 z-20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
      >
        <button
          onClick={handleSkipToContent}
          className="flex flex-col items-center gap-2 text-white/70 hover:text-white transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded-lg p-2"
          aria-label="Zum Hauptbereich scrollen"
        >
          <span className="text-sm font-medium">Scrollen</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <ArrowDown className="w-5 h-5" aria-hidden="true" />
          </motion.div>
        </button>
      </motion.div>

      {/* Screen Reader Live Region */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      >
        {announceMessage}
      </div>

      {/* Loading Progress Bar */}
      {isPlaying && (
        <motion.div
          className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-cyan-500 to-teal-500 z-30"
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: 5, ease: "linear" }}
          key={currentSlide}
        />
      )}
    </section>
  );
}