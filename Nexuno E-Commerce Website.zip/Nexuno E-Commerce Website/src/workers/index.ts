/**
 * Nexuno Printful Integration - Cloudflare Workers
 * Complete Print-on-Demand Backend API
 */

export interface Env {
  PRINTFUL_API_KEY: string;
  PRINTFUL_API_URL: string;
  NEXUNO_FRONTEND_URL: string;
  CORS_ORIGIN: string;
  PRINTFUL_CACHE: KVNamespace;
  DESIGN_STORAGE: R2Bucket;
  ORDER_STATUS: DurableObjectNamespace;
}

// CORS Headers
const corsHeaders = (origin: string) => ({
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
  'Access-Control-Max-Age': '86400',
});

// Router
class PrintfulRouter {
  private env: Env;
  private request: Request;

  constructor(request: Request, env: Env) {
    this.request = request;
    this.env = env;
  }

  async handle(): Promise<Response> {
    const url = new URL(this.request.url);
    const path = url.pathname;
    const method = this.request.method;

    // Handle CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, {
        headers: corsHeaders(this.env.CORS_ORIGIN)
      });
    }

    try {
      // Route to appropriate handler
      if (path.startsWith('/printful/products')) {
        return await this.handleProducts();
      } else if (path.startsWith('/printful/variants')) {
        return await this.handleVariants();
      } else if (path.startsWith('/printful/mockups')) {
        return await this.handleMockups();
      } else if (path.startsWith('/printful/orders')) {
        return await this.handleOrders();
      } else if (path.startsWith('/printful/upload')) {
        return await this.handleUpload();
      } else if (path.startsWith('/printful/webhooks')) {
        return await this.handleWebhooks();
      } else if (path.startsWith('/printful/status')) {
        return await this.handleStatus();
      }

      return new Response('Not Found', { status: 404 });
    } catch (error) {
      console.error('Router Error:', error);
      return new Response(
        JSON.stringify({ error: 'Internal Server Error' }),
        { 
          status: 500, 
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(this.env.CORS_ORIGIN)
          }
        }
      );
    }
  }

  // Products Handler
  async handleProducts(): Promise<Response> {
    const url = new URL(this.request.url);
    const category = url.searchParams.get('category');
    const cacheKey = `products:${category || 'all'}`;

    // Try cache first
    const cached = await this.env.PRINTFUL_CACHE.get(cacheKey);
    if (cached) {
      return new Response(cached, {
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'public, max-age=3600',
          ...corsHeaders(this.env.CORS_ORIGIN)
        }
      });
    }

    // Fetch from Printful API
    const response = await fetch(`${this.env.PRINTFUL_API_URL}/products`, {
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error(`Printful API Error: ${response.status}`);
    }

    const data = await response.text();
    
    // Cache for 1 hour
    await this.env.PRINTFUL_CACHE.put(cacheKey, data, { expirationTtl: 3600 });

    return new Response(data, {
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'public, max-age=3600',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  // Product Variants Handler
  async handleVariants(): Promise<Response> {
    const url = new URL(this.request.url);
    const productId = url.pathname.split('/').pop();
    
    if (!productId) {
      return new Response(
        JSON.stringify({ error: 'Product ID required' }),
        { 
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(this.env.CORS_ORIGIN)
          }
        }
      );
    }

    const cacheKey = `variants:${productId}`;
    
    // Try cache first
    const cached = await this.env.PRINTFUL_CACHE.get(cacheKey);
    if (cached) {
      return new Response(cached, {
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'public, max-age=3600',
          ...corsHeaders(this.env.CORS_ORIGIN)
        }
      });
    }

    // Fetch variants from Printful
    const response = await fetch(`${this.env.PRINTFUL_API_URL}/products/${productId}`, {
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error(`Printful API Error: ${response.status}`);
    }

    const data = await response.text();
    
    // Cache for 1 hour
    await this.env.PRINTFUL_CACHE.put(cacheKey, data, { expirationTtl: 3600 });

    return new Response(data, {
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'public, max-age=3600',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  // Mockup Generation Handler
  async handleMockups(): Promise<Response> {
    if (this.request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }

    const body = await this.request.json();
    const { product_id, variant_id, design_url, placement } = body;

    const mockupRequest = {
      product_id,
      variant_id,
      files: [
        {
          url: design_url,
          type: 'default',
          placement: placement || 'front'
        }
      ]
    };

    const response = await fetch(`${this.env.PRINTFUL_API_URL}/mockup-generator/create-task/$(product_id)`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(mockupRequest)
    });

    if (!response.ok) {
      throw new Error(`Printful Mockup API Error: ${response.status}`);
    }

    const data = await response.text();

    return new Response(data, {
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  // Orders Handler
  async handleOrders(): Promise<Response> {
    if (this.request.method === 'POST') {
      return await this.createOrder();
    } else if (this.request.method === 'GET') {
      return await this.getOrderStatus();
    }

    return new Response('Method Not Allowed', { status: 405 });
  }

  private async createOrder(): Promise<Response> {
    const body = await this.request.json();
    
    // Validate order data
    if (!body.recipient || !body.items) {
      return new Response(
        JSON.stringify({ error: 'Missing required order data' }),
        { 
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(this.env.CORS_ORIGIN)
          }
        }
      );
    }

    // Create order in Printful
    const response = await fetch(`${this.env.PRINTFUL_API_URL}/orders`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Printful Order Error:', errorText);
      throw new Error(`Printful Order API Error: ${response.status}`);
    }

    const data = await response.text();

    return new Response(data, {
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  private async getOrderStatus(): Promise<Response> {
    const url = new URL(this.request.url);
    const orderId = url.searchParams.get('id');
    
    if (!orderId) {
      return new Response(
        JSON.stringify({ error: 'Order ID required' }),
        { 
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(this.env.CORS_ORIGIN)
          }
        }
      );
    }

    const response = await fetch(`${this.env.PRINTFUL_API_URL}/orders/${orderId}`, {
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error(`Printful Order Status API Error: ${response.status}`);
    }

    const data = await response.text();

    return new Response(data, {
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  // Design Upload Handler
  async handleUpload(): Promise<Response> {
    if (this.request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }

    const formData = await this.request.formData();
    const file = formData.get('design') as File;
    
    if (!file) {
      return new Response(
        JSON.stringify({ error: 'No file provided' }),
        { 
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(this.env.CORS_ORIGIN)
          }
        }
      );
    }

    // Generate unique filename
    const filename = `designs/${Date.now()}-${file.name}`;
    
    // Upload to R2 Storage
    await this.env.DESIGN_STORAGE.put(filename, file);
    
    // Create public URL
    const designUrl = `https://designs.nexuno.eu/${filename}`;

    // Upload to Printful File Library
    const printfulUpload = await fetch(`${this.env.PRINTFUL_API_URL}/files`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.env.PRINTFUL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: designUrl,
        filename: file.name
      })
    });

    if (!printfulUpload.ok) {
      throw new Error(`Printful Upload API Error: ${printfulUpload.status}`);
    }

    const printfulData = await printfulUpload.json();

    return new Response(JSON.stringify({
      success: true,
      design_url: designUrl,
      printful_file: printfulData
    }), {
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }

  // Webhooks Handler
  async handleWebhooks(): Promise<Response> {
    if (this.request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }

    const body = await this.request.json();
    const { type, data } = body;

    console.log('Webhook received:', type, data);

    // Handle different webhook types
    switch (type) {
      case 'order_updated':
        await this.handleOrderUpdate(data);
        break;
      case 'order_shipped':
        await this.handleOrderShipped(data);
        break;
      case 'order_canceled':
        await this.handleOrderCanceled(data);
        break;
      default:
        console.log('Unknown webhook type:', type);
    }

    return new Response('OK', { status: 200 });
  }

  private async handleOrderUpdate(orderData: any) {
    // Store order status in KV
    const orderKey = `order:${orderData.external_id}`;
    await this.env.PRINTFUL_CACHE.put(orderKey, JSON.stringify(orderData));
    
    // Could also trigger email notifications, etc.
  }

  private async handleOrderShipped(orderData: any) {
    console.log('Order shipped:', orderData.external_id);
    
    // Update order status
    const orderKey = `order:${orderData.external_id}`;
    await this.env.PRINTFUL_CACHE.put(orderKey, JSON.stringify({
      ...orderData,
      status: 'shipped'
    }));
  }

  private async handleOrderCanceled(orderData: any) {
    console.log('Order canceled:', orderData.external_id);
    
    // Update order status
    const orderKey = `order:${orderData.external_id}`;
    await this.env.PRINTFUL_CACHE.put(orderKey, JSON.stringify({
      ...orderData,
      status: 'canceled'
    }));
  }

  // Status Handler
  async handleStatus(): Promise<Response> {
    return new Response(JSON.stringify({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.0.0'
    }), {
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(this.env.CORS_ORIGIN)
      }
    });
  }
}

// Main Worker Handler
export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const router = new PrintfulRouter(request, env);
    return await router.handle();
  }
};