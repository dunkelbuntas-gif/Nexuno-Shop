import React from 'react';
import { Clock, Eye } from 'lucide-react';
import { useRecentlyViewed } from './RecentlyViewedContext';
import { motion } from 'motion/react';
import { WishlistButton } from '../wishlist/WishlistButton';

interface RecentlyViewedSectionProps {
  onProductClick?: (product: any) => void;
  showInSidebar?: boolean;
}

export function RecentlyViewedSection({ 
  onProductClick, 
  showInSidebar = false 
}: RecentlyViewedSectionProps) {
  const { recentlyViewed, clearRecentlyViewed } = useRecentlyViewed();

  if (recentlyViewed.length === 0) {
    return null;
  }

  const displayItems = showInSidebar ? recentlyViewed.slice(0, 5) : recentlyViewed;

  return (
    <div className={`${showInSidebar ? '' : 'max-w-7xl mx-auto px-6 py-12'}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Clock className="w-6 h-6 text-slate-600" />
          <div>
            <h2 className={`${showInSidebar ? 'text-lg' : 'text-2xl'} font-semibold text-slate-900`}>
              Kürzlich angesehen
            </h2>
            <p className="text-sm text-slate-500">
              {recentlyViewed.length} {recentlyViewed.length === 1 ? 'Artikel' : 'Artikel'}
            </p>
          </div>
        </div>
        
        {!showInSidebar && (
          <button
            onClick={clearRecentlyViewed}
            className="text-sm text-slate-500 hover:text-slate-700 transition-colors"
          >
            Alle löschen
          </button>
        )}
      </div>

      <div className={`
        grid gap-4 
        ${showInSidebar 
          ? 'grid-cols-1' 
          : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5'
        }
      `}>
        {displayItems.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="group cursor-pointer"
            onClick={() => onProductClick?.(product)}
          >
            <div className="relative bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-300 hover:border-cyan-300">
              {/* Product Image */}
              <div className={`
                ${showInSidebar ? 'aspect-square' : 'aspect-square'} 
                bg-slate-100 overflow-hidden relative
              `}>
                {product.thumbnail_url ? (
                  <img
                    src={product.thumbnail_url}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <Eye className="w-8 h-8" />
                  </div>
                )}

                {/* Wishlist Button */}
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <WishlistButton product={product} size="sm" />
                </div>

                {/* Recently Viewed Badge */}
                <div className="absolute top-2 left-2">
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs bg-black/50 text-white backdrop-blur">
                    <Clock className="w-3 h-3" />
                    {index === 0 ? 'Zuletzt' : `${index + 1}.`}
                  </span>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-3">
                <h3 className={`
                  ${showInSidebar ? 'text-sm' : 'text-sm'} 
                  font-medium text-slate-900 line-clamp-2 mb-2 group-hover:text-cyan-600 transition-colors
                `}>
                  {product.name}
                </h3>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {product.categoryName}
                  </span>
                  {product.price && (
                    <span className="font-semibold text-cyan-600">
                      {product.price}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {showInSidebar && recentlyViewed.length > 5 && (
        <div className="mt-4 text-center">
          <button className="text-sm text-cyan-600 hover:text-cyan-700 transition-colors">
            Alle {recentlyViewed.length} anzeigen
          </button>
        </div>
      )}
    </div>
  );
}