import React, { useState, useEffect, useRef } from 'react';
import { Search, X, TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import exampleImage from 'figma:asset/4728a1be20e4308ce92fe6224a7df676f8b7c2a2.png';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onProductSelect?: (productId: string) => void;
}

export function SearchOverlay({ isOpen, onClose, onProductSelect }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [recentSearches, setRecentSearches] = useState([
    'AI Neural Backpack',
    'Smart Hoodie',
    'Future Runners',
    'Tech Accessories'
  ]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Mock search data
  const mockProducts = [
    {
      id: '1',
      name: 'AI Neural Backpack',
      category: 'Tech Bags',
      price: '€299.99',
      image: exampleImage,
      rating: 4.9
    },
    {
      id: '2',
      name: 'Smart Hoodie Pro',
      category: 'Tech Wear',
      price: '€189.99',
      image: exampleImage,
      rating: 4.8
    },
    {
      id: '3',
      name: 'Future Runners X1',
      category: 'Smart Shoes',
      price: '€399.99',
      image: exampleImage,
      rating: 5.0
    },
    {
      id: '4',
      name: 'Neural Interface Band',
      category: 'AI Accessories',
      price: '€149.99',
      image: exampleImage,
      rating: 4.7
    }
  ];

  const trendingSearches = [
    'AI Backpack',
    'Smart Clothing',
    'Tech Sneakers',
    'Neural Interface',
    'Future Fashion',
    'Connected Wear'
  ];

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Search functionality
  useEffect(() => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      
      // Simulate search delay
      const timeoutId = setTimeout(() => {
        const filtered = mockProducts.filter(product =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.category.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setSearchResults(filtered);
        setIsSearching(false);
      }, 300);

      return () => clearTimeout(timeoutId);
    } else {
      setSearchResults([]);
      setIsSearching(false);
    }
  }, [searchQuery]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Add to recent searches
      setRecentSearches(prev => [
        searchQuery,
        ...prev.filter(term => term !== searchQuery).slice(0, 3)
      ]);
    }
  };

  const handleProductClick = (productId: string) => {
    onProductSelect?.(productId);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Search Overlay */}
          <motion.div
            className="fixed inset-0 z-[101] flex items-start justify-center pt-20 px-4"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
              {/* Search Header */}
              <div className="p-6 border-b border-slate-100">
                <form onSubmit={handleSearchSubmit} className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    ref={inputRef}
                    type="text"
                    placeholder="Suche nach AI Fashion, Tech Wear, Smart Accessories..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-12 pr-12 py-4 text-lg font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-200"
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={onClose}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <X className="h-5 w-5 text-slate-400" />
                  </button>
                </form>
              </div>

              {/* Search Content */}
              <div className="max-h-96 overflow-y-auto">
                {isSearching ? (
                  <div className="p-8 text-center">
                    <motion.div
                      className="inline-block w-8 h-8 border-2 border-cyan-200 border-t-cyan-500 rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    />
                    <p className="mt-4 text-slate-600">Suche läuft...</p>
                  </div>
                ) : searchQuery.trim() ? (
                  searchResults.length > 0 ? (
                    <div className="p-4">
                      <h3 className="text-sm font-semibold text-slate-600 mb-4 px-2">
                        Suchergebnisse ({searchResults.length})
                      </h3>
                      <div className="space-y-2">
                        {searchResults.map((product, index) => (
                          <motion.div
                            key={product.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex items-center gap-4 p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors group"
                            onClick={() => handleProductClick(product.id)}
                          >
                            <div className="w-12 h-12 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
                              <ImageWithFallback
                                src={product.image}
                                alt={product.name}
                                className="w-full h-full object-contain"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-slate-900 truncate group-hover:text-cyan-600 transition-colors">
                                {product.name}
                              </h4>
                              <div className="flex items-center gap-2 text-sm text-slate-500">
                                <span>{product.category}</span>
                                <span>•</span>
                                <span className="font-medium text-slate-900">{product.price}</span>
                              </div>
                            </div>
                            <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-cyan-500 transition-colors" />
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-8 text-center">
                      <div className="w-16 h-16 mx-auto bg-slate-100 rounded-full flex items-center justify-center mb-4">
                        <Search className="h-8 w-8 text-slate-400" />
                      </div>
                      <p className="text-lg font-medium text-slate-600 mb-2">Keine Ergebnisse gefunden</p>
                      <p className="text-slate-500">Versuche es mit anderen Suchbegriffen</p>
                    </div>
                  )
                ) : (
                  <div className="p-4">
                    {/* Recent Searches */}
                    {recentSearches.length > 0 && (
                      <div className="mb-6">
                        <h3 className="text-sm font-semibold text-slate-600 mb-3 px-2 flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          Letzte Suchen
                        </h3>
                        <div className="space-y-1">
                          {recentSearches.map((term, index) => (
                            <button
                              key={index}
                              onClick={() => setSearchQuery(term)}
                              className="w-full text-left px-3 py-2 hover:bg-slate-50 rounded-lg transition-colors text-slate-700 hover:text-slate-900"
                            >
                              {term}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Trending Searches */}
                    <div>
                      <h3 className="text-sm font-semibold text-slate-600 mb-3 px-2 flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        Trending
                      </h3>
                      <div className="flex flex-wrap gap-2 px-2">
                        {trendingSearches.map((term, index) => (
                          <button
                            key={index}
                            onClick={() => setSearchQuery(term)}
                            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-full text-sm text-slate-700 hover:text-slate-900 transition-colors"
                          >
                            {term}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}