import { X, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';
import { useCart } from './CartContext';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Button } from '../ui/button';

export function CartSidebar() {
  const { state, removeItem, updateQuantity, closeCart, clearCart } = useCart();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  };

  const getItemKey = (item: any) => {
    return `${item.id}-${item.size || 'no-size'}-${item.color || 'no-color'}`;
  };

  return (
    <AnimatePresence>
      {state.isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            className="fixed inset-0 bg-black/50 z-40"
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-md z-50 flex flex-col"
            style={{
              background: 'var(--bg-dark)',
              borderLeft: '1px solid rgba(255, 255, 255, 0.1)'
            }}
          >
            {/* Header */}
            <div 
              className="flex items-center justify-between p-6 border-b"
              style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}
            >
              <h2 style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: 'var(--white)',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
              }}>
                Warenkorb
              </h2>
              <button
                onClick={closeCart}
                className="p-2 rounded-lg transition-all duration-300"
                style={{
                  color: 'var(--text-light)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = 'var(--accent-cyan)';
                  e.currentTarget.style.backgroundColor = 'rgba(0, 255, 255, 0.1)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = 'var(--text-light)';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            {state.items.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center" style={{ backgroundColor: 'var(--bg-dark)' }}>
                <ShoppingBag 
                  size={64} 
                  style={{ color: 'var(--text-light)', marginBottom: '1rem' }} 
                />
                <h3 style={{
                  fontSize: '1.25rem',
                  fontWeight: '600',
                  color: 'var(--white)',
                  marginBottom: '0.5rem'
                }}>
                  Dein Warenkorb ist leer
                </h3>
                <p style={{
                  color: 'var(--text-light)',
                  marginBottom: '2rem'
                }}>
                  Entdecke unsere futuristische Fashion-Kollektion
                </p>
                <Button
                  onClick={closeCart}
                  className="w-full"
                  style={{
                    background: 'linear-gradient(135deg, var(--primary-blue) 0%, var(--accent-cyan) 100%)',
                    border: 'none',
                    color: 'var(--white)'
                  }}
                >
                  Weitershoppen
                </Button>
              </div>
            ) : (
              <>
                {/* Items */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4" style={{ background: 'linear-gradient(to bottom right, #334155, #1d4ed8, #4338ca)' }}>
                  {state.items.map((item) => (
                    <motion.div
                      key={getItemKey(item)}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex gap-4 p-4 rounded-lg"
                      style={{
                        background: 'rgba(255, 255, 255, 0.05)',
                        border: '1px solid rgba(255, 255, 255, 0.1)'
                      }}
                    >
                      {/* Product Image */}
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Product Info */}
                      <div className="flex-1 min-w-0">
                        <h4 style={{
                          fontSize: '0.875rem',
                          fontWeight: '600',
                          color: 'var(--white)',
                          marginBottom: '0.25rem'
                        }}>
                          {item.name}
                        </h4>
                        
                        {(item.size || item.color) && (
                          <div className="flex gap-2 mb-2">
                            {item.size && (
                              <span style={{
                                fontSize: '0.75rem',
                                color: '#F8FAFC',
                                background: 'rgba(255, 255, 255, 0.15)',
                                padding: '0.125rem 0.5rem',
                                borderRadius: '0.25rem',
                                border: '1px solid rgba(255, 255, 255, 0.2)'
                              }}>
                                {item.size}
                              </span>
                            )}
                            {item.color && (
                              <span style={{
                                fontSize: '0.75rem',
                                color: '#F8FAFC',
                                background: 'rgba(255, 255, 255, 0.15)',
                                padding: '0.125rem 0.5rem',
                                borderRadius: '0.25rem',
                                border: '1px solid rgba(255, 255, 255, 0.2)'
                              }}>
                                {item.color}
                              </span>
                            )}
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          {/* Quantity Controls */}
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1, item.size, item.color)}
                              className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300"
                              style={{
                                background: 'rgba(255, 255, 255, 0.1)',
                                color: 'var(--white)'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = 'var(--accent-cyan)';
                                e.currentTarget.style.color = 'var(--bg-dark)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
                                e.currentTarget.style.color = 'var(--white)';
                              }}
                            >
                              <Minus size={12} />
                            </button>
                            
                            <span style={{
                              fontSize: '0.875rem',
                              fontWeight: '600',
                              color: 'var(--white)',
                              minWidth: '2rem',
                              textAlign: 'center'
                            }}>
                              {item.quantity}
                            </span>
                            
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1, item.size, item.color)}
                              className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300"
                              style={{
                                background: 'rgba(255, 255, 255, 0.1)',
                                color: 'var(--white)'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = 'var(--accent-cyan)';
                                e.currentTarget.style.color = 'var(--bg-dark)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
                                e.currentTarget.style.color = 'var(--white)';
                              }}
                            >
                              <Plus size={12} />
                            </button>
                          </div>

                          {/* Price & Remove */}
                          <div className="flex items-center gap-2">
                            <span style={{
                              fontSize: '0.875rem',
                              fontWeight: '600',
                              color: '#000000'
                            }}>
                              {formatPrice(item.price * item.quantity)}
                            </span>
                            
                            <button
                              onClick={() => removeItem(item.id, item.size, item.color)}
                              className="p-1 rounded transition-all duration-300"
                              style={{ color: 'var(--text-light)' }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.color = '#EF4444';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.color = 'var(--text-light)';
                              }}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  {/* Gesamtbetrag Anzeige */}
                  <div 
                    className="p-4 rounded-lg mb-4"
                    style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                      backdropFilter: 'blur(10px)'
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <span style={{
                        fontSize: '1.125rem',
                        fontWeight: '600',
                        color: '#F8FAFC'
                      }}>
                        Gesamtbetrag:
                      </span>
                      <span style={{
                        fontSize: '1.375rem',
                        fontWeight: '700',
                        color: '#000000'
                      }}>
                        {formatPrice(state.total)}
                      </span>
                    </div>
                  </div>

                  {/* Clear Cart Button */}
                  {state.items.length > 1 && (
                    <button
                      onClick={clearCart}
                      className="w-full py-2 px-4 rounded-lg transition-all duration-300"
                      style={{
                        background: 'rgba(239, 68, 68, 0.1)',
                        border: '1px solid rgba(239, 68, 68, 0.3)',
                        color: '#EF4444'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'rgba(239, 68, 68, 0.2)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)';
                      }}
                    >
                      <Trash2 size={16} className="inline mr-2" />
                      Warenkorb leeren
                    </button>
                  )}
                </div>

                {/* Footer */}
                <div 
                  className="p-6 border-t"
                  style={{ 
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    backgroundColor: 'var(--bg-dark)'
                  }}
                >
                  <div className="flex justify-between items-center mb-4">
                    <span style={{
                      fontSize: '1.125rem',
                      fontWeight: '600',
                      color: 'var(--white)'
                    }}>
                      Gesamt:
                    </span>
                    <span style={{
                      fontSize: '1.25rem',
                      fontWeight: '700',
                      color: '#000000'
                    }}>
                      {formatPrice(state.total)}
                    </span>
                  </div>

                  <div className="space-y-3">
                    <Button
                      className="w-full"
                      style={{
                        background: 'linear-gradient(135deg, var(--primary-blue) 0%, var(--accent-cyan) 100%)',
                        border: 'none',
                        color: 'var(--white)'
                      }}
                    >
                      Zur Kasse
                    </Button>
                    
                    <button
                      onClick={closeCart}
                      className="w-full py-2 px-4 rounded-lg transition-all duration-300"
                      style={{
                        background: 'transparent',
                        border: '1px solid rgba(255, 255, 255, 0.2)',
                        color: 'var(--white)'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                        e.currentTarget.style.background = 'rgba(0, 255, 255, 0.1)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                        e.currentTarget.style.background = 'transparent';
                      }}
                    >
                      Weitershoppen
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}