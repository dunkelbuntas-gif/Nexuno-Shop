import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, ShoppingBag, Trash2, Heart, RefreshCw, Package } from 'lucide-react';
import { useCart } from './CartContext';
import { CartItemCard } from './CartItemCard';
import { CartSummary } from './CartSummary';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { toast } from 'sonner@2.0.3';

interface CartPageProps {
  onBack?: () => void;
  onCheckout?: () => void;
  onContinueShopping?: () => void;
  onProductClick?: (productId: string) => void;
}

export function CartPage({ 
  onBack, 
  onCheckout, 
  onContinueShopping,
  onProductClick 
}: CartPageProps) {
  const [isClearing, setIsClearing] = useState(false);
  const { state, clearCart } = useCart();

  const handleClearCart = async () => {
    if (state.items.length === 0) return;
    
    setIsClearing(true);
    
    // Show confirmation
    const confirmed = window.confirm('Möchten Sie wirklich alle Artikel aus dem Warenkorb entfernen?');
    
    if (confirmed) {
      // Add slight delay for better UX
      setTimeout(() => {
        clearCart();
        setIsClearing(false);
        toast.success('Warenkorb wurde geleert');
      }, 500);
    } else {
      setIsClearing(false);
    }
  };

  const handleProductClick = (productId: string) => {
    onProductClick?.(productId);
  };

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const subtotal = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200/50 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              {onBack && (
                <Button
                  variant="ghost"
                  onClick={onBack}
                  className="p-2 hover:bg-gray-100"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              )}
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-lg">
                  <ShoppingBag className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Warenkorb</h1>
                  <p className="text-sm text-gray-600">
                    {state.itemCount} {state.itemCount === 1 ? 'Artikel' : 'Artikel'}
                  </p>
                </div>
              </div>
            </div>

            {/* Header Actions */}
            <div className="flex items-center gap-3">
              {state.items.length > 0 && (
                <Button
                  variant="outline"
                  onClick={handleClearCart}
                  disabled={isClearing}
                  className="border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
                >
                  {isClearing ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4 mr-2" />
                  )}
                  Alle entfernen
                </Button>
              )}
              
              <Badge variant="outline" className="bg-cyan-50 text-cyan-700 border-cyan-200">
                {formatPrice(subtotal)}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {state.items.length === 0 ? (
          /* Empty Cart */
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16"
          >
            <Card className="max-w-md mx-auto p-8 bg-white/80 backdrop-blur-sm">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShoppingBag className="w-10 h-10 text-gray-400" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Ihr Warenkorb ist leer
              </h2>
              
              <p className="text-gray-600 mb-8">
                Entdecken Sie unsere einzigartigen Fashion-Kollektionen und 
                finden Sie Ihr neues Lieblingsstück.
              </p>
              
              <div className="space-y-3">
                <Button
                  onClick={onContinueShopping}
                  className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                >
                  <Package className="w-5 h-5 mr-2" />
                  Jetzt shoppen
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => {/* Navigate to wishlist */}}
                  className="w-full border-gray-300 hover:bg-gray-50"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Zur Wunschliste
                </Button>
              </div>
            </Card>
          </motion.div>
        ) : (
          /* Cart with Items */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              {/* Items Header */}
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">
                  Ihre Artikel ({state.itemCount})
                </h2>
                
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span>Sortieren nach:</span>
                  <select className="border border-gray-300 rounded-lg px-3 py-1 text-sm bg-white">
                    <option>Zuletzt hinzugefügt</option>
                    <option>Preis: Niedrig zu Hoch</option>
                    <option>Preis: Hoch zu Niedrig</option>
                    <option>Name A-Z</option>
                  </select>
                </div>
              </div>

              {/* Items List */}
              <motion.div layout className="space-y-4">
                <AnimatePresence mode="popLayout">
                  {state.items.map((item, index) => (
                    <motion.div
                      key={`${item.id}-${item.size}-${item.color}`}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -100, height: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <CartItemCard
                        item={item}
                        variant="detailed"
                        onItemClick={(item) => handleProductClick(item.id)}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>

              {/* Continue Shopping */}
              <Card className="p-6 bg-gradient-to-r from-cyan-50 to-blue-50 border border-cyan-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-cyan-900 mb-1">
                      Noch nicht fertig?
                    </h3>
                    <p className="text-sm text-cyan-700">
                      Entdecken Sie weitere Artikel aus unseren Kollektionen
                    </p>
                  </div>
                  <Button
                    onClick={onContinueShopping}
                    variant="outline"
                    className="border-cyan-300 text-cyan-700 hover:bg-cyan-100"
                  >
                    Weiter shoppen
                  </Button>
                </div>
              </Card>
            </div>

            {/* Cart Summary */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <CartSummary
                  onCheckout={onCheckout}
                  showPromotions={true}
                  showTrustBadges={true}
                />

                {/* Recently Viewed */}
                <Card className="mt-6 p-4 bg-white/80 backdrop-blur-sm border border-gray-200/50">
                  <h4 className="font-semibold text-gray-900 mb-3">Zuletzt angesehen</h4>
                  <div className="space-y-2">
                    {/* Placeholder for recently viewed items */}
                    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <div className="w-10 h-10 bg-gray-200 rounded"></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">Future Tech T-Shirt</p>
                        <p className="text-xs text-gray-500">€39.99</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <div className="w-10 h-10 bg-gray-200 rounded"></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">Cyber Hoodie</p>
                        <p className="text-xs text-gray-500">€79.99</p>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isClearing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
          >
            <Card className="p-6 bg-white max-w-sm mx-4">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 text-cyan-600 animate-spin mx-auto mb-4" />
                <h3 className="font-semibold text-gray-900 mb-2">Warenkorb wird geleert...</h3>
                <p className="text-sm text-gray-600">Bitte warten Sie einen Moment</p>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}